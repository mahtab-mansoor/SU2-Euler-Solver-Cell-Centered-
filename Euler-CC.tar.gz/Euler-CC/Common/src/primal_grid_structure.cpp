/*!
 * \file primal_grid_structure.cpp
 * \brief Main classes for defining the primal grid elements
 * \author F. Palacios
 * \version 3.2.8 "eagle"
 *
 * SU2 Lead Developers: Dr. Francisco Palacios (fpalacios@stanford.edu).
 *                      Dr. Thomas D. Economon (economon@stanford.edu).
 *
 * SU2 Developers: Prof. Juan J. Alonso's group at Stanford University.
 *                 Prof. Piero Colonna's group at Delft University of Technology.
 *                 Prof. Nicolas R. Gauger's group at Kaiserslautern University of Technology.
 *                 Prof. Alberto Guardone's group at Polytechnic University of Milan.
 *                 Prof. Rafael Palacios' group at Imperial College London.
 *
 * Copyright (C) 2012-2015 SU2, the open-source CFD code.
 *
 * SU2 is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * SU2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with SU2. If not, see <http://www.gnu.org/licenses/>.
 */

#include "../include/primal_grid_structure.hpp"

unsigned short CPrimalGrid::nDim;

CPrimalGrid::CPrimalGrid(void) {

//    Nodes = NULL;
//    Neighbor_Elements = NULL;
//    Coord_CG = NULL;
//    Coord_FaceElems_CG = NULL;
    //##MAHTAB##//
    Elems = NULL;
    Node_Face = NULL;
    Neighbor_Face = NULL;
    Neighbor_Cell = NULL;
    CG = NULL;
    Normal_Face = NULL;
    GridVel = NULL;
    Volume_DT = NULL;
    Coord_p1 = NULL;
    Coord_n = NULL;
    Coord_n1 = NULL;
    //##MAHTAB##//
}

CPrimalGrid::~CPrimalGrid() {

    //##MAHTAB##//
    if (Elems != NULL) delete[] Elems;
    if (Node_Face != NULL) delete[] Node_Face;
    if (Neighbor_Face != NULL) delete[] Neighbor_Face;
    if (Neighbor_Cell != NULL) delete[] Neighbor_Cell;
    if (CG != NULL) delete[] CG;
    if (Normal_Face != NULL) delete[] Normal_Face;
    if (GridVel != NULL) delete[] GridVel;
    if (Volume_DT != NULL) delete[] Volume_DT;
    if (Coord_p1 != NULL) delete[] Coord_p1;
    if (Coord_n != NULL) delete[] Coord_n;
    if (Coord_n1 != NULL) delete[] Coord_n1;

    //##MAHTAB##///*
//    if (Nodes != NULL) delete[] Nodes;
//    if (Coord_CG != NULL) delete[] Coord_CG;
//    if (Neighbor_Elements != NULL) delete[] Neighbor_Elements;
}

//void CPrimalGrid::SetCG(double **val_coord) {
//    unsigned short iDim, iNode, NodeFace, iFace;

//    for (iDim = 0; iDim < nDim; iDim++) {
//        Coord_CG[iDim] = 0.0;
//        for (iNode = 0; iNode < GetnNodes();  iNode++)
//            Coord_CG[iDim] += val_coord[iNode][iDim]/double(GetnNodes());
//    }

//    for (iFace = 0; iFace < GetnFaces();  iFace++)
//        for (iDim = 0; iDim < nDim; iDim++) {
//            Coord_FaceElems_CG[iFace][iDim] = 0.0;
//            for (iNode = 0; iNode < GetnNodesFace(iFace); iNode++) {
//                NodeFace = GetFaces(iFace, iNode);
//                Coord_FaceElems_CG[iFace][iDim] += val_coord[NodeFace][iDim]/double(GetnNodesFace(iFace));
//            }
//        }
//}

//void CPrimalGrid::GetAllNeighbor_Elements() {
//    cout << "( ";
//    for (unsigned short iFace = 0; iFace < GetnFaces(); iFace++)
//    {
//        cout << GetNeighbor_Elements(iFace) << ", ";
//    }
//    cout << ")"  << endl;
//}

//unsigned short CVertexMPI::nFaces = 0;

//unsigned short CVertexMPI::nNodes = 1;

//unsigned short CVertexMPI::nNeighbor_Elements = 0;

//unsigned short CVertexMPI::VTK_Type = 1;

//unsigned short CVertexMPI::maxNodesFace = 0;

CVertexMPI::CVertexMPI(unsigned long val_point, unsigned short val_nDim) : CPrimalGrid() {
    unsigned short iDim;

//    /*--- Allocate CG coordinates ---*/
    nDim = val_nDim;
//    Coord_CG = new double[nDim];
//    for (iDim = 0; iDim < nDim; iDim++) Coord_CG[iDim] = 0.0;

//    /*--- Allocate and define face structure of the element ---*/
//    Nodes = new unsigned long[nNodes];
//    Nodes[0] = val_point;

//    /*--- By default, no rotation in the solution ---*/
//    Rotation_Type = 0;

}

CVertexMPI::~CVertexMPI() {
//    unsigned short iFaces;

//    for (iFaces = 0; iFaces < nFaces; iFaces++)
//        if (Coord_FaceElems_CG[iFaces] != NULL) delete[] Coord_FaceElems_CG[iFaces];
//    if (Coord_FaceElems_CG != NULL) delete[] Coord_FaceElems_CG;

}

void CVertexMPI::Change_Orientation(void) { cout << "Not defined orientation change" << endl; }

CFace::CFace(unsigned short nNodes, unsigned long val_globalindex) : CPrimalGrid() {

    Atri = NULL;
    unsigned short iElems, iNode, iDim;
    nDim = 3;

    Elems = new long[2];
    for (iElems = 0; iElems < 2; iElems++) Elems[iElems]=-1;

    nNodes_Face = nNodes;
    Node_Face = new unsigned long[nNodes_Face];
    CG = new double[nDim];
    Normal_Face = new double[nDim];
    GlobalIndex = val_globalindex;
    GridVel = new double[nDim];

    Atri = new double* [nNodes_Face];
    for (iNode = 0; iNode < nNodes_Face; iNode++) {
            Atri[iNode] = new double [nDim];
            for (iDim = 0; iDim < nDim; iDim ++)
                    Atri[iNode][iDim] = 0.0;
    }
}

CFace::~CFace() {
    unsigned short iNode;
    if (Atri != NULL) {
      for (iNode = 0; iNode < nNodes_Face; iNode++)
        delete Atri[iNode];
      delete [] Atri;
    }

}
CElement::CElement(unsigned short val_nfaces, unsigned long val_globalindex) : CPrimalGrid() {

    unsigned short iFace;
    nDim = 3;
    nNeighbor_Face = val_nfaces; //This is the max. value of the faces surrounding an element.//
    Neighbor_Face = new long[nNeighbor_Face];
    Neighbor_Cell = new long[nNeighbor_Face];
    CG = new double[nDim];
    GridVel = new double[nDim];
    GlobalIndex = val_globalindex;
    Volume_DT = new double[3]; Volume_DT[0] = 0.0; Volume_DT[1] = 0.0; Volume_DT[2] = 0.0;
    Coord_p1 = new double[nDim];
    Coord_n  = new double[nDim];
    Coord_n1 = new double[nDim];
}

CElement::~CElement() {

}

//unsigned short CLine::Faces[1][2]={{0,1}};

//unsigned short CLine::Neighbor_Nodes[2][1]={{1},{0}};

//unsigned short CLine::nNodesFace[1]={2};

//unsigned short CLine::nNeighbor_Nodes[2]={1,1};

//unsigned short CLine::nFaces = 1;

//unsigned short CLine::nNodes = 2;

//unsigned short CLine::nNeighbor_Elements = 1;

//unsigned short CLine::VTK_Type = 3;

//unsigned short CLine::maxNodesFace = 2;

//CLine::CLine(unsigned long val_point_0, unsigned long val_point_1,
//             unsigned short val_nDim) : CPrimalGrid() {
//    unsigned short iDim, iFace;

//    /*--- Allocate CG coordinates ---*/

//    nDim = val_nDim;
//    Coord_CG = new double[nDim];
//    for (iDim = 0; iDim < nDim; iDim++)
//        Coord_CG[iDim] = 0.0;
//    Coord_FaceElems_CG = new double* [nFaces];
//    for (iFace = 0; iFace < nFaces; iFace++) {
//        Coord_FaceElems_CG[iFace] = new double [nDim];
//        for (iDim = 0; iDim < nDim; iDim++)
//            Coord_FaceElems_CG[iFace][iDim] = 0.0;
//    }

//    /*--- Allocate and define face structure of the element ---*/

//    Nodes = new unsigned long[nNodes];
//    Nodes[0] = val_point_0;
//    Nodes[1] = val_point_1;

//}

//CLine::~CLine() {
//    unsigned short iFaces;

//    for (iFaces = 0; iFaces < nFaces; iFaces++)
//        if (Coord_FaceElems_CG[iFaces] != NULL) delete[] Coord_FaceElems_CG[iFaces];
//    if (Coord_FaceElems_CG != NULL) delete[] Coord_FaceElems_CG;

//}

//void CLine::Change_Orientation(void) {
//    unsigned long iPoint, jPoint;

//    iPoint = Nodes[0];
//    jPoint = Nodes[1];
//    Nodes[0] = jPoint;
//    Nodes[1] = iPoint;
//}

//unsigned short CTriangle::Faces[3][2] = {{0,1},{1,2},{2,0}};

//unsigned short CTriangle::Neighbor_Nodes[3][2] = {{1,2},{2,0},{0,1}};

//unsigned short CTriangle::nNodesFace[3] = {2,2,2};

//unsigned short CTriangle::nNeighbor_Nodes[3] = {2,2,2};

//unsigned short CTriangle::nFaces = 3;

//unsigned short CTriangle::nNodes = 3;

//unsigned short CTriangle::nNeighbor_Elements = 3;

//unsigned short CTriangle::VTK_Type = 5;

//unsigned short CTriangle::maxNodesFace = 2;

//CTriangle::CTriangle(unsigned long val_point_0, unsigned long val_point_1,
//                     unsigned long val_point_2, unsigned short val_nDim) : CPrimalGrid() {
//    unsigned short iDim, iFace, iNeighbor_Elements;

//    /*--- Allocate CG coordinates ---*/
//    nDim = val_nDim;
//    Coord_CG = new double[nDim];
//    for (iDim = 0; iDim < nDim; iDim++)
//        Coord_CG[iDim] = 0.0;
//    Coord_FaceElems_CG = new double* [nFaces];
//    for (iFace = 0; iFace < nFaces; iFace++) {
//        Coord_FaceElems_CG[iFace] = new double [nDim];
//        for (iDim = 0; iDim < nDim; iDim++)
//            Coord_FaceElems_CG[iFace][iDim] = 0.0;
//    }
//    /*--- Allocate and define face structure of the element ---*/
//    Nodes = new unsigned long[nNodes];
//    Nodes[0] = val_point_0;
//    Nodes[1] = val_point_1;
//    Nodes[2] = val_point_2;

//    /*--- Allocate and define neighbor elements to a element ---*/
//    nNeighbor_Elements = nFaces;
//    Neighbor_Elements = new long[nNeighbor_Elements];
//    for (iNeighbor_Elements = 0; iNeighbor_Elements<nNeighbor_Elements; iNeighbor_Elements++) {
//        Neighbor_Elements[iNeighbor_Elements]=-1;
//    }

//}

//CTriangle::~CTriangle() {
//    unsigned short iFaces;

//    for (iFaces = 0; iFaces < nFaces; iFaces++)
//        if (Coord_FaceElems_CG[iFaces] != NULL) delete[] Coord_FaceElems_CG[iFaces];
//    if (Coord_FaceElems_CG != NULL) delete[] Coord_FaceElems_CG;

//}

//void CTriangle::Change_Orientation(void) {
//    unsigned long iPoint, Point_2;
//    iPoint = Nodes[0];
//    Point_2 = Nodes[2];
//    Nodes[0] = Point_2;
//    Nodes[2] = iPoint;

//}

//unsigned short CRectangle::Faces[4][2] = {{0,1},{1,2},{2,3},{3,0}};

//unsigned short CRectangle::Neighbor_Nodes[4][2] = {{1,3},{2,0},{3,1},{0,2}};

//unsigned short CRectangle::nNodesFace[4] = {2,2,2,2};

//unsigned short CRectangle::nNeighbor_Nodes[4] = {2,2,2,2};

//unsigned short CRectangle::nFaces = 4;

//unsigned short CRectangle::nNodes = 4;

//unsigned short CRectangle::nNeighbor_Elements = 4;

//unsigned short CRectangle::VTK_Type = 9;

//unsigned short CRectangle::maxNodesFace = 2;

//CRectangle::CRectangle(unsigned long val_point_0, unsigned long val_point_1,
//                       unsigned long val_point_2, unsigned long val_point_3, unsigned short val_nDim)
//    : CPrimalGrid() {
//    unsigned short iDim, iFace, iNeighbor_Elements;

//    /*--- Allocate CG coordinates ---*/
//    nDim = val_nDim;
//    Coord_CG = new double[nDim];
//    for (iDim = 0; iDim < nDim; iDim++)
//        Coord_CG[iDim] = 0.0;
//    Coord_FaceElems_CG = new double* [nFaces];
//    for (iFace = 0; iFace < nFaces; iFace++) {
//        Coord_FaceElems_CG[iFace] = new double [nDim];
//        for (iDim = 0; iDim < nDim; iDim++)
//            Coord_FaceElems_CG[iFace][iDim] = 0.0;
//    }

//    /*--- Allocate and define face structure of the element ---*/
//    Nodes = new unsigned long[nNodes];
//    Nodes[0] = val_point_0;
//    Nodes[1] = val_point_1;
//    Nodes[2] = val_point_2;
//    Nodes[3] = val_point_3;


//    nNeighbor_Elements = nFaces;
//    Neighbor_Elements = new long[nNeighbor_Elements];
//    for (iNeighbor_Elements = 0; iNeighbor_Elements<nNeighbor_Elements; iNeighbor_Elements++) {
//        Neighbor_Elements[iNeighbor_Elements]=-1;
//    }

//}

//CRectangle::~CRectangle() {
//    unsigned short iFaces;

//    for (iFaces = 0; iFaces < nFaces; iFaces++)
//        if (Coord_FaceElems_CG[iFaces] != NULL) delete[] Coord_FaceElems_CG[iFaces];
//    if (Coord_FaceElems_CG != NULL) delete[] Coord_FaceElems_CG;

//}

//void CRectangle::Change_Orientation(void) {
//    unsigned long jPoint, Point_3;
//    jPoint = Nodes[1];
//    Point_3 = Nodes[3];
//    Nodes[1] = Point_3;
//    Nodes[3] = jPoint;

//}

//unsigned short CTetrahedron::Faces[4][3]={{0,2,1},{0,1,3},{0,3,2},{1,2,3}};

//unsigned short CTetrahedron::Neighbor_Nodes[4][3]={{1,2,3},{0,2,3},{0,1,3},{0,1,2}};

//unsigned short CTetrahedron::nNodesFace[4]={3,3,3,3};

//unsigned short CTetrahedron::nNeighbor_Nodes[4]={3,3,3,3};

//unsigned short CTetrahedron::nFaces = 4;

//unsigned short CTetrahedron::nNodes = 4;

//unsigned short CTetrahedron::nNeighbor_Elements = 4;

//unsigned short CTetrahedron::VTK_Type = 10;

//unsigned short CTetrahedron::maxNodesFace = 3;

//CTetrahedron::CTetrahedron(unsigned long val_point_0, unsigned long val_point_1,
//                           unsigned long val_point_2, unsigned long val_point_3) : CPrimalGrid() {
//    unsigned short iDim, iFace, iNeighbor_Elements;

//    /*--- Allocate CG coordinates ---*/
//    nDim = 3;
//    Coord_CG = new double[nDim];
//    for (iDim = 0; iDim < nDim; iDim++)
//        Coord_CG[iDim] = 0.0;
//    Coord_FaceElems_CG = new double* [nFaces];
//    for (iFace = 0; iFace < nFaces; iFace++) {
//        Coord_FaceElems_CG[iFace] = new double [nDim];
//        for (iDim = 0; iDim < nDim; iDim++)
//            Coord_FaceElems_CG[iFace][iDim] = 0.0;
//    }

//    /*--- Allocate and define face structure of the element ---*/
//    Nodes = new unsigned long[nNodes];
//    Nodes[0] = val_point_0;
//    Nodes[1] = val_point_1;
//    Nodes[2] = val_point_2;
//    Nodes[3] = val_point_3;

//    /*--- Allocate and define neighbor elements to a element ---*/
//    nNeighbor_Elements = nFaces;
//    Neighbor_Elements = new long[nNeighbor_Elements];
//    for (iNeighbor_Elements = 0; iNeighbor_Elements<nNeighbor_Elements; iNeighbor_Elements++) {
//        Neighbor_Elements[iNeighbor_Elements]=-1;
//    }

//}

//CTetrahedron::~CTetrahedron() {
//    unsigned short iFaces;

//    for (iFaces = 0; iFaces < nFaces; iFaces++)
//        if (Coord_FaceElems_CG[iFaces] != NULL) delete[] Coord_FaceElems_CG[iFaces];
//    if (Coord_FaceElems_CG != NULL) delete[] Coord_FaceElems_CG;

//}

//void CTetrahedron::Change_Orientation(void) {
//    unsigned long iPoint, jPoint;
//    iPoint = Nodes[0];
//    jPoint = Nodes[1];
//    Nodes[0] = jPoint;
//    Nodes[1] = iPoint;

//}

//unsigned short CHexahedron::Faces[6][4] = {{0,1,5,4},{1,2,6,5},{2,3,7,6},{3,0,4,7},{0,3,2,1},{4,5,6,7}};

//unsigned short CHexahedron::Neighbor_Nodes[8][3] = {{1,3,4},{0,2,5},{1,3,6},{0,2,7},{0,5,7},{4,6,1},{2,5,7},{4,3,6}};

//unsigned short CHexahedron::nNodesFace[6] = {4,4,4,4,4,4};

//unsigned short CHexahedron::nNeighbor_Nodes[8] = {3,3,3,3,3,3,3,3};

//unsigned short CHexahedron::nFaces = 6;

//unsigned short CHexahedron::nNodes = 8;

//unsigned short CHexahedron::nNeighbor_Elements = 6;

//unsigned short CHexahedron::VTK_Type = 12;

//unsigned short CHexahedron::maxNodesFace = 4;

//CHexahedron::CHexahedron(unsigned long val_point_0, unsigned long val_point_1,
//                         unsigned long val_point_2, unsigned long val_point_3,
//                         unsigned long val_point_4, unsigned long val_point_5,
//                         unsigned long val_point_6, unsigned long val_point_7) : CPrimalGrid() {
//    unsigned short iDim, iFace, iNeighbor_Elements;

//    /*--- Allocate center-of-gravity coordinates ---*/
//    nDim = 3;
//    Coord_CG = new double[nDim];
//    for (iDim = 0; iDim < nDim; iDim++)
//        Coord_CG[iDim] = 0.0;
//    Coord_FaceElems_CG = new double* [nFaces];
//    for (iFace = 0; iFace < nFaces; iFace++) {
//        Coord_FaceElems_CG[iFace] = new double [nDim];
//        for (iDim = 0; iDim < nDim; iDim++)
//            Coord_FaceElems_CG[iFace][iDim] = 0.0;
//    }

//    /*--- Allocate and define face structure of the element ---*/
//    Nodes = new unsigned long[nNodes];
//    Nodes[0] = val_point_0;	Nodes[1] = val_point_1;
//    Nodes[2] = val_point_2;	Nodes[3] = val_point_3;
//    Nodes[4] = val_point_4;	Nodes[5] = val_point_5;
//    Nodes[6] = val_point_6;	Nodes[7] = val_point_7;

//    /*--- Allocate and define neighbor elements to a element ---*/
//    nNeighbor_Elements = nFaces;
//    Neighbor_Elements = new long[nNeighbor_Elements];
//    for (iNeighbor_Elements = 0; iNeighbor_Elements<nNeighbor_Elements; iNeighbor_Elements++) {
//        Neighbor_Elements[iNeighbor_Elements]=-1;
//    }

//}

//CHexahedron::~CHexahedron() {
//    unsigned short iFaces;

//    for (iFaces = 0; iFaces < nFaces; iFaces++)
//        if (Coord_FaceElems_CG[iFaces] != NULL) delete[] Coord_FaceElems_CG[iFaces];
//    if (Coord_FaceElems_CG != NULL) delete[] Coord_FaceElems_CG;

//}

//void CHexahedron::Change_Orientation(void) {
//    unsigned long Point_0, Point_1, Point_2, Point_3, Point_4, Point_5, Point_6, Point_7;
//    Point_0 = Nodes[0];
//    Point_1 = Nodes[1];
//    Point_2 = Nodes[2];
//    Point_3 = Nodes[3];
//    Point_4 = Nodes[4];
//    Point_5 = Nodes[5];
//    Point_6 = Nodes[6];
//    Point_7 = Nodes[7];

//    Nodes[0] = Point_7;
//    Nodes[1] = Point_4;
//    Nodes[2] = Point_5;
//    Nodes[3] = Point_6;
//    Nodes[4] = Point_3;
//    Nodes[5] = Point_0;
//    Nodes[6] = Point_1;
//    Nodes[7] = Point_2;

//}

//unsigned short CWedge::Faces[5][4] = {{3,4,1,0},{5,2,1,4},{2,5,3,0},{0,1,2,2},{5,4,3,3}};

//unsigned short CWedge::Neighbor_Nodes[6][3] = {{1,2,3},{0,2,4},{1,0,5},{0,4,5},{3,5,1},{4,3,2}};

//unsigned short CWedge::nNodesFace[5] = {4,4,4,3,3};

//unsigned short CWedge::nNeighbor_Nodes[6] = {3,3,3,3,3,3};

//unsigned short CWedge::nFaces = 5;

//unsigned short CWedge::nNodes = 6;

//unsigned short CWedge::nNeighbor_Elements = 5;

//unsigned short CWedge::VTK_Type = 13;

//unsigned short CWedge::maxNodesFace = 4;

//CWedge::CWedge(unsigned long val_point_0, unsigned long val_point_1,
//               unsigned long val_point_2, unsigned long val_point_3,
//               unsigned long val_point_4, unsigned long val_point_5) : CPrimalGrid() {
//    unsigned short iDim, iFace, iNeighbor_Elements;

//    /*--- Allocate CG coordinates ---*/
//    nDim = 3;
//    Coord_CG = new double[nDim];
//    for (iDim = 0; iDim < nDim; iDim++) Coord_CG[iDim] = 0.0;

//    Coord_FaceElems_CG = new double* [nFaces];
//    for (iFace = 0; iFace < nFaces; iFace++) {
//        Coord_FaceElems_CG[iFace] = new double [nDim];
//        for (iDim = 0; iDim < nDim; iDim++)
//            Coord_FaceElems_CG[iFace][iDim] = 0.0;
//    }

//    /*--- Allocate and define face structure of the element ---*/
//    Nodes = new unsigned long[nNodes];
//    Nodes[0] = val_point_0;
//    Nodes[1] = val_point_1;
//    Nodes[2] = val_point_2;
//    Nodes[3] = val_point_3;
//    Nodes[4] = val_point_4;
//    Nodes[5] = val_point_5;

//    /*--- Allocate and define neighbor elements to a element ---*/
//    nNeighbor_Elements = nFaces;
//    Neighbor_Elements = new long[nNeighbor_Elements];
//    for (iNeighbor_Elements = 0; iNeighbor_Elements<nNeighbor_Elements; iNeighbor_Elements++) {
//        Neighbor_Elements[iNeighbor_Elements]=-1;
//    }

//}

//CWedge::~CWedge() {
//    unsigned short iFaces;

//    for (iFaces = 0; iFaces < nFaces; iFaces++)
//        if (Coord_FaceElems_CG[iFaces] != NULL) delete[] Coord_FaceElems_CG[iFaces];
//    if (Coord_FaceElems_CG != NULL) delete[] Coord_FaceElems_CG;

//}

//void CWedge::Change_Orientation(void) {
//    unsigned long Point_0, Point_1, Point_3, Point_4;
//    Point_0 = Nodes[0];
//    Point_1 = Nodes[1];
//    Point_3 = Nodes[3];
//    Point_4 = Nodes[4];

//    Nodes[0] = Point_1;
//    Nodes[1] = Point_0;
//    Nodes[3] = Point_4;
//    Nodes[4] = Point_3;

//}

//unsigned short CPyramid::Faces[5][4] = {{0,3,2,1},{4,3,0,0},{4,0,1,1},{2,4,1,1},{3,4,2,2}};

//unsigned short CPyramid::Neighbor_Nodes[5][4] = {{1,3,4,4},{0,2,4,4},{1,3,4,4},{2,0,4,4},{0,1,2,3}};

//unsigned short CPyramid::nNodesFace[5] = {4,3,3,3,3};

//unsigned short CPyramid::nNeighbor_Nodes[5] = {3,3,3,3,4};

//unsigned short CPyramid::nFaces = 5;

//unsigned short CPyramid::nNodes = 5;

//unsigned short CPyramid::nNeighbor_Elements = 5;

//unsigned short CPyramid::VTK_Type = 14;

//unsigned short CPyramid::maxNodesFace = 4;

//CPyramid::CPyramid(unsigned long val_point_0, unsigned long val_point_1,
//                   unsigned long val_point_2, unsigned long val_point_3,
//                   unsigned long val_point_4) : CPrimalGrid() {
//    unsigned short iDim, iFace, iNeighbor_Elements;

//    /*--- Allocate CG coordinates ---*/
//    nDim = 3;
//    Coord_CG = new double[nDim];
//    for (iDim = 0; iDim < nDim; iDim++)
//        Coord_CG[iDim] = 0.0;
//    Coord_FaceElems_CG = new double* [nFaces];
//    for (iFace = 0; iFace < nFaces; iFace++) {
//        Coord_FaceElems_CG[iFace] = new double [nDim];
//        for (iDim = 0; iDim < nDim; iDim++)
//            Coord_FaceElems_CG[iFace][iDim] = 0.0;
//    }

//    /*--- Allocate and define face structure of the element ---*/
//    Nodes = new unsigned long[nNodes];
//    Nodes[0] = val_point_0;
//    Nodes[1] = val_point_1;
//    Nodes[2] = val_point_2;
//    Nodes[3] = val_point_3;
//    Nodes[4] = val_point_4;

//    /*--- Allocate and define neighbor elements to a element ---*/
//    nNeighbor_Elements = nFaces;
//    Neighbor_Elements = new long[nNeighbor_Elements];
//    for (iNeighbor_Elements = 0; iNeighbor_Elements<nNeighbor_Elements; iNeighbor_Elements++) {
//        Neighbor_Elements[iNeighbor_Elements]=-1;
//    }

//}

//CPyramid::~CPyramid() {
//    unsigned short iFaces;

//    for (iFaces = 0; iFaces < nFaces; iFaces++)
//        if (Coord_FaceElems_CG[iFaces] != NULL) delete[] Coord_FaceElems_CG[iFaces];
//    if (Coord_FaceElems_CG != NULL) delete[] Coord_FaceElems_CG;

//}

//void CPyramid::Change_Orientation(void) { cout << "Not defined orientation change" << endl; }

