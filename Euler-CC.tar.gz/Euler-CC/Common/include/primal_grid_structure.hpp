/*!
 * \file primal_grid_structure.hpp
 * \brief Headers of the main subroutines for storing the primal grid structure.
 *        The subroutines and functions are in the <i>primal_grid_structure.cpp</i> file.
 * \author F. Palacios
 * \version 3.2.8 "eagle"
 *
 * SU2 Lead Developers: Dr. Francisco Palacios (fpalacios@stanford.edu).
 *                      Dr. Thomas D. Economon (economon@stanford.edu).
 *
 * SU2 Developers: Prof. Juan J. Alonso's group at Stanford University.
 *                 Prof. Piero Colonna's group at Delft University of Technology.
 *                 Prof. Nicolas R. Gauger's group at Kaiserslautern University of Technology.
 *                 Prof. Alberto Guardone's group at Polytechnic University of Milan.
 *                 Prof. Rafael Palacios' group at Imperial College London.
 *
 * Copyright (C) 2012-2015 SU2, the open-source CFD code.
 *
 * SU2 is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * SU2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with SU2. If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

#ifdef HAVE_MPI
  #include "mpi.h"
#endif
#include <iostream>
#include <vector>
#include <cstdlib>

#include "dual_grid_structure.hpp"
#include "config_structure.hpp"

using namespace std;

/*!
 * \class CPrimalGrid
 * \brief Class to define the numerical primal grid.
 * \author F. Palacios
 * \version 3.2.8 "eagle"
 */
class CPrimalGrid {
protected:
	unsigned long *Nodes;         /*!< \brief Vector to store the global nodes of an element. */
	long *Neighbor_Elements;      /*!< \brief Vector to store the elements surronding an element. */
	double *Coord_CG;             /*!< \brief Coordinates of the center-of-gravity of the element. */
	double **Coord_FaceElems_CG;	/*!< \brief Coordinates of the center-of-gravity of the face of the
                                 elements. */
	static unsigned short nDim;		/*!< \brief Dimension of the element (2D or 3D) useful for triangles,
                                 rectangles and edges. */
	unsigned long DomainElement;	/*!< \brief Only for boundaries, in this variable the 3D elements which
                                 correspond with a boundary element is stored. */
	bool Divide;                  /*!< \brief Marker used to know if we are going to divide this element
                                 in the adaptation proccess. */
        //##MAHTAB##//
        long *Elems;
        unsigned long *Node_Face, nNodes_Face;
        long *Neighbor_Face, *Neighbor_Cell;
        unsigned short nNeighbor_Face, nNeighbor_Cell;
        unsigned short color;
        unsigned long GlobalFace, GlobalIndex, Bound_Element;
        double *CG, *Normal_Face;
        bool Domain, Boundary, PhysicalBoundary, SolidBoundary;
        double Volume_Face, Volume, Wall_Distance, SharpEdge_Distance;
        double *GridVel;
        double *Volume_DT;
        double *Coord_n, *Coord_n1, *Coord_p1;
        //##MAHTAB##//

public:
	
	CPrimalGrid(void);
	
        CPrimalGrid(unsigned short val_nNodes, unsigned short val_nFaces);
	
	virtual ~CPrimalGrid(void);

        //long GetNeighbor_Elements(unsigned short val_face);
        //##MAHTAB##//  
        virtual void SetColor(unsigned short val_color);

        virtual unsigned short GetColor(void);

        virtual unsigned short GetnNeighbor_Face(void); //= 0;

        virtual void SetnNeighbor_Face(unsigned short val_nFace);

        virtual long GetNeighbor_Face(unsigned short val_surf); //= 0;

        virtual void SetNeighbor_Face(long val_face, unsigned short val_surf);
        
        virtual long GetElems(unsigned short val_neigh);

        virtual void SetElems(unsigned short val_neigh, long val_elem);

        virtual unsigned short GetnNodes_Face(void); //= 0;

        virtual void SetnNodes_Face(unsigned short val_nPoint);

        virtual unsigned long GetNode_Face(unsigned short val_node); //= 0;

        virtual void SetNode_Face(unsigned short val_node, unsigned long val_point);

        virtual unsigned long GetGlobalFace(void); //= 0;

        virtual void SetGlobalFace(unsigned long val_globalface);

        virtual void SetCG(unsigned short val_dim, double val_coord);

        virtual void SetCG(double *val_coord); //= 0;

        virtual double GetCG(unsigned short val_dim); //= 0;

        virtual double *GetCG(void);

        virtual unsigned long GetGlobalIndex(void);

        virtual void SetGlobalIndex(unsigned long val_globalindex);

        virtual unsigned long GetBound_Element(void);

        virtual void SetBound_Element(unsigned long val_boundelem);

        virtual void SetDomain(bool val_domain);

        virtual bool GetDomain(void);

        virtual void SetNormal_Face(unsigned short val_dim, double val_normal);

        virtual void SetNormal_Face(double *val_normal);

        virtual double GetNormal_Face(unsigned short val_dim);

        virtual double *GetNormal_Face(void);

        virtual double GetVolume_Face(void);

        virtual void SetVolume_Face(double val_volume_face);

        virtual void SetAtri(unsigned short val_node, unsigned short val_dim, double val_vol);

        virtual double GetAtri(unsigned short val_vol, unsigned short val_dim);

        virtual double GetVolume(void);

        virtual void SetVolume(double val_volume);

        virtual void SetnNeighbor_Cell(unsigned short val_nCell);

        virtual unsigned short GetnNeighbor_Cell(void);

        virtual long GetNeighbor_Cell(unsigned short val_cell); //= 0;

        virtual void SetNeighbor_Cell(long val_elem, unsigned short val_cell);

        virtual double GetWall_Distance(void);

        virtual void SetWall_Distance(double val_wall_dist);

        virtual double GetSharpEdge_Distance(void);

        virtual void SetGridVel(unsigned short val_dim, double val_gridvel);

        virtual void SetGridVel(double *val_gridvel);

        virtual double *GetGridVel(void);

        virtual double GetGridVel(unsigned short val_dim); //= 0;

        virtual void SetVolume_nM1(void);

        virtual double GetVolume_nM1(void);

        virtual void SetVolume_n(void);

        virtual double GetVolume_n(void);

        virtual void SetCoord_n(void);

        virtual void SetCoord_n1(void);

        virtual void SetCoord_p1(double *val_coord);

        virtual double* GetCoord_n(void);

        virtual double* GetCoord_n1(void);

        virtual double* GetCoord_p1(void);

        //virtual void SetBoundary(unsigned short val_nmarker);

        virtual void SetBoundary(bool val_boundary);

        virtual bool GetBoundary(void);

        virtual void SetPhysicalBoundary(bool val_boundary);

        virtual void SetSolidBoundary(bool val_boundary);

        virtual bool GetPhysicalBoundary(void);

        virtual bool GetSolidBoundary(void);

        //##MAHTAB##//

//	void SetNeighbor_Elements(unsigned long val_elem, unsigned short val_face);
	
//        void SetCG(double **val_coord);
	
//        double GetCG(unsigned short val_dim);
	
//	double GetFaceCG(unsigned short val_face, unsigned short val_dim);

//	void GetAllNeighbor_Elements(void);
	
//	void SetDivide(bool val_divide);

//	bool GetDivide(void);

//        void SetDomainElement(unsigned long val_domainelement);

//        unsigned long GetDomainElement(void);

//        void Change_Orientation(void); //= 0;
	
//        unsigned short GetVTK_Type(void); //= 0;

//        unsigned short GetRotation_Type(void);

//        void SetRotation_Type(unsigned short val_rotation_type);

//        unsigned long GetnNeighbor_Nodes(unsigned short val_node); //= 0;
	
//        unsigned short GetnNeighbor_Elements(void); //= 0;
	
//        unsigned short GetnNodes(void); //= 0;

//        unsigned short GetnFaces(void); //= 0;

//        unsigned short GetnNodesFace(unsigned short val_face); //= 0;
	
//        unsigned short GetMaxNodesFace(void); //= 0;

//        unsigned long GetNode(unsigned short val_node); //= 0;
  
//        void SetNode(unsigned short val_node, unsigned long val_point);
	
//        unsigned short GetFaces(unsigned short val_face, unsigned short val_index); //= 0;

//        unsigned short GetNeighbor_Nodes(unsigned short val_node, unsigned short val_index); //= 0;
};

//##MAHTAB##//
class CFace : public CPrimalGrid {
private:
    vector<unsigned long> Face;
    unsigned long nFace;
    double **Atri;

    public:

    CFace(unsigned short val_nNodes, unsigned long val_globalindex);

    ~CFace(void);
    
    long GetElems(unsigned short val_neigh);

    void SetElems(unsigned short val_neigh, long val_elem);

    unsigned short GetnNodes_Face(void);

    void SetnNodes_Face(unsigned short val_nPoint);

    unsigned long GetNode_Face(unsigned short val_node);

    void SetNode_Face(unsigned short val_node, unsigned long val_point);

    unsigned long GetGlobalFace(void);

    void SetGlobalFace(unsigned long val_globalface);

    void SetCG(unsigned short val_dim, double val_coord);

    void SetCG(double *val_coord);

    double GetCG(unsigned short val_dim);

    double *GetCG(void);

    unsigned long GetGlobalIndex(void);

    void SetGlobalIndex(unsigned long val_globalindex);

    void SetNormal_Face(unsigned short val_dim, double val_normal);

    void SetNormal_Face(double *val_normal);

    double GetNormal_Face(unsigned short val_dim);

    double *GetNormal_Face(void);

    double GetVolume_Face(void);

    void SetVolume_Face(double val_volume_face);

    void SetAtri(unsigned short val_node, unsigned short val_dim, double val_vol);

    double GetAtri(unsigned short val_vol, unsigned short val_dim);

    void SetGridVel(unsigned short val_dim, double val_gridvel);

    void SetGridVel(double *val_gridvel);

    double *GetGridVel(void);

    double GetGridVel(unsigned short val_dim);

};

class CElement : public CPrimalGrid {
private:
    vector<unsigned long> Elem;
    unsigned long nElem;
    public:

    CElement(unsigned short val_nfaces, unsigned long val_globalindex);

    ~CElement(void);

    void SetColor(unsigned short val_color);

    unsigned short GetColor(void);

    unsigned short GetnNeighbor_Face(void);

    void SetnNeighbor_Face(unsigned short val_nFace);

    long GetNeighbor_Face(unsigned short val_surf);

    void SetNeighbor_Face(long val_face, unsigned short val_surf);

    void SetCG(unsigned short val_dim, double val_coord);

    void SetCG(double *val_coord);

    double GetCG(unsigned short val_dim);

    double *GetCG(void);

    unsigned long GetGlobalIndex(void);

    void SetGlobalIndex(unsigned long val_globalindex);

    void SetDomain(bool val_domain);

    bool GetDomain(void);

    double GetVolume(void);

    void SetVolume(double val_volume);

    void SetnNeighbor_Cell(unsigned short val_nCell);

    unsigned short GetnNeighbor_Cell(void);

    long GetNeighbor_Cell(unsigned short val_cell); //= 0;

    void SetNeighbor_Cell(long val_elem, unsigned short val_cell);

    double GetWall_Distance(void);

    void SetWall_Distance(double val_wall_dist);

    double GetSharpEdge_Distance(void);

    void SetGridVel(unsigned short val_dim, double val_gridvel);

    void SetGridVel(double *val_gridvel);

    double *GetGridVel(void);

    double GetGridVel(unsigned short val_dim);

    void SetVolume_nM1(void);

    double GetVolume_nM1(void);

    void SetVolume_n(void);

    double GetVolume_n(void);

    void SetCoord_n(void);

    void SetCoord_n1(void);

    void SetCoord_p1(double *val_coord);

    double* GetCoord_n(void);

    double* GetCoord_n1(void);

    double* GetCoord_p1(void);

    void SetBoundary(unsigned short val_nmarker);

    void SetBoundary(bool val_boundary);

    bool GetBoundary(void);

    void SetPhysicalBoundary(bool val_boundary);

    void SetSolidBoundary(bool val_boundary);

    bool GetPhysicalBoundary(void);

    bool GetSolidBoundary(void);

};
//##MAHTAB##//

class CVertexMPI : public CPrimalGrid {
private:
//	static unsigned short nFaces;				/*!< \brief Number of faces of the element. */
//	static unsigned short nNodes;				/*!< \brief Number of nodes of the element. */
//	static unsigned short VTK_Type;				/*!< \brief Type of element using VTK nomenclature. */
//	unsigned short Rotation_Type;			/*!< \brief Definition of the rotation, traslation of the
//																		 solution at the vertex. */
//	static unsigned short maxNodesFace;			/*!< \brief Maximum number of nodes for a face. */
//	static unsigned short nNeighbor_Elements;	/*!< \brief Number of Neighbor_Elements. */
	
public:

	CVertexMPI(unsigned long val_point, unsigned short val_nDim);

	~CVertexMPI(void);


        unsigned long GetBound_Element(void);

        void SetBound_Element(unsigned long val_boundelem);

//	unsigned long GetNode(unsigned short val_node);
	
//      void SetNode(unsigned short val_node, unsigned long val_point);

//	unsigned short GetnNodes(void);

//	unsigned short GetVTK_Type(void);

//	unsigned short GetRotation_Type(void);

//	void SetRotation_Type(unsigned short val_rotation_type);
	
	void Change_Orientation(void);
	
//	unsigned short GetnNeighbor_Elements(void);

//	unsigned short GetnNeighbor_Nodes(unsigned short val_node);
	
//	unsigned short GetnFaces(void);
	
//	unsigned short GetnNodesFace(unsigned short val_face);
	
//	unsigned short GetMaxNodesFace(void);

//	unsigned short GetFaces(unsigned short val_face, unsigned short val_index);
	
//	unsigned short GetNeighbor_Nodes(unsigned short val_node, unsigned short val_index);
};

///*!
// * \class CLine
// * \brief Class for line element definition.
// * \author F. Palacios
// * \version 3.2.8 "eagle"
// */
//class CLine : public CPrimalGrid {
//private:
//	static unsigned short Faces[1][2];			/*!< \brief Matrix to store the local nodes of all the faces. */
//	static unsigned short Neighbor_Nodes[2][1]; /*!< \brief Neighbor to a nodes in the element. */
//	static unsigned short nNodesFace[1];		/*!< \brief Number of nodes of each face of the element. */
//	static unsigned short nNeighbor_Nodes[2];	/*!< \brief Number of Neighbor to a nodes in the element. */
//	static unsigned short nFaces;				/*!< \brief Number of faces of the element. */
//	static unsigned short nNodes;				/*!< \brief Number of nodes of the element. */
//	static unsigned short VTK_Type;				/*!< \brief Type of element using VTK nomenclature. */
//	static unsigned short maxNodesFace;			/*!< \brief Maximum number of nodes for a face. */
//	static unsigned short nNeighbor_Elements;	/*!< \brief Number of Neighbor_Elements. */
  
//public:
  
//	/*!
//	 * \brief Constructor using the nodes and index.
//	 * \param[in] val_point_0 - Index of the 1st triangle point read from the grid file.
//	 * \param[in] val_point_1 - Index of the 2nd triangle point read from the grid file.
//	 * \param[in] val_nDim - Number of dimension of the problem (2D or 3D).
//	 */
//	CLine(unsigned long val_point_0, unsigned long val_point_1, unsigned short val_nDim);
  
//  /*!
//	 * \brief Destructor of the class.
//	 */
//	~CLine(void);
  
//	/*!
//	 * \brief Get the nodes shared by the line.
//	 * \param[in] val_node - Local (to the line) index of the node (a line has 2 nodes).
//	 * \return Global index of the line node.
//	 */
//	unsigned long GetNode(unsigned short val_node);
  
//  /*!
//	 * \brief Set the point associated at a node.
//	 * \param[in] val_node - Local index of a node.
//   * \param[in] val_point - Point associated to the node.
//	 */
//  void SetNode(unsigned short val_node, unsigned long val_point);
  
//	/*!
//	 * \brief Get the face index of and element.
//	 * \param[in] val_face - Local index of the face.
//	 * \param[in] val_index - Local (to the face) index of the nodes that compose the face.
//	 * \return Local (to the line) index of the nodes that compose the face.
//	 */
//	unsigned short GetFaces(unsigned short val_face, unsigned short val_index);
  
//	/*!
//	 * \brief Get the local index of the neighbors to a node (given the local index).
//	 * \param[in] val_node - Local (to the line) index of a node.
//	 * \param[in] val_index - Local (to the neighbor nodes of val_node) index of the nodes
//   that are neighbor to val_node (each face is composed by 3 nodes).
//	 * \return Local (to the line) index of the nodes that are neighbor to val_node.
//	 */
//	unsigned short GetNeighbor_Nodes(unsigned short val_node, unsigned short val_index);
	
//	/*!
//	 * \brief Get the number of neighbors nodes of a node.
//	 * \param[in] val_node - Local (to the line) index of a node.
//	 * \return Number if neighbors of a node val_node.
//	 */
//	unsigned short GetnNeighbor_Nodes(unsigned short val_node);
  
//	/*!
//	 * \brief Get the number of nodes that composes a face of an element.
//	 * \param[in] val_face - Local index of the face.
//	 * \return Number of nodes that composes a face of an element.
//	 */
//	unsigned short GetnNodesFace(unsigned short val_face);
	
//	/*!
//	 * \brief Get the number of nodes of an element.
//	 * \return Number of nodes that composes an element.
//	 */
//	unsigned short GetnNodes(void);
  
//	/*!
//	 * \brief Get the number of faces of an element.
//	 * \return Number of faces of an element.
//	 */
//	unsigned short GetnFaces(void);
  
//	/*!
//	 * \brief Get the Maximum number of nodes of a face of an element.
//	 * \return Maximum number of nodes of a face of an element.
//	 */
//	unsigned short GetMaxNodesFace(void);
  
//	/*!
//	 * \brief Get the type of the element using VTK nomenclature.
//	 * \return Type of the element using VTK nomenclature.
//	 */
//	unsigned short GetVTK_Type(void);
	
//	/*!
//	 * \brief Get the number of element that are neighbor to this element.
//	 * \return Number of neighbor elements.
//	 */
//	unsigned short GetnNeighbor_Elements(void);
  
//	/*!
//	 * \brief Set the domain element which shares a face with the boundary element.
//	 * \param[in] val_domainelement - Global index of the element.
//	 */
//	void SetDomainElement(unsigned long val_domainelement);
	
//	/*!
//	 * \brief Get the domain element which shares a face with the boundary element.
//	 * \return Domain element which shares a face with the boundary element.
//	 */
//	unsigned long GetDomainElement(void);
	
//	/*!
//	 * \brief Change the orientation of an element.
//	 */
//	void Change_Orientation(void);
//};

///*!
// * \class CTriangle
// * \brief Class for triangle element definition.
// * \author F. Palacios
// * \version 3.2.8 "eagle"
// */
//class CTriangle : public CPrimalGrid {
//private:
//	static unsigned short Faces[3][2];			/*!< \brief Matrix to store the local nodes of all the faces. */
//	static unsigned short Neighbor_Nodes[3][2];	/*!< \brief Neighbor to a nodes in the element. */
//	static unsigned short nNodesFace[3];		/*!< \brief Number of nodes of each face of the element. */
//	static unsigned short nNeighbor_Nodes[3];	/*!< \brief Number of Neighbor to a nodes in the element. */
//	static unsigned short nFaces;				/*!< \brief Number of faces of the element. */
//	static unsigned short nNodes;				/*!< \brief Number of nodes of the element. */
//	static unsigned short VTK_Type;				/*!< \brief Type of element using VTK nomenclature. */
//	static unsigned short maxNodesFace;			/*!< \brief Maximum number of nodes for a face. */
//	static unsigned short nNeighbor_Elements;	/*!< \brief Number of Neighbor_Elements. */
  
//public:
	
//	/*!
//	 * \brief Constructor using the nodes and index.
//	 * \param[in] val_point_0 - Index of the 1st triangle point read from the grid file.
//	 * \param[in] val_point_1 - Index of the 2nd triangle point read from the grid file.
//	 * \param[in] val_point_2 - Index of the 3th triangle point read from the grid file.
//	 * \param[in] val_nDim - Number of dimension of the problem (2D or 3D), be careful a triangle could be 2D or 3D.
//	 */
//	CTriangle(unsigned long val_point_0, unsigned long val_point_1,
//            unsigned long val_point_2, unsigned short val_nDim);
  
//  /*!
//	 * \brief Destructor of the class.
//	 */
//	~CTriangle(void);
	
//	/*!
//	 * \brief Get the nodes shared by the triangle.
//	 * \param[in] val_node - Local (to the triangle) index of the node (a triangle has 3 nodes).
//	 * \return Global index of the triangle node.
//	 */
//	unsigned long GetNode(unsigned short val_node);
  
//  /*!
//	 * \brief Set the point associated at a node.
//	 * \param[in] val_node - Local index of a node.
//   * \param[in] val_point - Point associated to the node.
//	 */
//  void SetNode(unsigned short val_node, unsigned long val_point);
  
//	/*!
//	 * \brief Get the face index of and element.
//	 * \param[in] val_face - Local index of the face.
//	 * \param[in] val_index - Local (to the face) index of the nodes that compose the face.
//	 * \return Local (to the triangle) index of the nodes that compose the face.
//	 */
//	unsigned short GetFaces(unsigned short val_face, unsigned short val_index);
	
//	/*!
//	 * \brief Get the local index of the neighbors to a node (given the local index).
//	 * \param[in] val_node - Local (to the triangle) index of a node.
//	 * \param[in] val_index - Local (to the neighbor nodes of val_node) index of the nodes that
//   are neighbor to val_node (each face is composed by 3 nodes).
//	 * \return Local (to the triangle) index of the nodes that are neighbor to val_node.
//	 */
//	unsigned short GetNeighbor_Nodes(unsigned short val_node, unsigned short val_index);
  
//	/*!
//	 * \brief Get the number of neighbors nodes of a node.
//	 * \param[in] val_node - Local (to the triangle) index of a node.
//	 * \return Number if neighbors of a node val_node.
//	 */
//	unsigned short GetnNeighbor_Nodes(unsigned short val_node);
	
//	/*!
//	 * \brief Get the number of nodes that composes a face of an element.
//	 * \param[in] val_face - Local index of the face.
//	 * \return Number of nodes that composes a face of an element.
//	 */
//	unsigned short GetnNodesFace(unsigned short val_face);
	
//	/*!
//	 * \brief Get the number of nodes of an element.
//	 * \return Number of nodes that composes an element.
//	 */
//	unsigned short GetnNodes(void);
  
//	/*!
//	 * \brief Get the number of faces of an element.
//	 * \return Number of faces of an element.
//	 */
//	unsigned short GetnFaces(void);
  
//	/*!
//	 * \brief Get the Maximum number of nodes of a face of an element.
//	 * \return Maximum number of nodes of a face of an element.
//	 */
//	unsigned short GetMaxNodesFace(void);
  
//	/*!
//	 * \brief Get the type of the element using VTK nomenclature.
//	 * \return Type of the element using VTK nomenclature.
//	 */
//	unsigned short GetVTK_Type(void);
  
//	/*!
//	 * \brief Get the number of element that are neighbor to this element.
//	 * \return Number of neighbor elements.
//	 */
//	unsigned short GetnNeighbor_Elements(void);
  
//	/*!
//	 * \brief Change the orientation of an element.
//	 */
//	void Change_Orientation(void);
	
//	/*!
//	 * \brief Set the domain element which shares a face with the boundary element.
//	 * \param[in] val_domainelement - Global index of the element.
//	 */
//	void SetDomainElement(unsigned long val_domainelement);
	
//	/*!
//	 * \brief Get the domain element which shares a face with the boundary element.
//	 * \return Domain element which shares a face with the boundary element.
//	 */
//	unsigned long GetDomainElement(void);
//};

///*!
// * \class CRectangle
// * \brief Class for rectangle element definition.
// * \author F. Palacios
// * \version 3.2.8 "eagle"
// */
//class CRectangle : public CPrimalGrid {
//private:
//	static unsigned short Faces[4][2];			/*!< \brief Matrix to store the local nodes of all the faces. */
//	static unsigned short Neighbor_Nodes[4][2];	/*!< \brief Neighbor to a nodes in the element. */
//	static unsigned short nNodesFace[4];		/*!< \brief Number of nodes of each face of the element. */
//	static unsigned short nNeighbor_Nodes[4];	/*!< \brief Number of Neighbor to a nodes in the element. */
//	static unsigned short nFaces;				/*!< \brief Number of faces of the element. */
//	static unsigned short nNodes;				/*!< \brief Number of nodes of the element. */
//	static unsigned short VTK_Type;				/*!< \brief Type of element using VTK nomenclature. */
//	static unsigned short maxNodesFace;			/*!< \brief Maximum number of nodes for a face. */
//	static unsigned short nNeighbor_Elements;	/*!< \brief Number of neighbor elements. */
  
//public:
  
//	/*!
//	 * \brief Constructor using the nodes and index.
//	 * \param[in] val_point_0 - Index of the 1st point read from the grid file.
//	 * \param[in] val_point_1 - Index of the 2nd point read from the grid file.
//	 * \param[in] val_point_2 - Index of the 3th point read from the grid file.
//	 * \param[in] val_point_3 - Index of the 4th point read from the grid file.
//	 * \param[in] val_nDim - Number of dimension of the problem (2D or 3D).
//	 */
//	CRectangle(unsigned long val_point_0, unsigned long val_point_1,
//             unsigned long val_point_2, unsigned long val_point_3, unsigned short val_nDim);
  
//  /*!
//	 * \brief Destructor of the class.
//	 */
//	~CRectangle(void);
  
//	/*!
//	 * \brief Get the nodes shared by the triangle.
//	 * \param[in] val_node - Local (to the rectangle) index of the node (a rectangle has 4 nodes).
//	 * \return Global index of the triangle node.
//	 */
//	unsigned long GetNode(unsigned short val_node);
  
//  /*!
//	 * \brief Set the point associated at a node.
//	 * \param[in] val_node - Local index of a node.
//   * \param[in] val_point - Point associated to the node.
//	 */
//  void SetNode(unsigned short val_node, unsigned long val_point);
  
//	/*!
//	 * \brief Get the face index of and element.
//	 * \param[in] val_face - Local index of the face.
//	 * \param[in] val_index - Local (to the face) index of the nodes that compose the face.
//	 * \return Local (to the rectangle) index of the nodes that compose the face.
//	 */
//	unsigned short GetFaces(unsigned short val_face, unsigned short val_index);
  
//	/*!
//	 * \brief Get the local index of the neighbors to a node (given the local index).
//	 * \param[in] val_node - Local (to the element) index of a node.
//	 * \param[in] val_index - Local (to the neighbor nodes of val_node) index of the nodes that are neighbor to val_node.
//	 * \return Local (to the rectangle) index of the nodes that are neighbor to val_node.
//	 */
//	unsigned short GetNeighbor_Nodes(unsigned short val_node, unsigned short val_index);
  
//	/*!
//	 * \brief Get the number of neighbors nodes of a node.
//	 * \param[in] val_node - Local (to the element) index of a node.
//	 * \return Number if neighbors of a node val_node.
//	 */
//	unsigned short GetnNeighbor_Nodes(unsigned short val_node);
	
//	/*!
//	 * \brief Get the number of nodes that composes a face of an element.
//	 * \param[in] val_face - Local index of the face.
//	 * \return Number of nodes that composes a face of an element.
//	 */
//	unsigned short GetnNodesFace(unsigned short val_face);
	
//	/*!
//	 * \brief Get the number of nodes of an element.
//	 * \return Number of nodes that composes an element.
//	 */
//	unsigned short GetnNodes(void);
	
//	/*!
//	 * \brief Get the number of faces of an element.
//	 * \return Number of faces of an element.
//	 */
//	unsigned short GetnFaces(void);
	
//	/*!
//	 * \brief Get the Maximum number of nodes of a face of an element.
//	 * \return Maximum number of nodes of a face of an element.
//	 */
//	unsigned short GetMaxNodesFace(void);
	
//	/*!
//	 * \brief Get the type of the element using VTK nomenclature.
//	 * \return Type of the element using VTK nomenclature.
//	 */
//	unsigned short GetVTK_Type(void);
	
//	/*!
//	 * \brief Get the number of element that are neighbor to this element.
//	 * \return Number of neighbor elements.
//	 */
//	unsigned short GetnNeighbor_Elements(void);
	
//	/*!
//	 * \brief Change the orientation of an element.
//	 */
//	void Change_Orientation(void);
	
//	/*!
//	 * \brief Set the domain element which shares a face with the boundary element.
//	 * \param[in] val_domainelement - Global index of the element.
//	 */
//	void SetDomainElement(unsigned long val_domainelement);
	
//	/*!
//	 * \brief Get the domain element which shares a face with the boundary element.
//	 * \return Domain element which shares a face with the boundary element.
//	 */
//	unsigned long GetDomainElement(void);
//};

///*!
// * \class CTetrahedron
// * \brief Class for tetrahedron element definition.
// * \author F. Palacios
// * \version 3.2.8 "eagle"
// */
//class CTetrahedron : public CPrimalGrid {
//private:
//	static unsigned short Faces[4][3];			/*!< \brief Matrix to store the local nodes of all the faces. */
//	static unsigned short Neighbor_Nodes[4][3];	/*!< \brief Neighbor to a nodes in the element. */
//	static unsigned short nNodesFace[4];		/*!< \brief Number of nodes of each face of the element. */
//	static unsigned short nNeighbor_Nodes[4];	/*!< \brief Number of Neighbor to a nodes in the element. */
//	static unsigned short nFaces;				/*!< \brief Number of faces of the element. */
//	static unsigned short nNodes;				/*!< \brief Number of nodes of the element. */
//	static unsigned short VTK_Type;				/*!< \brief Type of element using VTK nomenclature. */
//	static unsigned short maxNodesFace;			/*!< \brief Maximum number of nodes for a face. */
//	static unsigned short nNeighbor_Elements;	/*!< \brief Number of neighbor elements. */
	
//public:
  
//	/*!
//	 * \brief Constructor using the nodes and index.
//	 * \param[in] val_point_0 - Index of the 1st point read from the grid file.
//	 * \param[in] val_point_1 - Index of the 2nd point read from the grid file.
//	 * \param[in] val_point_2 - Index of the 3th point read from the grid file.
//	 * \param[in] val_point_3 - Index of the 4th point read from the grid file.
//	 */
//	CTetrahedron(unsigned long val_point_0, unsigned long val_point_1,
//               unsigned long val_point_2, unsigned long val_point_3);
  
//  /*!
//	 * \brief Destructor of the class.
//	 */
//	~CTetrahedron(void);
  
//	/*!
//	 * \brief Get the nodes shared by the tetrahedron.
//	 * \param[in] val_node - Local (to the tetrahedron) index of the node (a tetrahedron has 4 nodes).
//	 * \return Global index of the tetrahedron node.
//	 */
//	unsigned long GetNode(unsigned short val_node);
  
//  /*!
//	 * \brief Set the point associated at a node.
//	 * \param[in] val_node - Local index of a node.
//   * \param[in] val_point - Point associated to the node.
//	 */
//  void SetNode(unsigned short val_node, unsigned long val_point);
	
//	/*!
//	 * \brief Get the face index of and element.
//	 * \param[in] val_face - Local index of the face.
//	 * \param[in] val_index - Local (to the face) index of the nodes that compose the face.
//	 * \return Local (to the element) index of the nodes that compose the face.
//	 */
//	unsigned short GetFaces(unsigned short val_face, unsigned short val_index);
	
//	/*!
//	 * \brief Get the local index of the neighbors to a node (given the local index).
//	 * \param[in] val_node - Local (to the element) index of a node.
//	 * \param[in] val_index - Local (to the neighbor nodes of val_node) index of the nodes that are neighbor to val_node.
//	 * \return Local (to the element) index of the nodes that are neighbor to val_node.
//	 */
//	unsigned short GetNeighbor_Nodes(unsigned short val_node, unsigned short val_index);
	
//	/*!
//	 * \brief Get the number of neighbors nodes of a node.
//	 * \param[in] val_node - Local (to the element) index of a node.
//	 * \return Number if neighbors of a node val_node.
//	 */
//	unsigned short GetnNeighbor_Nodes(unsigned short val_node);
  
//	/*!
//	 * \brief Get the number of nodes that composes a face of an element.
//	 * \param[in] val_face - Local index of the face.
//	 * \return Number of nodes that composes a face of an element.
//	 */
//	unsigned short GetnNodesFace(unsigned short val_face);
	
//	/*!
//	 * \brief Get the number of nodes of an element.
//	 * \return Number of nodes that composes an element.
//	 */
//	unsigned short GetnNodes(void);
	
//	/*!
//	 * \brief Get the number of faces of an element.
//	 * \return Number of faces of an element.
//	 */
//	unsigned short GetnFaces(void);
	
//	/*!
//	 * \brief Get the Maximum number of nodes of a face of an element.
//	 * \return Maximum number of nodes of a face of an element.
//	 */
//	unsigned short GetMaxNodesFace(void);
	
//	/*!
//	 * \brief Get the type of the element using VTK nomenclature.
//	 * \return Type of the element using VTK nomenclature.
//	 */
//	unsigned short GetVTK_Type(void);
	
//	/*!
//	 * \brief Get the number of element that are neighbor to this element.
//	 * \return Number of neighbor elements.
//	 */
//	unsigned short GetnNeighbor_Elements(void);
	
//	/*!
//	 * \brief Change the orientation of an element.
//	 */
//	void Change_Orientation(void);
//};

///*!
// * \class CHexahedron
// * \brief Class for hexahedron element definition.
// * \author F. Palacios
// * \version 3.2.8 "eagle"
// */
//class CHexahedron : public CPrimalGrid {
//private:
//	static unsigned short Faces[6][4];			/*!< \brief Matrix to store the local nodes of all the faces. */
//	static unsigned short Neighbor_Nodes[8][3];	/*!< \brief Neighbor to a nodes in the element. */
//	static unsigned short nNodesFace[6];		/*!< \brief Number of nodes of each face of the element. */
//	static unsigned short nNeighbor_Nodes[8];	/*!< \brief Number of Neighbor to a nodes in the element. */
//	static unsigned short nFaces;				/*!< \brief Number of faces of the element. */
//	static unsigned short nNodes;				/*!< \brief Number of nodes of the element. */
//	static unsigned short VTK_Type;				/*!< \brief Type of element using VTK nomenclature. */
//	static unsigned short maxNodesFace;			/*!< \brief Maximum number of nodes for a face. */
//	static unsigned short nNeighbor_Elements;	/*!< \brief Number of neighbor elements. */
  
//public:
	
//	/*!
//	 * \brief Constructor using the nodes and index.
//	 * \param[in] val_point_0 - Index of the 1st point read from the grid file.
//	 * \param[in] val_point_1 - Index of the 2nd point read from the grid file.
//	 * \param[in] val_point_2 - Index of the 3th point read from the grid file.
//	 * \param[in] val_point_3 - Index of the 4th point read from the grid file.
//	 * \param[in] val_point_4 - Index of the 5td point read from the grid file.
//	 * \param[in] val_point_5 - Index of the 6th point read from the grid file.
//	 * \param[in] val_point_6 - Index of the 7th point read from the grid file.
//	 * \param[in] val_point_7 - Index of the 8th point read from the grid file.
//	 */
//	CHexahedron(unsigned long val_point_0, unsigned long val_point_1,
//              unsigned long val_point_2, unsigned long val_point_3,
//              unsigned long val_point_4, unsigned long val_point_5,
//              unsigned long val_point_6, unsigned long val_point_7);
  
//  /*!
//	 * \brief Destructor of the class.
//	 */
//	~CHexahedron(void);
  
//	/*!
//	 * \brief Get the nodes shared by the triangle.
//	 * \param[in] val_node - Local (to the triangle) index of the node (a triangle has 3 nodes).
//	 * \return Global index of the triangle node.
//	 */
//	unsigned long GetNode(unsigned short val_node);
  
//  /*!
//	 * \brief Set the point associated at a node.
//	 * \param[in] val_node - Local index of a node.
//   * \param[in] val_point - Point associated to the node.
//	 */
//  void SetNode(unsigned short val_node, unsigned long val_point);
	
//	/*!
//	 * \brief Get the face index of and element.
//	 * \param[in] val_face - Local index of the face.
//	 * \param[in] val_index - Local (to the face) index of the nodes that compose the face.
//	 * \return Local (to the element) index of the nodes that compose the face.
//	 */
//	unsigned short GetFaces(unsigned short val_face, unsigned short val_index);
	
//	/*!
//	 * \brief Get the local index of the neighbors to a node (given the local index).
//	 * \param[in] val_node - Local (to the element) index of a node.
//	 * \param[in] val_index - Local (to the neighbor nodes of val_node) index of the nodes
//	 *            that are neighbor to val_node.
//	 * \return Local (to the element) index of the nodes that are neighbor to val_node.
//	 */
//	unsigned short GetNeighbor_Nodes(unsigned short val_node, unsigned short val_index);
  
//	/*!
//	 * \brief Get the number of neighbors nodes of a node.
//	 * \param[in] val_node - Local (to the element) index of a node.
//	 * \return Number if neighbors of a node val_node.
//	 */
//	unsigned short GetnNeighbor_Nodes(unsigned short val_node);
  
//	/*!
//	 * \brief Get the number of nodes that composes a face of an element.
//	 * \param[in] val_face - Local index of the face.
//	 * \return Number of nodes that composes a face of an element.
//	 */
//	unsigned short GetnNodesFace(unsigned short val_face);
	
//	/*!
//	 * \brief Get the number of nodes of an element.
//	 * \return Number of nodes that composes an element.
//	 */
//	unsigned short GetnNodes(void);
	
//	/*!
//	 * \brief Get the number of faces of an element.
//	 * \return Number of faces of an element.
//	 */
//	unsigned short GetnFaces(void);
	
//	/*!
//	 * \brief Get the Maximum number of nodes of a face of an element.
//	 * \return Maximum number of nodes of a face of an element.
//	 */
//	unsigned short GetMaxNodesFace(void);
	
//	/*!
//	 * \brief Get the type of the element using VTK nomenclature.
//	 * \return Type of the element using VTK nomenclature.
//	 */
//	unsigned short GetVTK_Type(void);
	
//	/*!
//	 * \brief Get the number of element that are neighbor to this element.
//	 * \return Number of neighbor elements.
//	 */
//	unsigned short GetnNeighbor_Elements(void);
	
//	/*!
//	 * \brief Change the orientation of an element.
//	 */
//	void Change_Orientation(void);
//};

///*!
// * \class CWedge
// * \brief Class for wedge element definition.
// * \author F. Palacios
// * \version 3.2.8 "eagle"
// */
//class CWedge : public CPrimalGrid {
//private:
//	static unsigned short Faces[5][4];			/*!< \brief Matrix to store the local nodes of all the faces. */
//	static unsigned short Neighbor_Nodes[6][3];	/*!< \brief Neighbor to a nodes in the element. */
//	static unsigned short nNodesFace[5];		/*!< \brief Number of nodes of each face of the element. */
//	static unsigned short nNeighbor_Nodes[6];	/*!< \brief Number of Neighbor to a nodes in the element. */
//	static unsigned short nFaces;				/*!< \brief Number of faces of the element. */
//	static unsigned short nNodes;				/*!< \brief Number of nodes of the element. */
//	static unsigned short VTK_Type;				/*!< \brief Type of element using VTK nomenclature. */
//	static unsigned short maxNodesFace;			/*!< \brief Maximum number of nodes for a face. */
//	static unsigned short nNeighbor_Elements;	/*!< \brief Number of neighbor elements. */
	
//public:
	
//	/*!
//	 * \brief Constructor using the nodes and index.
//	 * \param[in] val_point_0 - Index of the 1st point read from the grid file.
//	 * \param[in] val_point_1 - Index of the 2nd point read from the grid file.
//	 * \param[in] val_point_2 - Index of the 3th point read from the grid file.
//	 * \param[in] val_point_3 - Index of the 4th point read from the grid file.
//	 * \param[in] val_point_4 - Index of the 5th point read from the grid file.
//	 * \param[in] val_point_5 - Index of the 6th point read from the grid file.
//	 */
//	CWedge(unsigned long val_point_0, unsigned long val_point_1,
//         unsigned long val_point_2, unsigned long val_point_3,
//         unsigned long val_point_4, unsigned long val_point_5);
  
//  /*!
//	 * \brief Destructor of the class.
//	 */
//	~CWedge(void);
  
//	/*!
//	 * \brief Get the nodes shared by the triangle.
//	 * \param[in] val_node - Local (to the triangle) index of the node (a wedge has 6 nodes).
//	 * \return Global index of the wedge node.
//	 */
//	unsigned long GetNode(unsigned short val_node);
  
//  /*!
//	 * \brief Set the point associated at a node.
//	 * \param[in] val_node - Local index of a node.
//   * \param[in] val_point - Point associated to the node.
//	 */
//  void SetNode(unsigned short val_node, unsigned long val_point);
	
//	/*!
//	 * \brief Get the face index of and element.
//	 * \param[in] val_face - Local index of the face.
//	 * \param[in] val_index - Local (to the face) index of the nodes that compose the face.
//	 * \return Local (to the element) index of the nodes that compose the face.
//	 */
//	unsigned short GetFaces(unsigned short val_face, unsigned short val_index);
	
//	/*!
//	 * \brief Get the local index of the neighbors to a node (given the local index).
//	 * \param[in] val_node - Local (to the element) index of a node.
//	 * \param[in] val_index - Local (to the neighbor nodes of val_node) index of the nodes that are neighbor to val_node.
//	 * \return Local (to the element) index of the nodes that are neighbor to val_node.
//	 */
//	unsigned short GetNeighbor_Nodes(unsigned short val_node, unsigned short val_index);
	
//	/*!
//	 * \brief Get the number of neighbors nodes of a node.
//	 * \param[in] val_node - Local (to the element) index of a node.
//	 * \return Number if neighbors of a node val_node.
//	 */
//	unsigned short GetnNeighbor_Nodes(unsigned short val_node);
	
//	/*!
//	 * \brief Get the number of nodes that composes a face of an element.
//	 * \param[in] val_face - Local index of the face.
//	 * \return Number of nodes that composes a face of an element.
//	 */
//	unsigned short GetnNodesFace(unsigned short val_face);
	
//	/*!
//	 * \brief Get the number of nodes of an element.
//	 * \return Number of nodes that composes an element.
//	 */
//	unsigned short GetnNodes(void);
	
//	/*!
//	 * \brief Get the number of faces of an element.
//	 * \return Number of faces of an element.
//	 */
//	unsigned short GetnFaces(void);
	
//	/*!
//	 * \brief Get the Maximum number of nodes of a face of an element.
//	 * \return Maximum number of nodes of a face of an element.
//	 */
//	unsigned short GetMaxNodesFace(void);
	
//	/*!
//	 * \brief Get the type of the element using VTK nomenclature.
//	 * \return Type of the element using VTK nomenclature.
//	 */
//	unsigned short GetVTK_Type(void);
	
//	/*!
//	 * \brief Get the number of element that are neighbor to this element.
//	 * \return Number of neighbor elements.
//	 */
//	unsigned short GetnNeighbor_Elements(void);
	
//	/*!
//	 * \brief Change the orientation of an element.
//	 */
//	void Change_Orientation(void);
//};

///*!
// * \class CPyramid
// * \brief Class for pyramid element definition.
// * \author F. Palacios
// * \version 3.2.8 "eagle"
// */
//class CPyramid : public CPrimalGrid {
//private:
//	static unsigned short Faces[5][4];			/*!< \brief Matrix to store the local nodes of all the faces. */
//	static unsigned short Neighbor_Nodes[5][4];	/*!< \brief Neighbor to a nodes in the element. */
//	static unsigned short nNodesFace[5];		/*!< \brief Number of nodes of each face of the element. */
//	static unsigned short nNeighbor_Nodes[5];	/*!< \brief Number of Neighbor to a nodes in the element. */
//	static unsigned short nFaces;				/*!< \brief Number of faces of the element. */
//	static unsigned short nNodes;				/*!< \brief Number of nodes of the element. */
//	static unsigned short VTK_Type;				/*!< \brief Type of element using VTK nomenclature. */
//	static unsigned short maxNodesFace;			/*!< \brief Maximum number of nodes for a face. */
//	static unsigned short nNeighbor_Elements;	/*!< \brief Number of neighbor elements. */
	
//public:
	
//	/*!
//	 * \brief Constructor using the nodes and index.
//	 * \param[in] val_point_0 - Index of the 1st point read from the grid file.
//	 * \param[in] val_point_1 - Index of the 2nd point read from the grid file.
//	 * \param[in] val_point_2 - Index of the 3th point read from the grid file.
//	 * \param[in] val_point_3 - Index of the 4th point read from the grid file.
//	 * \param[in] val_point_4 - Index of the 5th point read from the grid file.
//	 */
//	CPyramid(unsigned long val_point_0, unsigned long val_point_1,
//           unsigned long val_point_2, unsigned long val_point_3,
//           unsigned long val_point_4);
  
//  /*!
//	 * \brief Destructor of the class.
//	 */
//	~CPyramid(void);
  
//	/*!
//	 * \brief Get the nodes shared by the pyramid.
//	 * \param[in] val_node - Local (to the pyramid) index of the node (a pyramid has 3 nodes).
//	 * \return Global index of the pyramid node.
//	 */
//	unsigned long GetNode(unsigned short val_node);
  
//  /*!
//	 * \brief Set the point associated at a node.
//	 * \param[in] val_node - Local index of a node.
//   * \param[in] val_point - Point associated to the node.
//	 */
//  void SetNode(unsigned short val_node, unsigned long val_point);
	
//	/*!
//	 * \brief Get the face index of and element.
//	 * \param[in] val_face - Local index of the face.
//	 * \param[in] val_index - Local (to the face) index of the nodes that compose the face.
//	 * \return Local (to the element) index of the nodes that compose the face.
//	 */
//	unsigned short GetFaces(unsigned short val_face, unsigned short val_index);
	
//	/*!
//	 * \brief Get the local index of the neighbors to a node (given the local index).
//	 * \param[in] val_node - Local (to the element) index of a node.
//	 * \param[in] val_index - Local (to the neighbor nodes of val_node) index of the nodes that are neighbor to val_node.
//	 * \return Local (to the element) index of the nodes that are neighbor to val_node.
//	 */
//	unsigned short GetNeighbor_Nodes(unsigned short val_node, unsigned short val_index);
	
//	/*!
//	 * \brief Get the number of neighbors nodes of a node.
//	 * \param[in] val_node - Local (to the element) index of a node.
//	 * \return Number if neighbors of a node val_node.
//	 */
//	unsigned short GetnNeighbor_Nodes(unsigned short val_node);
	
//	/*!
//	 * \brief Get the number of nodes that composes a face of an element.
//	 * \param[in] val_face - Local index of the face.
//	 * \return Number of nodes that composes a face of an element.
//	 */
//	unsigned short GetnNodesFace(unsigned short val_face);
	
//	/*!
//	 * \brief Get the number of nodes of an element.
//	 * \return Number of nodes that composes an element.
//	 */
//	unsigned short GetnNodes(void);
	
//	/*!
//	 * \brief Get the number of faces of an element.
//	 * \return Number of faces of an element.
//	 */
//	unsigned short GetnFaces(void);
	
//	/*!
//	 * \brief Get the Maximum number of nodes of a face of an element.
//	 * \return Maximum number of nodes of a face of an element.
//	 */
//	unsigned short GetMaxNodesFace(void);
	
//	/*!
//	 * \brief Get the type of the element using VTK nomenclature.
//	 * \return Type of the element using VTK nomenclature.
//	 */
//	unsigned short GetVTK_Type(void);
	
//	/*!
//	 * \brief Get the number of element that are neighbor to this element.
//	 * \return Number of neighbor elements.
//	 */
//	unsigned short GetnNeighbor_Elements(void);
	
//	/*!
//	 * \brief Change the orientation of an element.
//	 */
//	void Change_Orientation(void);
//};

#include "primal_grid_structure.inl"
