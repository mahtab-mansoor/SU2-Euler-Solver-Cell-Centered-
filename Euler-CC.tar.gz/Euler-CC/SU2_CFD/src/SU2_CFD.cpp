/*!
 * \file SU2_CFD.cpp
 * \brief Main file of the Computational Fluid Dynamics code
 * \author F. Palacios, T. Economon
 * \version 3.2.8 "eagle"
 *
 * SU2 Lead Developers: Dr. Francisco Palacios (fpalacios@stanford.edu).
 *                      Dr. Thomas D. Economon (economon@stanford.edu).
 *
 * SU2 Developers: Prof. Juan J. Alonso's group at Stanford University.
 *                 Prof. Piero Colonna's group at Delft University of Technology.
 *                 Prof. Nicolas R. Gauger's group at Kaiserslautern University of Technology.
 *                 Prof. Alberto Guardone's group at Polytechnic University of Milan.
 *                 Prof. Rafael Palacios' group at Imperial College London.
 *
 * Copyright (C) 2012-2015 SU2, the open-source CFD code.
 *
 * SU2 is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * SU2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with SU2. If not, see <http://www.gnu.org/licenses/>.
 */

#include "../include/SU2_CFD.hpp"

using namespace std;

int main(int argc, char *argv[]) {
  
  bool StopCalc = false;
  double StartTime = 0.0, StopTime = 0.0, UsedTime = 0.0;
  unsigned long ExtIter = 0;
  unsigned short iMesh, iZone, iSol, nZone, nDim;
  char config_file_name[MAX_STRING_SIZE];
  char runtime_file_name[MAX_STRING_SIZE];
  ofstream ConvHist_file;
  int rank = MASTER_NODE;
  int size = SINGLE_NODE;
  
#ifdef HAVE_MPI
  int *bptr, bl;
  MPI_Init(&argc,&argv);
  MPI_Buffer_attach( malloc(BUFSIZE), BUFSIZE );
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);
#endif
  
  COutput *output                       = NULL;
  CIntegration ***integration_container = NULL;
  CGeometry ***geometry_container       = NULL;
  CSolver ****solver_container          = NULL;
  CNumerics *****numerics_container     = NULL;
  CConfig **config_container            = NULL;
  CSurfaceMovement **surface_movement   = NULL;
  CVolumetricMovement **grid_movement   = NULL;
  CFreeFormDefBox*** FFDBox             = NULL;
  
  if (argc == 2){ strcpy(config_file_name,argv[1]); }
  else { strcpy(config_file_name, "default.cfg"); }
  
  CConfig *config = NULL;
  config = new CConfig(config_file_name, SU2_CFD);
  
  nZone = 1;//GetnZone(config->GetMesh_FileName(), config->GetMesh_FileFormat(), config);
  nDim  = 3;//GetnDim(config->GetMesh_FileName(), config->GetMesh_FileFormat());
    
  solver_container      = new CSolver***[nZone];
  integration_container = new CIntegration**[nZone];
  numerics_container    = new CNumerics****[nZone];
  config_container      = new CConfig*[nZone];
  geometry_container    = new CGeometry**[nZone];
  surface_movement      = new CSurfaceMovement*[nZone];
  grid_movement         = new CVolumetricMovement*[nZone];
  FFDBox                = new CFreeFormDefBox**[nZone];
  
  for (iZone = 0; iZone < nZone; iZone++) {
    solver_container[iZone]       = NULL;
    integration_container[iZone]  = NULL;
    numerics_container[iZone]     = NULL;
    config_container[iZone]       = NULL;
    geometry_container[iZone]     = NULL;
    surface_movement[iZone]       = NULL;
    grid_movement[iZone]          = NULL;
    FFDBox[iZone]                 = NULL;
  }
  
  for (iZone = 0; iZone < nZone; iZone++) {
    
    config_container[iZone] = new CConfig(config_file_name, SU2_CFD, iZone, nZone, nDim, VERB_HIGH);
    
    CGeometry *geometry_aux = NULL;

    if (rank == MASTER_NODE) {
            
      geometry_aux = new CPhysicalGeometry(config_container[iZone], iZone, nZone);

      geometry_aux->SetColorGrid(config_container[iZone]);
    }
    geometry_container[iZone] = new CGeometry *[config_container[iZone]->GetnMGLevels()+1];

    geometry_container[iZone][MESH_0] = new CPhysicalGeometry(geometry_aux, config_container[iZone]);

    delete geometry_aux;

    geometry_container[iZone][MESH_0]->SetSendReceive(config_container[iZone]);
    
    geometry_container[iZone][MESH_0]->SetBoundaries(config_container[iZone]);

  }
  
  if (rank == MASTER_NODE)
    cout << endl <<"------------------------- Geometry Preprocessing ------------------------" << endl;
  
  Geometrical_Preprocessing(geometry_container, config_container, nZone);
  
  if (rank == MASTER_NODE)
    cout << endl <<"------------------------- Solver Preprocessing --------------------------" << endl;

  
  for (iZone = 0; iZone < nZone; iZone++) {
        
    if ( (config_container[iZone]->GetKind_Solver() == RANS) ||
        (config_container[iZone]->GetKind_Solver() == ADJ_RANS) ){
      geometry_container[iZone][MESH_0]->ComputeWall_Distance(config_container[iZone]);
    }

    geometry_container[iZone][MESH_0]->SetPositive_ZArea(config_container[iZone]);
        
    for (iMesh = 0; iMesh <= config_container[iZone]->GetnMGLevels(); iMesh++) {
      //geometry_container[iZone][iMesh]->MatchNearField(config_container[iZone]);
      //geometry_container[iZone][iMesh]->MatchInterface(config_container[iZone]);
      //geometry_container[iZone][iMesh]->MatchActuator_Disk(config_container[iZone]);
    }

    solver_container[iZone] = new CSolver** [config_container[iZone]->GetnMGLevels()+1];
    for (iMesh = 0; iMesh <= config_container[iZone]->GetnMGLevels(); iMesh++)
      solver_container[iZone][iMesh] = NULL;
    
    for (iMesh = 0; iMesh <= config_container[iZone]->GetnMGLevels(); iMesh++) {
      solver_container[iZone][iMesh] = new CSolver* [MAX_SOLS];
      for (iSol = 0; iSol < MAX_SOLS; iSol++){
        solver_container[iZone][iMesh][iSol] = NULL;
      }
    }

    Solver_Preprocessing(solver_container[iZone], geometry_container[iZone],
                         config_container[iZone], iZone);

    if (rank == MASTER_NODE)
      cout << endl <<"----------------- Integration and Numerics Preprocessing ----------------" << endl;
    
    integration_container[iZone] = new CIntegration*[MAX_SOLS];
    Integration_Preprocessing(integration_container[iZone], geometry_container[iZone],
                              config_container[iZone], iZone);
    
    if (rank == MASTER_NODE) cout << "Integration Preprocessing." << endl;
    
    numerics_container[iZone] = new CNumerics***[config_container[iZone]->GetnMGLevels()+1];
    Numerics_Preprocessing(numerics_container[iZone], solver_container[iZone],
                           geometry_container[iZone], config_container[iZone], iZone);
    
    if (rank == MASTER_NODE) cout << "Numerics Preprocessing." << endl;

//    if (config_container[iZone]->GetGrid_Movement()) {
//      if (rank == MASTER_NODE)
//        cout << "Setting dynamic mesh structure." << endl;
//      grid_movement[iZone] = new CVolumetricMovement(geometry_container[iZone][MESH_0]);
//      FFDBox[iZone] = new CFreeFormDefBox*[MAX_NUMBER_FFD];
//      surface_movement[iZone] = new CSurfaceMovement();
//      surface_movement[iZone]->CopyBoundary(geometry_container[iZone][MESH_0], config_container[iZone]);
//      if (config_container[iZone]->GetUnsteady_Simulation() == TIME_SPECTRAL)
//        SetGrid_Movement(geometry_container[iZone], surface_movement[iZone], grid_movement[iZone],
//                         FFDBox[iZone], solver_container[iZone], config_container[iZone], iZone, 0, 0);
//    }
    
  }
    
  //if (config_container[ZONE_0]->GetUnsteady_Simulation() == TIME_SPECTRAL)
    //SetTimeSpectral_Velocities(geometry_container, config_container, nZone);

  //if (nZone == 2) {
    //if (rank == MASTER_NODE)
      //cout << endl <<"--------------------- Setting Coupling Between Zones --------------------" << endl;
    //geometry_container[ZONE_0][MESH_0]->MatchZone(config_container[ZONE_0], geometry_container[ZONE_1][MESH_0],
                                                  //config_container[ZONE_1], ZONE_0, nZone);
    //geometry_container[ZONE_1][MESH_0]->MatchZone(config_container[ZONE_1], geometry_container[ZONE_0][MESH_0],
                                                  //config_container[ZONE_0], ZONE_1, nZone);
  //}
  
  output = new COutput();
  
  if (rank == MASTER_NODE)
    output->SetConvHistory_Header(&ConvHist_file, config_container[ZONE_0]);
  
  //if (config_container[ZONE_0]->GetWrt_Unsteady() && config_container[ZONE_0]->GetRestart())
    //ExtIter = config_container[ZONE_0]->GetUnst_RestartIter();
    
  if (rank == MASTER_NODE)
    cout << endl <<"------------------------------ Begin Solver -----------------------------" << endl;
    
#ifndef HAVE_MPI
  StartTime = double(clock())/double(CLOCKS_PER_SEC);
#else
  StartTime = MPI_Wtime();
#endif
  
  while (ExtIter < config_container[ZONE_0]->GetnExtIter()) {
        
    config_container[ZONE_0]->SetExtIter(ExtIter);
        
    //if (config_container[ZONE_0]->GetInvDesign_Cp() == YES)
      //output->SetCp_InverseDesign(solver_container[ZONE_0][MESH_0][FLOW_SOL],
                                  //geometry_container[ZONE_0][MESH_0], config_container[ZONE_0], ExtIter);
    
    //if (config_container[ZONE_0]->GetInvDesign_HeatFlux() == YES)
      //output->SetHeat_InverseDesign(solver_container[ZONE_0][MESH_0][FLOW_SOL],
                                    //geometry_container[ZONE_0][MESH_0], config_container[ZONE_0], ExtIter);
        
    switch (config_container[ZONE_0]->GetKind_Solver()) {
        
      case EULER: case NAVIER_STOKES: case RANS:
        MeanFlowIteration(output, integration_container, geometry_container,
                          solver_container, numerics_container, config_container);//,
                          //surface_movement, grid_movement, FFDBox);
        break;
        
      //case HEAT_EQUATION:
        //HeatIteration(output, integration_container, geometry_container,
                      //solver_container, numerics_container, config_container,
                      //surface_movement, grid_movement, FFDBox);
        //break;

    }
    
#ifndef HAVE_MPI
    StopTime = double(clock())/double(CLOCKS_PER_SEC);
#else
    StopTime = MPI_Wtime();
#endif
    
    UsedTime = (StopTime - StartTime);
        
    //if (config_container[ZONE_0]->GetEquivArea() == YES) {
      //output->SetEquivalentArea(solver_container[ZONE_0][MESH_0][FLOW_SOL],
                                //geometry_container[ZONE_0][MESH_0], config_container[ZONE_0], ExtIter);
    //}
        
    CConfig *runtime = NULL;
    strcpy(runtime_file_name, "runtime.dat");
    runtime = new CConfig(runtime_file_name, config_container[ZONE_0]);

    output->SetConvHistory_Body(&ConvHist_file, geometry_container, solver_container,
                                   config_container, integration_container, false, UsedTime, ZONE_0);

    if (config_container[ZONE_0]->GetCFL_Adapt() == YES) {
      output->SetCFL_Number(solver_container, config_container, ZONE_0);
    }
    
    switch (config_container[ZONE_0]->GetKind_Solver()) {
      case EULER: case NAVIER_STOKES: case RANS:
        StopCalc = integration_container[ZONE_0][FLOW_SOL]->GetConvergence(); break;
      //case TNE2_EULER: case TNE2_NAVIER_STOKES:
        //StopCalc = integration_container[ZONE_0][TNE2_SOL]->GetConvergence(); break;
      //case WAVE_EQUATION:
        //StopCalc = integration_container[ZONE_0][WAVE_SOL]->GetConvergence(); break;
      //case HEAT_EQUATION:
        //StopCalc = integration_container[ZONE_0][HEAT_SOL]->GetConvergence(); break;
      //case LINEAR_ELASTICITY:
        //StopCalc = integration_container[ZONE_0][FEA_SOL]->GetConvergence(); break;
      //case ADJ_EULER: case ADJ_NAVIER_STOKES: case ADJ_RANS:
        //StopCalc = integration_container[ZONE_0][ADJFLOW_SOL]->GetConvergence(); break;
      //case ADJ_TNE2_EULER: case ADJ_TNE2_NAVIER_STOKES:
        //StopCalc = integration_container[ZONE_0][ADJTNE2_SOL]->GetConvergence(); break;
    }
    
    if ((ExtIter+1 >= config_container[ZONE_0]->GetnExtIter()) ||
        ((ExtIter % config_container[ZONE_0]->GetWrt_Sol_Freq() == 0) && (ExtIter != 0) &&
          !((config_container[ZONE_0]->GetUnsteady_Simulation() == DT_STEPPING_1ST) ||
           (config_container[ZONE_0]->GetUnsteady_Simulation() == DT_STEPPING_2ND))) ||
        (StopCalc) ||
        (((config_container[ZONE_0]->GetUnsteady_Simulation() == DT_STEPPING_1ST) ||
          (config_container[ZONE_0]->GetUnsteady_Simulation() == DT_STEPPING_2ND)) &&
         ((ExtIter == 0) || (ExtIter % config_container[ZONE_0]->GetWrt_Sol_Freq_DualTime() == 0)))) {
          
          if (config_container[ZONE_0]->GetLowFidelitySim()) {
            //integration_container[ZONE_0][FLOW_SOL]->SetProlongated_Solution(RUNTIME_FLOW_SYS, solver_container[ZONE_0][MESH_0][FLOW_SOL], solver_container[ZONE_0][MESH_1][FLOW_SOL], geometry_container[ZONE_0][MESH_0], geometry_container[ZONE_0][MESH_1], config_container[ZONE_0]);
            //integration_container[ZONE_0][FLOW_SOL]->Smooth_Solution(RUNTIME_FLOW_SYS, solver_container[ZONE_0][MESH_0][FLOW_SOL], geometry_container[ZONE_0][MESH_0], 3, 1.25, config_container[ZONE_0]);
            //solver_container[ZONE_0][MESH_0][config_container[ZONE_0]->GetContainerPosition(RUNTIME_FLOW_SYS)]->Set_MPI_Solution(geometry_container[ZONE_0][MESH_0], config_container[ZONE_0]);
            //solver_container[ZONE_0][MESH_0][config_container[ZONE_0]->GetContainerPosition(RUNTIME_FLOW_SYS)]->Preprocessing(geometry_container[ZONE_0][MESH_0], solver_container[ZONE_0][MESH_0], config_container[ZONE_0], MESH_0, 0, RUNTIME_FLOW_SYS, false);
          }

          output->SetResult_Files(solver_container, geometry_container, config_container, ExtIter, nZone);
          
//          output->SetForces_Breakdown(geometry_container, solver_container,
//                                      config_container, integration_container, ZONE_0);
          
          if (config_container[ZONE_0]->GetPlot_Section_Forces()) {
//            output->SetForceSections(solver_container[ZONE_0][MESH_0][FLOW_SOL],
//                                     geometry_container[ZONE_0][MESH_0], config_container[ZONE_0], ExtIter);
          }
          
          if (rank == MASTER_NODE) cout << endl;
          
       }
        
    if (StopCalc) break;

    ExtIter++;
    
  }
    
  if (rank == MASTER_NODE) {
        
  if (config_container[ZONE_0]->GetNonphysical_Points() > 0)
    cout << "Warning: there are " << config_container[ZONE_0]->GetNonphysical_Points() << " non-physical points in the solution." << endl;
  if (config_container[ZONE_0]->GetNonphysical_Reconstr() > 0)
    cout << "Warning: " << config_container[ZONE_0]->GetNonphysical_Reconstr() << " reconstructed states for upwinding are non-physical." << endl;
      
    ConvHist_file.close();
    cout << "History file, closed." << endl;
  }
  
//  for (iZone = 0; iZone < nZone; iZone++) {
//    if (config_container[iZone] != NULL) {
//      delete config_container[iZone];
//    }
//  }
//  if (config_container != NULL) delete[] config_container;
  
#ifndef HAVE_MPI
  StopTime = double(clock())/double(CLOCKS_PER_SEC);
#else
  StopTime = MPI_Wtime();
#endif
    
  UsedTime = StopTime-StartTime;
  if (rank == MASTER_NODE) {
    cout << "\nCompleted in " << fixed << UsedTime << " seconds on "<< size;
    if (size == 1) cout << " core." << endl; else cout << " cores." << endl;
  }
    
  if (rank == MASTER_NODE)
    cout << endl <<"------------------------- Exit Success (SU2_CFD) ------------------------" << endl << endl;
  
#ifdef HAVE_MPI
  /*--- Finalize MPI parallelization ---*/
  MPI_Buffer_detach(&bptr,&bl);
  MPI_Finalize();
#endif
  
  return EXIT_SUCCESS;
}
