﻿/*!
 * \file output_structure.cpp
 * \brief Main subroutines for output solver information
 * \author F. Palacios, T. Economon
 * \version 3.2.8 "eagle"
 *
 * SU2 Lead Developers: Dr. Francisco Palacios (fpalacios@stanford.edu).
 *                      Dr. Thomas D. Economon (economon@stanford.edu).
 *
 * SU2 Developers: Prof. Juan J. Alonso's group at Stanford University.
 *                 Prof. Piero Colonna's group at Delft University of Technology.
 *                 Prof. Nicolas R. Gauger's group at Kaiserslautern University of Technology.
 *                 Prof. Alberto Guardone's group at Polytechnic University of Milan.
 *                 Prof. Rafael Palacios' group at Imperial College London.
 *
 * Copyright (C) 2012-2015 SU2, the open-source CFD code.
 *
 * SU2 is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * SU2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with SU2. If not, see <http://www.gnu.org/licenses/>.
 */

#include "../include/output_structure.hpp"

COutput::COutput(void) {

    /*--- Initialize point and connectivity counters to zero. ---*/
    nGlobal_Poin      = 0;
    nSurf_Poin        = 0;
    nGlobal_Polygon      = 0;
    nSurf_Elem        = 0;
    nGlobal_Polyhedron      = 0;
    nGlobal_Quad      = 0;
    nGlobal_Tetr      = 0;
    nGlobal_Hexa      = 0;
    nGlobal_Wedg      = 0;
    nGlobal_Pyra      = 0;
    nGlobal_Line      = 0;
    nGlobal_BoundTria = 0;
    nGlobal_BoundQuad = 0;

    /*--- Initialize CGNS write flag ---*/
    wrote_base_file = false;

    /*--- Initialize CGNS write flag ---*/
    wrote_CGNS_base = false;

    /*--- Initialize Tecplot surface flag ---*/
    wrote_surf_file = false;

    /*--- Initialize Paraview write flag ---*/
    wrote_Paraview_base = false;

}

COutput::~COutput(void) { }

void COutput::SetSurfaceCSV_Flow(CConfig *config, CGeometry *geometry,
                                 CSolver *FlowSolver, unsigned long iExtIter,
                                 unsigned short val_iZone) {
    unsigned short iMarker;
    unsigned long iPoint, iVertex, Global_Index, iFace, iElem;
    double PressCoeff = 0.0, SkinFrictionCoeff, HeatFlux;
    double xCoord = 0.0, yCoord = 0.0, zCoord = 0.0, Mach, Pressure;
    char cstr[200];

    unsigned short solver = config->GetKind_Solver();
    unsigned short nDim = geometry->GetnDim();

#ifndef HAVE_MPI

    char buffer [50];
    ofstream SurfFlow_file;

    strcpy (cstr, config->GetSurfFlowCoeff_FileName().c_str());

    if (config->GetUnsteady_Simulation() == TIME_SPECTRAL) {
        if (int(val_iZone) < 10) sprintf (buffer, "_0000%d.csv", int(val_iZone));
        if ((int(val_iZone) >= 10)   && (int(val_iZone) < 100))   sprintf (buffer, "_000%d.csv", int(val_iZone));
        if ((int(val_iZone) >= 100)  && (int(val_iZone) < 1000))  sprintf (buffer, "_00%d.csv", int(val_iZone));
        if ((int(val_iZone) >= 1000) && (int(val_iZone) < 10000)) sprintf (buffer, "_0%d.csv", int(val_iZone));
        if (int(val_iZone) >= 10000) sprintf (buffer, "_%d.csv", int(val_iZone));

    } else if (config->GetUnsteady_Simulation() && config->GetWrt_Unsteady()) {
        if ((int(iExtIter) >= 0)    && (int(iExtIter) < 10))    sprintf (buffer, "_0000%d.csv", int(iExtIter));
        if ((int(iExtIter) >= 10)   && (int(iExtIter) < 100))   sprintf (buffer, "_000%d.csv",  int(iExtIter));
        if ((int(iExtIter) >= 100)  && (int(iExtIter) < 1000))  sprintf (buffer, "_00%d.csv",   int(iExtIter));
        if ((int(iExtIter) >= 1000) && (int(iExtIter) < 10000)) sprintf (buffer, "_0%d.csv",    int(iExtIter));
        if  (int(iExtIter) >= 10000) sprintf (buffer, "_%d.csv", int(iExtIter));
    }
    else
        sprintf (buffer, ".csv");

    strcat (cstr, buffer);
    SurfFlow_file.precision(15);
    SurfFlow_file.open(cstr, ios::out);

    SurfFlow_file << "\"Global_Index\", \"x_coord\", \"y_coord\", ";
    if (nDim == 3) SurfFlow_file << "\"z_coord\", ";
    SurfFlow_file << "\"Pressure\", \"Pressure_Coefficient\", ";

    switch (solver) {
    case EULER : SurfFlow_file <<  "\"Mach_Number\"" << endl; break;
    case NAVIER_STOKES: case RANS: SurfFlow_file <<  "\"Skin_Friction_Coefficient\", \"Heat_Flux\"" << endl; break;
    }

    for (iMarker = 0; iMarker < config->GetnMarker_All(); iMarker++) {
        if (config->GetMarker_All_Plotting(iMarker) == YES) {
            for(iVertex = 0; iVertex < geometry->nElem_Bound[iMarker]; iVertex++) {
                iFace = geometry->bound[iMarker][iVertex]->GetGlobalFace();
                iElem = geometry->face[iFace]->GetElems(0);
                Global_Index = geometry->face[iFace]->GetGlobalIndex();
                xCoord = geometry->face[iFace]->GetCG(0);
                yCoord = geometry->face[iFace]->GetCG(1);
                if (nDim == 3) zCoord = geometry->face[iFace]->GetCG(2);

                if (config->GetSystemMeasurements() == US) {
                    xCoord *= 12.0; yCoord *= 12.0;
                    if (nDim == 3) zCoord *= 12.0;
                }

                Pressure = FlowSolver->elem[iElem]->GetPressure();
                PressCoeff = FlowSolver->GetCPressure(iMarker,iVertex);
                SurfFlow_file << scientific << Global_Index << ", " << xCoord << ", " << yCoord << ", ";
                if (nDim == 3) SurfFlow_file << scientific << zCoord << ", ";
                SurfFlow_file << scientific << Pressure << ", " << PressCoeff << ", ";
                switch (solver) {
                case EULER :
                    Mach = sqrt(FlowSolver->elem[iPoint]->GetVelocity2()) / FlowSolver->elem[iPoint]->GetSoundSpeed();
                    SurfFlow_file << scientific << Mach << endl;
                    break;
                case NAVIER_STOKES: case RANS:
                    SkinFrictionCoeff = FlowSolver->GetCSkinFriction(iMarker,iVertex);
                    HeatFlux = FlowSolver->GetHeatFlux(iMarker,iVertex);
                    SurfFlow_file << scientific << SkinFrictionCoeff << ", " << HeatFlux << endl;
                    break;
                }
            }
        }
    }

    SurfFlow_file.close();

#else
    int rank, iProcessor, nProcessor;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &nProcessor);

    unsigned long Buffer_Send_nVertex[1], *Buffer_Recv_nVertex = NULL;
    unsigned long nVertex_Surface = 0, nLocalVertex_Surface = 0;
    unsigned long MaxLocalVertex_Surface = 0;

    nLocalVertex_Surface = 0;
    for (iMarker = 0; iMarker < config->GetnMarker_All(); iMarker++){
        if (config->GetMarker_All_Plotting(iMarker) == YES){
            for (iVertex = 0; iVertex < geometry->GetnElem_Bound(iMarker); iVertex++) {
                iFace = geometry->bound[iMarker][iVertex]->GetGlobalFace();
                iElem = geometry->face[iFace]->GetElems(0);
                if (geometry->elem[iElem]->GetDomain()) {nLocalVertex_Surface++;}
            }
        }
    }

    Buffer_Send_nVertex[0] = nLocalVertex_Surface;
    if (rank == MASTER_NODE) Buffer_Recv_nVertex = new unsigned long [nProcessor];

    MPI_Allreduce(&nLocalVertex_Surface, &MaxLocalVertex_Surface, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);
    MPI_Gather(&Buffer_Send_nVertex, 1, MPI_UNSIGNED_LONG, Buffer_Recv_nVertex, 1, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);

    double *Buffer_Send_Coord_x = new double [MaxLocalVertex_Surface];
    double *Buffer_Recv_Coord_x = NULL;

    double *Buffer_Send_Coord_y = new double [MaxLocalVertex_Surface];
    double *Buffer_Recv_Coord_y = NULL;

    double *Buffer_Send_Coord_z = new double [MaxLocalVertex_Surface];
    double *Buffer_Recv_Coord_z = NULL;

    double *Buffer_Send_Press = new double [MaxLocalVertex_Surface];
    double *Buffer_Recv_Press = NULL;

    double *Buffer_Send_CPress = new double [MaxLocalVertex_Surface];
    double *Buffer_Recv_CPress = NULL;

    double *Buffer_Send_Mach = new double [MaxLocalVertex_Surface];
    double *Buffer_Recv_Mach = NULL;

    double *Buffer_Send_SkinFriction = new double [MaxLocalVertex_Surface];
    double *Buffer_Recv_SkinFriction = NULL;

    double *Buffer_Send_HeatTransfer = new double [MaxLocalVertex_Surface];
    double *Buffer_Recv_HeatTransfer = NULL;

    unsigned long *Buffer_Send_GlobalIndex = new unsigned long [MaxLocalVertex_Surface];
    unsigned long *Buffer_Recv_GlobalIndex = NULL;

    if (rank == MASTER_NODE) {
        Buffer_Recv_Coord_x = new double [nProcessor*MaxLocalVertex_Surface];
        Buffer_Recv_Coord_y = new double [nProcessor*MaxLocalVertex_Surface];
        if (nDim == 3) Buffer_Recv_Coord_z = new double [nProcessor*MaxLocalVertex_Surface];
        Buffer_Recv_Press   = new double [nProcessor*MaxLocalVertex_Surface];
        Buffer_Recv_CPress  = new double [nProcessor*MaxLocalVertex_Surface];
        Buffer_Recv_Mach    = new double [nProcessor*MaxLocalVertex_Surface];
        Buffer_Recv_SkinFriction = new double [nProcessor*MaxLocalVertex_Surface];
        Buffer_Recv_HeatTransfer = new double [nProcessor*MaxLocalVertex_Surface];
        Buffer_Recv_GlobalIndex  = new unsigned long [nProcessor*MaxLocalVertex_Surface];
    }

    nVertex_Surface = 0;
    for (iMarker = 0; iMarker < config->GetnMarker_All(); iMarker++)
        if (config->GetMarker_All_Plotting(iMarker) == YES)
            for (iVertex = 0; iVertex < geometry->GetnElem_Bound(iMarker); iVertex++) {
                iFace = geometry->bound[iMarker][iVertex]->GetGlobalFace();
                iElem = geometry->face[iFace]->GetElems(0);
                if (geometry->elem[iElem]->GetDomain()) {
                    Buffer_Send_Press[nVertex_Surface] = FlowSolver->elem[iElem]->GetPressure();
                    Buffer_Send_CPress[nVertex_Surface] = FlowSolver->GetCPressure(iMarker,iVertex);
                    Buffer_Send_Coord_x[nVertex_Surface] = geometry->face[iFace]->GetCG(0);
                    Buffer_Send_Coord_y[nVertex_Surface] = geometry->face[iFace]->GetCG(1);
                    if (nDim == 3) { Buffer_Send_Coord_z[nVertex_Surface] = geometry->face[iFace]->GetCG(2); }

                    if (config->GetSystemMeasurements() == US) {
                        Buffer_Send_Coord_x[nVertex_Surface] *= 12.0;
                        Buffer_Send_Coord_y[nVertex_Surface] *= 12.0;
                        if (nDim == 3) Buffer_Send_Coord_z[nVertex_Surface] *= 12.0;
                    }

                    Buffer_Send_GlobalIndex[nVertex_Surface] = geometry->face[iFace]->GetGlobalIndex();

                    if (solver == EULER)
                        Buffer_Send_Mach[nVertex_Surface] = sqrt(FlowSolver->elem[iElem]->GetVelocity2()) / FlowSolver->elem[iElem]->GetSoundSpeed();
                    if ((solver == NAVIER_STOKES) || (solver == RANS))
                        Buffer_Send_SkinFriction[nVertex_Surface] = FlowSolver->GetCSkinFriction(iMarker,iVertex);
                    nVertex_Surface++;
                }
            }

    MPI_Gather(Buffer_Send_Coord_x, MaxLocalVertex_Surface, MPI_DOUBLE, Buffer_Recv_Coord_x, MaxLocalVertex_Surface, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_Coord_y, MaxLocalVertex_Surface, MPI_DOUBLE, Buffer_Recv_Coord_y, MaxLocalVertex_Surface, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
    if (nDim == 3) MPI_Gather(Buffer_Send_Coord_z, MaxLocalVertex_Surface, MPI_DOUBLE, Buffer_Recv_Coord_z, MaxLocalVertex_Surface, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_Press, MaxLocalVertex_Surface, MPI_DOUBLE, Buffer_Recv_Press, MaxLocalVertex_Surface, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_CPress, MaxLocalVertex_Surface, MPI_DOUBLE, Buffer_Recv_CPress, MaxLocalVertex_Surface, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
    if (solver == EULER) MPI_Gather(Buffer_Send_Mach, MaxLocalVertex_Surface, MPI_DOUBLE, Buffer_Recv_Mach, MaxLocalVertex_Surface, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
    if ((solver == NAVIER_STOKES) || (solver == RANS)) MPI_Gather(Buffer_Send_SkinFriction, MaxLocalVertex_Surface, MPI_DOUBLE, Buffer_Recv_SkinFriction, MaxLocalVertex_Surface, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);

    MPI_Gather(Buffer_Send_GlobalIndex, MaxLocalVertex_Surface, MPI_UNSIGNED_LONG, Buffer_Recv_GlobalIndex, MaxLocalVertex_Surface, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);

    if (rank == MASTER_NODE) {

        char buffer[50];
        string filename = config->GetSurfFlowCoeff_FileName();
        ofstream SurfFlow_file;

        strcpy (cstr, filename.c_str());
        if (config->GetUnsteady_Simulation() == TIME_SPECTRAL) {
            if (int(val_iZone) < 10) sprintf (buffer, "_0000%d.csv", int(val_iZone));
            if ((int(val_iZone) >= 10) && (int(val_iZone) < 100)) sprintf (buffer, "_000%d.csv", int(val_iZone));
            if ((int(val_iZone) >= 100) && (int(val_iZone) < 1000)) sprintf (buffer, "_00%d.csv", int(val_iZone));
            if ((int(val_iZone) >= 1000) && (int(val_iZone) < 10000)) sprintf (buffer, "_0%d.csv", int(val_iZone));
            if (int(val_iZone) >= 10000) sprintf (buffer, "_%d.csv", int(val_iZone));

        } else if (config->GetUnsteady_Simulation() && config->GetWrt_Unsteady()) {
            if ((int(iExtIter) >= 0)    && (int(iExtIter) < 10))    sprintf (buffer, "_0000%d.csv", int(iExtIter));
            if ((int(iExtIter) >= 10)   && (int(iExtIter) < 100))   sprintf (buffer, "_000%d.csv",  int(iExtIter));
            if ((int(iExtIter) >= 100)  && (int(iExtIter) < 1000))  sprintf (buffer, "_00%d.csv",   int(iExtIter));
            if ((int(iExtIter) >= 1000) && (int(iExtIter) < 10000)) sprintf (buffer, "_0%d.csv",    int(iExtIter));
            if  (int(iExtIter) >= 10000) sprintf (buffer, "_%d.csv", int(iExtIter));
        }
        else
            sprintf (buffer, ".csv");

        strcat (cstr, buffer);
        SurfFlow_file.precision(15);
        SurfFlow_file.open(cstr, ios::out);

        SurfFlow_file << "\"Global_Index\", \"x_coord\", \"y_coord\", ";
        if (nDim == 3) SurfFlow_file << "\"z_coord\", ";
        SurfFlow_file << "\"Pressure\", \"Pressure_Coefficient\", ";

        switch (solver) {
        case EULER : SurfFlow_file <<  "\"Mach_Number\"" << endl; break;
        case NAVIER_STOKES: case RANS: SurfFlow_file <<  "\"Skin_Friction_Coefficient\"" << endl; break;
        }

        unsigned long Total_Index;
        for (iProcessor = 0; iProcessor < nProcessor; iProcessor++) {
            for (iVertex = 0; iVertex < Buffer_Recv_nVertex[iProcessor]; iVertex++) {

                Total_Index  = iProcessor*MaxLocalVertex_Surface+iVertex;
                Global_Index = Buffer_Recv_GlobalIndex[Total_Index];

                xCoord = Buffer_Recv_Coord_x[Total_Index];
                yCoord = Buffer_Recv_Coord_y[Total_Index];
                if (nDim == 3) zCoord = Buffer_Recv_Coord_z[Total_Index];
                Pressure   = Buffer_Recv_Press[Total_Index];
                PressCoeff = Buffer_Recv_CPress[Total_Index];

                SurfFlow_file << scientific << Global_Index << ", " << xCoord << ", " << yCoord << ", ";
                if (nDim == 3) SurfFlow_file << scientific << zCoord << ", ";
                SurfFlow_file << scientific << Pressure << ", " << PressCoeff << ", ";

                switch (solver) {
                case EULER :
                    Mach = Buffer_Recv_Mach[Total_Index];
                    SurfFlow_file << scientific << Mach << endl;
                    break;
                case NAVIER_STOKES: case RANS:
                    SkinFrictionCoeff = Buffer_Recv_SkinFriction[Total_Index];
                    SurfFlow_file << scientific << SkinFrictionCoeff << endl;
                    break;
                }
            }
        }

        SurfFlow_file.close();

        delete [] Buffer_Recv_Coord_x;
        delete [] Buffer_Recv_Coord_y;
        if (nDim == 3) delete [] Buffer_Recv_Coord_z;
        delete [] Buffer_Recv_Press;
        delete [] Buffer_Recv_CPress;
        delete [] Buffer_Recv_Mach;
        delete [] Buffer_Recv_SkinFriction;
        delete [] Buffer_Recv_HeatTransfer;
        delete [] Buffer_Recv_GlobalIndex;

        delete [] Buffer_Recv_nVertex;

    }

    delete [] Buffer_Send_Coord_x;
    delete [] Buffer_Send_Coord_y;
    delete [] Buffer_Send_Coord_z;
    delete [] Buffer_Send_Press;
    delete [] Buffer_Send_CPress;
    delete [] Buffer_Send_Mach;
    delete [] Buffer_Send_SkinFriction;
    delete [] Buffer_Send_HeatTransfer;
    delete [] Buffer_Send_GlobalIndex;

#endif
}

void COutput::SetSurfaceCSV_Adjoint(CConfig *config, CGeometry *geometry, CSolver *AdjSolver, CSolver *FlowSolution, unsigned long iExtIter, unsigned short val_iZone) {


}

void COutput::SetSurfaceCSV_Linearized(CConfig *config, CGeometry *geometry, CSolver *LinSolution, string val_filename, unsigned long iExtIter) { }

void COutput::MergeConnectivity(CConfig *config, CGeometry *geometry, unsigned short val_iZone) {

    int rank = MASTER_NODE;
    int size = SINGLE_NODE;

#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
#endif

    bool Wrt_Vol = config->GetWrt_Vol_Sol();
    bool Wrt_Srf = config->GetWrt_Srf_Sol();

    if (Wrt_Vol) {

        if ((rank == MASTER_NODE) && (size != SINGLE_NODE))// && (nGlobal_Polyhedron != 0))
            cout <<"Merging volumetric triangle grid connectivity." << endl;
        MergeVolumetricConnectivity(config, geometry);
        MergeSurfaceConnectivity(config, geometry);

    }

    if (Wrt_Srf) {

        //if ((rank == MASTER_NODE) && (size != SINGLE_NODE))

        //        MergeSurfaceConnectivity(config, geometry);

    }

}

void COutput::MergeCoordinates(CConfig *config, CGeometry *geometry) {

    int iProcessor;
    unsigned long iPoint, jPoint;
    unsigned long Buffer_Send_nPoint[1], *Buffer_Recv_nPoint = NULL;
    unsigned long nLocalPoint, nBuffer_Scalar = 0;
    unsigned long MaxLocalPoint, nPoint_Total, iGlobal_Index, MaxPointTotal;

    int rank = MASTER_NODE;
    int size = SINGLE_NODE;

#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
#endif

    nLocalPoint = geometry->GetnPoint();

    Buffer_Send_nPoint[0] = nLocalPoint;
    if (rank == MASTER_NODE) Buffer_Recv_nPoint = new unsigned long[size];


#ifdef HAVE_MPI
    MPI_Allreduce(&nLocalPoint, &MaxLocalPoint, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);
    MPI_Gather(&Buffer_Send_nPoint, 1, MPI_UNSIGNED_LONG, Buffer_Recv_nPoint, 1, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);

#else
    MaxLocalPoint = nLocalPoint;
    Buffer_Recv_nPoint[0] = Buffer_Send_nPoint[0];
#endif

    nBuffer_Scalar = MaxLocalPoint;

    double *Buffer_Send_X = new double[MaxLocalPoint];
    double *Buffer_Recv_X = NULL;

    double *Buffer_Send_Y = new double[MaxLocalPoint];
    double *Buffer_Recv_Y = NULL;

    double *Buffer_Send_Z, *Buffer_Recv_Z = NULL;
    Buffer_Send_Z = new double[MaxLocalPoint];

    unsigned long *Buffer_Send_GlobalIndex = new unsigned long[MaxLocalPoint];
    unsigned long *Buffer_Recv_GlobalIndex = NULL;

    unsigned short *Buffer_Send_View = new unsigned short[MaxPointTotal];
    unsigned short *Buffer_Recv_View = NULL;

    if (rank == MASTER_NODE) {

        Buffer_Recv_X = new double[size*MaxLocalPoint];
        Buffer_Recv_Y = new double[size*MaxLocalPoint];
        Buffer_Recv_Z = new double[size*MaxLocalPoint];
        Buffer_Recv_GlobalIndex = new unsigned long[size*MaxLocalPoint];
        Buffer_Recv_View = new unsigned short[MaxPointTotal];
    }

    for(iPoint = 0; iPoint < geometry->GetnPoint(); iPoint++){
        Buffer_Send_GlobalIndex[iPoint] = geometry->node[iPoint]->GetGlobalIndex();
        Buffer_Send_View[Buffer_Send_GlobalIndex[iPoint]] = false;
    }

    jPoint = 0;
    double *Coords_Local;
    for(iPoint = 0; iPoint < geometry->GetnPoint(); iPoint++){
        Coords_Local = geometry->node[iPoint]->GetCoord();
        Buffer_Send_X[jPoint] = Coords_Local[0];
        Buffer_Send_Y[jPoint] = Coords_Local[1];
        Buffer_Send_Z[jPoint] = Coords_Local[2];

        if ((config->GetSystemMeasurements() == US) && (config->GetKind_SU2() != SU2_DEF)) {
            Buffer_Send_X[jPoint] *= 12.0;
            Buffer_Send_Y[jPoint] *= 12.0;
            Buffer_Send_Z[jPoint] *= 12.0;
        }
        jPoint++;
    }

#ifdef HAVE_MPI
    MPI_Gather(Buffer_Send_X, nBuffer_Scalar, MPI_DOUBLE, Buffer_Recv_X, nBuffer_Scalar, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_Y, nBuffer_Scalar, MPI_DOUBLE, Buffer_Recv_Y, nBuffer_Scalar, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_Z, nBuffer_Scalar, MPI_DOUBLE, Buffer_Recv_Z, nBuffer_Scalar, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_GlobalIndex, nBuffer_Scalar, MPI_UNSIGNED_LONG, Buffer_Recv_GlobalIndex, nBuffer_Scalar, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_View, MaxPointTotal, MPI_UNSIGNED_SHORT, Buffer_Recv_View, MaxPointTotal, MPI_UNSIGNED_SHORT, MASTER_NODE, MPI_COMM_WORLD);
#else

    for(iPoint = 0; iPoint < MaxLocalPoint; iPoint++) Buffer_Recv_X[iPoint] = Buffer_Send_X[iPoint];
    for(iPoint = 0; iPoint < MaxLocalPoint; iPoint++) Buffer_Recv_Y[iPoint] = Buffer_Send_Y[iPoint];
    for(iPoint = 0; iPoint < MaxLocalPoint; iPoint++) Buffer_Recv_Z[iPoint] = Buffer_Send_Z[iPoint];
    for(iPoint = 0; iPoint < MaxLocalPoint; iPoint++) Buffer_Recv_GlobalIndex[iPoint] = Buffer_Send_GlobalIndex[iPoint];
    for(iPoint = 0; iPoint < MaxLocalPoint; iPoint++) Buffer_Recv_View[iPoint] = Buffer_Send_View[iPoint];
#endif


    if (rank == MASTER_NODE) {

        jPoint = 0;
        for (iProcessor = 0; iProcessor < size; iProcessor++) {
            for (iPoint = 0; iPoint < Buffer_Recv_nPoint[iProcessor]; iPoint++) {

                if (Buffer_Recv_View[Buffer_Recv_GlobalIndex[jPoint]] == false) {

                    nPoint_Total++;
                    Buffer_Recv_View[Buffer_Recv_GlobalIndex[jPoint]] = true;
                    iGlobal_Index = Buffer_Recv_GlobalIndex[jPoint];
                    Coords[0][iGlobal_Index] = Buffer_Recv_X[jPoint];
                    Coords[1][iGlobal_Index] = Buffer_Recv_Y[jPoint];
                    Coords[2][iGlobal_Index] = Buffer_Recv_Z[jPoint];
                    jPoint++;

                }
            }
            jPoint = (iProcessor+1)*nBuffer_Scalar;
        }
    }

    delete [] Buffer_Send_X;
    delete [] Buffer_Send_Y;
    delete [] Buffer_Send_Z;
    delete [] Buffer_Send_GlobalIndex;
    delete [] Buffer_Send_View;
    if (rank == MASTER_NODE) {
        delete [] Buffer_Recv_X;
        delete [] Buffer_Recv_Y;
        delete [] Buffer_Recv_Z;
        delete [] Buffer_Recv_GlobalIndex;
        delete [] Buffer_Recv_View;
        delete [] Buffer_Recv_nPoint;
    }

    if (rank == MASTER_NODE) {
        nGlobal_Poin = nPoint_Total;
    }
}
void COutput::MergeVolumetricConnectivity(CConfig *config, CGeometry *geometry) {

    int iProcessor;
    unsigned short nDim = 3, iDim =0;
    unsigned long iNode, iPoint, jNode3=0, jNode4=0, jNode5=0, jNode6=0, jNode7=0, jNode8 = 0, lNode3, lNode4, lNode5, lNode6, lNode7, iGlobal_Index,
            kNode3, kNode4, kNode5, kNode6, kNode7, kNode8;
    unsigned long iElem = 0, iFace = 0, jFace, jElem, kFace, jPoint = 0;
    unsigned long nLocalElem = 0, nLocalFace = 0, nLocalPoint = 0, nFace_Total, nFace_TotalSurf = 0, nPoint_Total, Total_nNode;
    unsigned long nLocalFace3=0, nLocalFace4=0, nLocalFace5=0, nLocalFace6=0, nLocalFace7=0, nLocalFace8=0;
    unsigned long Buffer_Send_nElem[1], *Buffer_Recv_nElem = NULL;
    unsigned long Buffer_Send_nFace[1], *Buffer_Recv_nFace = NULL;
    unsigned long Buffer_Send_nFace3[1], *Buffer_Recv_nFace3 = NULL;
    unsigned long Buffer_Send_nFace4[1], *Buffer_Recv_nFace4 = NULL;
    unsigned long Buffer_Send_nFace5[1], *Buffer_Recv_nFace5 = NULL;
    unsigned long Buffer_Send_nFace6[1], *Buffer_Recv_nFace6 = NULL;
    unsigned long Buffer_Send_nFace7[1], *Buffer_Recv_nFace7 = NULL;
    unsigned long Buffer_Send_nFace8[1], *Buffer_Recv_nFace8 = NULL;

    unsigned long Buffer_Send_nPoint[1], *Buffer_Recv_nPoint = NULL;
    unsigned long nBuffer_Scalar3 = 0, nBuffer_Scalar4 = 0,nBuffer_Scalar5 = 0,nBuffer_Scalar6 = 0,nBuffer_Scalar7 = 0, nBuffer_Scalar8 = 0;
    unsigned long MaxLocalElem,MaxLocalFace, MaxLocalPoint;
    unsigned long MaxLocalFace3,MaxLocalFace4, MaxLocalFace5, MaxLocalFace6, MaxLocalFace7, MaxLocalFace8;
    int rank = MASTER_NODE;
    int size = SINGLE_NODE;

#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
#endif

    for(iFace = 0; iFace < geometry->GetnFace(); iFace++){
        if(geometry->face[iFace]->GetnNodes_Face()==3) nLocalFace3++;
        if(geometry->face[iFace]->GetnNodes_Face()==4) nLocalFace4++;
        if(geometry->face[iFace]->GetnNodes_Face()==5) nLocalFace5++;
        if(geometry->face[iFace]->GetnNodes_Face()==6) nLocalFace6++;
        if(geometry->face[iFace]->GetnNodes_Face()==7) nLocalFace7++;
        if(geometry->face[iFace]->GetnNodes_Face()==8) nLocalFace8++;
    }

    nLocalFace = geometry->GetnFace();
    nLocalElem = geometry->GetnElem();
    nLocalPoint = geometry->GetnPoint();

    Buffer_Send_nElem[0] = nLocalElem;
    Buffer_Send_nFace[0] = nLocalFace;
    Buffer_Send_nFace3[0] = nLocalFace3;
    Buffer_Send_nFace4[0] = nLocalFace4;
    Buffer_Send_nFace5[0] = nLocalFace5;
    Buffer_Send_nFace6[0] = nLocalFace6;
    Buffer_Send_nFace7[0] = nLocalFace7;
    Buffer_Send_nFace8[0] = nLocalFace8;
    Buffer_Send_nPoint[0] = nLocalPoint;

    if (rank == MASTER_NODE){
        Buffer_Recv_nElem = new unsigned long[size];
        Buffer_Recv_nFace = new unsigned long[size];
        Buffer_Recv_nFace3 = new unsigned long[size];
        Buffer_Recv_nFace4 = new unsigned long[size];
        Buffer_Recv_nFace5 = new unsigned long[size];
        Buffer_Recv_nFace6 = new unsigned long[size];
        Buffer_Recv_nFace7 = new unsigned long[size];
        Buffer_Recv_nFace8 = new unsigned long[size];
        Buffer_Recv_nPoint = new unsigned long[size];
    }

#ifdef HAVE_MPI
    MPI_Allreduce(&nLocalElem, &MaxLocalElem, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);
    MPI_Allreduce(&nLocalFace, &MaxLocalFace, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);
    MPI_Allreduce(&nLocalFace3, &MaxLocalFace3, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);
    MPI_Allreduce(&nLocalFace4, &MaxLocalFace4, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);
    MPI_Allreduce(&nLocalFace5, &MaxLocalFace5, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);
    MPI_Allreduce(&nLocalFace6, &MaxLocalFace6, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);
    MPI_Allreduce(&nLocalFace7, &MaxLocalFace7, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);
    MPI_Allreduce(&nLocalFace8, &MaxLocalFace8, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);
    MPI_Allreduce(&nLocalPoint, &MaxLocalPoint, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);

    MPI_Gather(&Buffer_Send_nElem, 1, MPI_UNSIGNED_LONG, Buffer_Recv_nElem, 1, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(&Buffer_Send_nFace, 1, MPI_UNSIGNED_LONG, Buffer_Recv_nFace, 1, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(&Buffer_Send_nFace3, 1, MPI_UNSIGNED_LONG, Buffer_Recv_nFace3, 1, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(&Buffer_Send_nFace4, 1, MPI_UNSIGNED_LONG, Buffer_Recv_nFace4, 1, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(&Buffer_Send_nFace5, 1, MPI_UNSIGNED_LONG, Buffer_Recv_nFace5, 1, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(&Buffer_Send_nFace6, 1, MPI_UNSIGNED_LONG, Buffer_Recv_nFace6, 1, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(&Buffer_Send_nFace7, 1, MPI_UNSIGNED_LONG, Buffer_Recv_nFace7, 1, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(&Buffer_Send_nFace8, 1, MPI_UNSIGNED_LONG, Buffer_Recv_nFace8, 1, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(&Buffer_Send_nPoint, 1, MPI_UNSIGNED_LONG, Buffer_Recv_nPoint, 1, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);

#else
    MaxLocalElem = nLocalElem;
    MaxLocalFace = nLocalFace;
    MaxLocalFace3 = nLocalFace3;
    MaxLocalFace4 = nLocalFace4;
    MaxLocalFace5 = nLocalFace5;
    MaxLocalFace6 = nLocalFace6;
    MaxLocalFace7 = nLocalFace7;
    MaxLocalFace8 = nLocalFace8;
    MaxLocalPoint = nLocalPoint;
    Buffer_Recv_nElem[0] = Buffer_Send_nElem[0];
    Buffer_Recv_nFace[0] = Buffer_Send_nFace[0];
    Buffer_Recv_nPoint[0] = Buffer_Send_nPoint[0];

#endif
    nBuffer_Scalar3 = MaxLocalFace3*3;
    nBuffer_Scalar4 = MaxLocalFace4*4;
    nBuffer_Scalar5 = MaxLocalFace5*5;
    nBuffer_Scalar6 = MaxLocalFace6*6;
    nBuffer_Scalar7 = MaxLocalFace7*7;
    nBuffer_Scalar8 = MaxLocalFace8*8;

    unsigned long *Buffer_Send_nNode = new unsigned long[MaxLocalFace];
    unsigned long *Buffer_Recv_nNode = NULL;

    unsigned long *Buffer_Send_Face3 = new unsigned long[nBuffer_Scalar3];
    unsigned long *Buffer_Recv_Face3 = NULL;

    unsigned long *Buffer_Send_Face4 = new unsigned long[nBuffer_Scalar4];
    unsigned long *Buffer_Recv_Face4 = NULL;

    unsigned long *Buffer_Send_Face5 = new unsigned long[nBuffer_Scalar5];
    unsigned long *Buffer_Recv_Face5 = NULL;

    unsigned long *Buffer_Send_Face6 = new unsigned long[nBuffer_Scalar6];
    unsigned long *Buffer_Recv_Face6 = NULL;

    unsigned long *Buffer_Send_Face7 = new unsigned long[nBuffer_Scalar7];
    unsigned long *Buffer_Recv_Face7 = NULL;

    unsigned long *Buffer_Send_Face8 = new unsigned long[nBuffer_Scalar8];
    unsigned long *Buffer_Recv_Face8 = NULL;

    long *Buffer_Send_RNeigh = new long[MaxLocalFace];
    long *Buffer_Recv_RNeigh = NULL;

    long *Buffer_Send_LNeigh = new long[MaxLocalFace];
    long *Buffer_Recv_LNeigh = NULL;

    unsigned long *Buffer_Send_GFace = new unsigned long[MaxLocalFace];
    unsigned long *Buffer_Recv_GFace = NULL;

    long *Buffer_Send_Halo = new long[MaxLocalFace];
    long *Buffer_Recv_Halo = NULL;

    long *Buffer_Send_Point = new long[MaxLocalPoint];
    long *Buffer_Recv_Point = NULL;

    double *Buffer_Send_X = new double[MaxLocalPoint];
    double *Buffer_Recv_X = NULL;

    double *Buffer_Send_Y = new double[MaxLocalPoint];
    double *Buffer_Recv_Y = NULL;

    double *Buffer_Send_Z, *Buffer_Recv_Z = NULL;
    Buffer_Send_Z = new double[MaxLocalPoint];

    if (rank == MASTER_NODE) {
        Buffer_Recv_Face3 = new unsigned long[size*nBuffer_Scalar3];
        Buffer_Recv_Face4 = new unsigned long[size*nBuffer_Scalar4];
        Buffer_Recv_Face5 = new unsigned long[size*nBuffer_Scalar5];
        Buffer_Recv_Face6 = new unsigned long[size*nBuffer_Scalar6];
        Buffer_Recv_Face7 = new unsigned long[size*nBuffer_Scalar7];
        Buffer_Recv_Face8 = new unsigned long[size*nBuffer_Scalar8];
        Buffer_Recv_RNeigh = new long[size*MaxLocalFace];
        Buffer_Recv_LNeigh = new long[size*MaxLocalFace];
        Buffer_Recv_nNode = new unsigned long[size*MaxLocalFace];
        Buffer_Recv_GFace = new unsigned long[size*MaxLocalFace];
        Buffer_Recv_Halo = new long[size*MaxLocalFace];
        Buffer_Recv_Point = new long[size*MaxLocalPoint];
        Buffer_Recv_X = new double[size*MaxLocalPoint];
        Buffer_Recv_Y = new double[size*MaxLocalPoint];
        Buffer_Recv_Z = new double[size*MaxLocalPoint];
    }

    jPoint = 0;
    for(iPoint = 0; iPoint < geometry->GetnPoint(); iPoint++){
        Buffer_Send_Point[jPoint] = geometry->node[iPoint]->GetGlobalIndex();
        Buffer_Send_X[jPoint] = geometry->node[iPoint]->GetCoord(0);
        Buffer_Send_Y[jPoint] = geometry->node[iPoint]->GetCoord(1);
        Buffer_Send_Z[jPoint] = geometry->node[iPoint]->GetCoord(2);
        jPoint++;
    }

#ifdef HAVE_MPI
    MPI_Gather(Buffer_Send_Point, MaxLocalPoint, MPI_UNSIGNED_LONG, Buffer_Recv_Point, MaxLocalPoint, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_X, MaxLocalPoint, MPI_DOUBLE, Buffer_Recv_X, MaxLocalPoint, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_Y, MaxLocalPoint, MPI_DOUBLE, Buffer_Recv_Y, MaxLocalPoint, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_Z, MaxLocalPoint, MPI_DOUBLE, Buffer_Recv_Z, MaxLocalPoint, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
#else
    for(iPoint = 0; iPoint < MaxLocalPoint; iPoint++) Buffer_Recv_Point[iPoint] = Buffer_Send_Point[iPoint];
    for(iPoint = 0; iPoint < MaxLocalPoint; iPoint++) Buffer_Recv_X[iPoint] = Buffer_Send_X[iPoint];
    for(iPoint = 0; iPoint < MaxLocalPoint; iPoint++) Buffer_Recv_Y[iPoint] = Buffer_Send_Y[iPoint];
    for(iPoint = 0; iPoint < MaxLocalPoint; iPoint++) Buffer_Recv_Z[iPoint] = Buffer_Send_Z[iPoint];
#endif

    delete [] Buffer_Send_Point;
    delete [] Buffer_Send_X;
    delete [] Buffer_Send_Y;
    delete [] Buffer_Send_Z;
    if(rank == MASTER_NODE){
        unsigned long *ncount = new unsigned long[MaxLocalPoint*size];
        for(iPoint = 0; iPoint < MaxLocalPoint*size; iPoint++) ncount[iPoint]=0;

        jPoint = 0; nPoint_Total = 0;
        for(iProcessor = 0; iProcessor < size; iProcessor++){
            for(iPoint = 0; iPoint < Buffer_Recv_nPoint[iProcessor]; iPoint++){

                ncount[Buffer_Recv_Point[iPoint+jPoint]]++;
                if(ncount[Buffer_Recv_Point[iPoint+jPoint]]==1){
                    nPoint_Total++;
                }
            }
            jPoint = (iProcessor+1)*MaxLocalPoint;
        }
        nGlobal_Poin = nPoint_Total;

        Coords = new double*[nDim];
        for (iDim = 0; iDim < nDim; iDim++) {
            Coords[iDim] = new double[nGlobal_Poin];
        }

        for(iPoint = 0; iPoint < MaxLocalPoint*size; iPoint++) ncount[iPoint]=0;

        jPoint = 0; nPoint_Total = 0;
        for(iProcessor = 0; iProcessor < size; iProcessor++){
            for(iPoint = 0; iPoint < Buffer_Recv_nPoint[iProcessor]; iPoint++){
                ncount[Buffer_Recv_Point[iPoint+jPoint]]++;
                if(ncount[Buffer_Recv_Point[iPoint+jPoint]]==1){
                    iGlobal_Index = Buffer_Recv_Point[iPoint+jPoint];
                    Coords[0][iGlobal_Index] = Buffer_Recv_X[iPoint+jPoint];
                    Coords[1][iGlobal_Index] = Buffer_Recv_Y[iPoint+jPoint];
                    Coords[2][iGlobal_Index] = Buffer_Recv_Z[iPoint+jPoint];
                    nPoint_Total++;
                }
            }
            jPoint = (iProcessor+1)*MaxLocalPoint;
        }

        nGlobal_Poin = nPoint_Total;
        delete [] ncount;
        delete [] Buffer_Recv_nPoint;
        delete [] Buffer_Recv_Point;
        delete [] Buffer_Recv_X;
        delete [] Buffer_Recv_Y;
        delete [] Buffer_Recv_Z;
    }

    jFace = 0;
    for(iFace = 0; iFace < geometry->GetnFace(); iFace++){
        Buffer_Send_Halo[jFace] = -1;
        if((geometry->elem[geometry->face[iFace]->GetElems(0)]->GetColor() == rank)){
            if(geometry->face[iFace]->GetElems(1) != -1){
                if((geometry->elem[geometry->face[iFace]->GetElems(1)]->GetColor() > rank)||(geometry->elem[geometry->face[iFace]->GetElems(1)]->GetColor() == rank)){
                    Buffer_Send_Halo[jFace] = 1;//iFace;
                }
            }
            if(geometry->face[iFace]->GetElems(1) == -1){
                if((geometry->elem[geometry->face[iFace]->GetElems(0)]->GetColor() == rank)){
                    Buffer_Send_Halo[jFace] = 1;//iFace;
                }
            }
        }

        else if((geometry->face[iFace]->GetElems(1) != -1) &&(geometry->elem[geometry->face[iFace]->GetElems(1)]->GetColor() == rank)){
            if((geometry->elem[geometry->face[iFace]->GetElems(0)]->GetColor() == rank)||(geometry->elem[geometry->face[iFace]->GetElems(0)]->GetColor() > rank)){
                Buffer_Send_Halo[jFace] = 1;//iFace;
            }
        }
        jFace++;
    }

    jNode3 = 0; jNode4 = 0; jNode5 = 0; jNode6 = 0; jNode7 = 0; jNode8 = 0; jFace = 0;
    for(iFace = 0; iFace < geometry->GetnFace(); iFace++){
        if(Buffer_Send_Halo[jFace] == 1){
            Buffer_Send_GFace[jFace] = geometry->face[iFace]->GetGlobalIndex();
            Buffer_Send_nNode[jFace] = geometry->face[iFace]->GetnNodes_Face();
            jElem = geometry->elem[geometry->face[iFace]->GetElems(0)]->GetGlobalIndex();
            Buffer_Send_LNeigh[jFace] = jElem;

            if(geometry->face[iFace]->GetElems(1)!=-1){
                iElem = geometry->elem[geometry->face[iFace]->GetElems(1)]->GetGlobalIndex();
                Buffer_Send_RNeigh[jFace] = iElem;
            }
            else if(geometry->face[iFace]->GetElems(1)==-1){
                Buffer_Send_RNeigh[jFace] = -1;
            }

            if( Buffer_Send_nNode[jFace]==3){
                for(iNode = 0; iNode < 3; iNode++){
                    Buffer_Send_Face3[jNode3] = geometry->node[geometry->face[iFace]->GetNode_Face(iNode)]->GetGlobalIndex();
                    jNode3++;
                }
            }
            if( Buffer_Send_nNode[jFace]==4){
                for(iNode = 0; iNode < 4; iNode++){
                    Buffer_Send_Face4[jNode4] = geometry->node[geometry->face[iFace]->GetNode_Face(iNode)]->GetGlobalIndex();
                    jNode4++;
                }
            }
            if( Buffer_Send_nNode[jFace]==5){
                for(iNode = 0; iNode < 5; iNode++){
                    Buffer_Send_Face5[jNode5] = geometry->node[geometry->face[iFace]->GetNode_Face(iNode)]->GetGlobalIndex();
                    jNode5++;
                }
            }
            if( Buffer_Send_nNode[jFace]==6){
                for(iNode = 0; iNode < 6; iNode++){
                    Buffer_Send_Face6[jNode6] = geometry->node[geometry->face[iFace]->GetNode_Face(iNode)]->GetGlobalIndex();
                    jNode6++;
                }
            }
            if( Buffer_Send_nNode[jFace]==7){
                for(iNode = 0; iNode < 7; iNode++){
                    Buffer_Send_Face7[jNode7] = geometry->node[geometry->face[iFace]->GetNode_Face(iNode)]->GetGlobalIndex();
                    jNode7++;
                }
            }

            if( Buffer_Send_nNode[jFace]==8){
                for(iNode = 0; iNode < 8; iNode++){
                    Buffer_Send_Face8[jNode8] = geometry->node[geometry->face[iFace]->GetNode_Face(iNode)]->GetGlobalIndex();
                    jNode8++;
                }
            }

        }
        jFace++;
    }

#ifdef HAVE_MPI
    MPI_Gather(Buffer_Send_Face3, nBuffer_Scalar3, MPI_UNSIGNED_LONG, Buffer_Recv_Face3, nBuffer_Scalar3, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_Face4, nBuffer_Scalar4, MPI_UNSIGNED_LONG, Buffer_Recv_Face4, nBuffer_Scalar4, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_Face5, nBuffer_Scalar5, MPI_UNSIGNED_LONG, Buffer_Recv_Face5, nBuffer_Scalar5, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_Face6, nBuffer_Scalar6, MPI_UNSIGNED_LONG, Buffer_Recv_Face6, nBuffer_Scalar6, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_Face7, nBuffer_Scalar7, MPI_UNSIGNED_LONG, Buffer_Recv_Face7, nBuffer_Scalar7, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_Face8, nBuffer_Scalar8, MPI_UNSIGNED_LONG, Buffer_Recv_Face8, nBuffer_Scalar8, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_RNeigh, MaxLocalFace, MPI_LONG, Buffer_Recv_RNeigh, MaxLocalFace, MPI_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_LNeigh, MaxLocalFace, MPI_LONG, Buffer_Recv_LNeigh, MaxLocalFace, MPI_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_nNode, MaxLocalFace, MPI_UNSIGNED_LONG, Buffer_Recv_nNode, MaxLocalFace, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_GFace, MaxLocalFace, MPI_UNSIGNED_LONG, Buffer_Recv_GFace, MaxLocalFace, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_Halo, MaxLocalFace, MPI_LONG, Buffer_Recv_Halo, MaxLocalFace, MPI_LONG, MASTER_NODE, MPI_COMM_WORLD);
#else
    for(iPoint = 0; iPoint < nBuffer_Scalar3; iPoint++) Buffer_Recv_Face3[iPoint] = Buffer_Send_Face3[iPoint];
    for(iPoint = 0; iPoint < nBuffer_Scalar4; iPoint++) Buffer_Recv_Face4[iPoint] = Buffer_Send_Face4[iPoint];
    for(iPoint = 0; iPoint < nBuffer_Scalar5; iPoint++) Buffer_Recv_Face5[iPoint] = Buffer_Send_Face5[iPoint];
    for(iPoint = 0; iPoint < nBuffer_Scalar6; iPoint++) Buffer_Recv_Face6[iPoint] = Buffer_Send_Face6[iPoint];
    for(iPoint = 0; iPoint < nBuffer_Scalar7; iPoint++) Buffer_Recv_Face8[iPoint] = Buffer_Send_Face8[iPoint];
    for(iPoint = 0; iPoint < MaxLocalFace; iPoint++) Buffer_Recv_RNeigh[iPoint] = Buffer_Send_RNeigh[iPoint];
    for(iPoint = 0; iPoint < MaxLocalFace; iPoint++) Buffer_Recv_LNeigh[iPoint] = Buffer_Send_LNeigh[iPoint];
    for(iPoint = 0; iPoint < MaxLocalFace; iPoint++) Buffer_Recv_nNode[iPoint] = Buffer_Send_nNode[iPoint];
    for(iPoint = 0; iPoint < MaxLocalFace; iPoint++) Buffer_Recv_GFace[iPoint] = Buffer_Send_GFace[iPoint];
    for(iPoint = 0; iPoint < MaxLocalFace; iPoint++) Buffer_Recv_Halo[iPoint] = Buffer_Send_Halo[iPoint];
#endif

    delete [] Buffer_Send_Face3;
    delete [] Buffer_Send_Face4;
    delete [] Buffer_Send_Face5;
    delete [] Buffer_Send_Face6;
    delete [] Buffer_Send_Face7;
    delete [] Buffer_Send_Face8;
    delete [] Buffer_Send_RNeigh;
    delete [] Buffer_Send_LNeigh;
    delete [] Buffer_Send_nNode;
    delete [] Buffer_Send_GFace;
    delete [] Buffer_Send_Halo;

    if (rank == MASTER_NODE) {

        kFace = 0; nFace_Total=0;
        for (iProcessor = 0; iProcessor < size; iProcessor++) {
            for (iFace = 0; iFace < Buffer_Recv_nFace[iProcessor]; iFace++) {
                if(Buffer_Recv_Halo[kFace+iFace] == 1){
                    nFace_Total++;
                }
            }
            kFace = (iProcessor+1)*MaxLocalFace;
        }

        Conn_Polyhedron3 = new int*[3];
        for (iNode = 0; iNode < 3; iNode++) {
            Conn_Polyhedron3[iNode] = new int[nFace_Total];
        }
        Conn_Polyhedron4 = new int*[4];
        for (iNode = 0; iNode < 4; iNode++) {
            Conn_Polyhedron4[iNode] = new int[nFace_Total];
        }

        Conn_Polyhedron5 = new int*[5];
        for (iNode = 0; iNode < 5; iNode++) {
            Conn_Polyhedron5[iNode] = new int[nFace_Total];
        }

        Conn_Polyhedron6 = new int*[6];
        for (iNode = 0; iNode < 6; iNode++) {
            Conn_Polyhedron6[iNode] = new int[nFace_Total];
        }

        Conn_Polyhedron7 = new int*[7];
        for (iNode = 0; iNode < 7; iNode++) {
            Conn_Polyhedron7[iNode] = new int[nFace_Total];
        }

        Conn_Polyhedron8 = new int*[8];
        for (iNode = 0; iNode < 8; iNode++) {
            Conn_Polyhedron8[iNode] = new int[nFace_Total];
        }

        Conn_RNeighPolygon = new int [nFace_Total];
        Conn_LNeighPolygon = new int [nFace_Total];
        Conn_nNodePolyhedron = new int [nFace_Total];

        nFace_Total = 0; Total_nNode = 0; jFace = 0; kFace = 0;
        lNode3 = 0; lNode4 = 0; lNode5 = 0; lNode6 = 0; lNode7 = 0;
        kNode3 = 0; kNode4 = 0; kNode5 = 0; kNode6 = 0; kNode7 = 0; kNode8 = 0;
        int iGlobal_Index = 0;
        for (iProcessor = 0; iProcessor < size; iProcessor++) {
            jNode3 = 0; jNode4 = 0; jNode5 = 0; jNode6 = 0; jNode7 = 0; jNode8 = 0;
            for (iFace = 0; iFace < Buffer_Recv_nFace[iProcessor]; iFace++) {
                if(Buffer_Recv_Halo[kFace+iFace] == 1){
                    iGlobal_Index = Buffer_Recv_GFace[kFace+iFace];
                    Conn_RNeighPolygon[iGlobal_Index] = (int)Buffer_Recv_RNeigh[kFace+iFace]+1;
                    Conn_LNeighPolygon[iGlobal_Index] = (int)Buffer_Recv_LNeigh[kFace+iFace]+1;
                    Conn_nNodePolyhedron[iGlobal_Index] = (int)Buffer_Recv_nNode[kFace+iFace];

                    if(Conn_nNodePolyhedron[iGlobal_Index] == 3){
                        for(iNode = 0; iNode < 3; iNode++){
                            Conn_Polyhedron3[iNode][iGlobal_Index] = (int)Buffer_Recv_Face3[jNode3+kNode3]+1;
                            jNode3++; Total_nNode++;
                        }
                    }
                    if(Conn_nNodePolyhedron[iGlobal_Index] == 4){
                        for(iNode = 0; iNode < 4; iNode++){
                            Conn_Polyhedron4[iNode][iGlobal_Index] = (int)Buffer_Recv_Face4[jNode4+kNode4]+1;
                            jNode4++; Total_nNode++;
                        }
                    }
                    if(Conn_nNodePolyhedron[iGlobal_Index] == 5){
                        for(iNode = 0; iNode < 5; iNode++){
                            Conn_Polyhedron5[iNode][iGlobal_Index] = (int)Buffer_Recv_Face5[jNode5+kNode5]+1;
                            jNode5++; Total_nNode++;
                        }
                    }
                    if(Conn_nNodePolyhedron[iGlobal_Index] == 6){
                        for(iNode = 0; iNode < 6; iNode++){
                            Conn_Polyhedron6[iNode][iGlobal_Index] = (int)Buffer_Recv_Face6[jNode6+kNode6]+1;
                            jNode6++; Total_nNode++;
                        }
                    }
                    if(Conn_nNodePolyhedron[iGlobal_Index] == 7){
                        for(iNode = 0; iNode < 7; iNode++){
                            Conn_Polyhedron7[iNode][iGlobal_Index] = (int)Buffer_Recv_Face7[jNode7+kNode7]+1;
                            jNode7++; Total_nNode++;
                        }
                    }

                    if(Conn_nNodePolyhedron[iGlobal_Index] == 8){
                        for(iNode = 0; iNode < 8; iNode++){
                            Conn_Polyhedron8[iNode][iGlobal_Index] = (int)Buffer_Recv_Face8[jNode8+kNode8]+1;
                            jNode8++; Total_nNode++;
                        }
                    }


                    nFace_Total++; jFace++;
                }
            }
            kFace = (iProcessor+1)*MaxLocalFace;
            kNode3 = (iProcessor+1)*nBuffer_Scalar3;
            kNode4 = (iProcessor+1)*nBuffer_Scalar4;
            kNode5 = (iProcessor+1)*nBuffer_Scalar5;
            kNode6 = (iProcessor+1)*nBuffer_Scalar6;
            kNode7 = (iProcessor+1)*nBuffer_Scalar7;
            kNode8 = (iProcessor+1)*nBuffer_Scalar8;

        }
    }

    if (rank == MASTER_NODE){
        delete [] Buffer_Recv_nFace;
        delete [] Buffer_Recv_Face3;
        delete [] Buffer_Recv_Face4;
        delete [] Buffer_Recv_Face5;
        delete [] Buffer_Recv_Face6;
        delete [] Buffer_Recv_Face7;
        delete [] Buffer_Recv_Face8;
        delete [] Buffer_Recv_RNeigh;
        delete [] Buffer_Recv_LNeigh;
        delete [] Buffer_Recv_nNode;
        delete [] Buffer_Recv_GFace;
        delete [] Buffer_Recv_Halo;
    }

    if (rank == MASTER_NODE) {
        nGlobal_Polyhedron = nFace_Total;
        TOTALNUMFACENODESII = Total_nNode;
        NumConnectedBoundaryFaces = 0;
        TotalNumBoundaryConnections = 0;
    }
    //##Merge Boundary Connectivity##//
    unsigned short iMarker = 0;
    unsigned long iElem_Bound = 0, nLocalFaceSurf, MaxLocalFaceSurf = 0;
    unsigned long Buffer_Send_nFaceSurf[1], *Buffer_Recv_nFaceSurf = NULL;

    nLocalFaceSurf = 0; iFace = 0;
    for (iMarker = 0; iMarker < config->GetnMarker_All(); iMarker++){
        if (config->GetMarker_All_Plotting(iMarker) == YES){
            for(iElem_Bound = 0; iElem_Bound < geometry->GetnElem_Bound(iMarker); iElem_Bound++) {

                iFace = geometry->bound[iMarker][iElem_Bound]->GetGlobalFace();
                nLocalFaceSurf++;
            }
        }
    }

    Buffer_Send_nFaceSurf[0] = nLocalFaceSurf;

    if (rank == MASTER_NODE){
        Buffer_Recv_nFaceSurf = new unsigned long[size];
    }

#ifdef HAVE_MPI
    MPI_Allreduce(&nLocalFaceSurf, &MaxLocalFaceSurf, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);
    MPI_Gather(&Buffer_Send_nFaceSurf, 1, MPI_UNSIGNED_LONG, Buffer_Recv_nFaceSurf, 1, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
#else
    MaxLocalFaceSurf = nLocalFaceSurf;
    Buffer_Recv_nFaceSurf[0] = Buffer_Send_nFaceSurf[0];

#endif

    unsigned long *Buffer_Send_GFaceSurf = new unsigned long[MaxLocalFaceSurf];
    unsigned long *Buffer_Recv_GFaceSurf = NULL;

    long *Buffer_Send_HaloSurf = new long[MaxLocalFaceSurf];
    long *Buffer_Recv_HaloSurf = NULL;

    if (rank == MASTER_NODE) {
        Buffer_Recv_GFaceSurf = new unsigned long[size*MaxLocalFaceSurf];
        Buffer_Recv_HaloSurf = new long[size*MaxLocalFaceSurf];
    }

    jFace = 0;
    for (iMarker = 0; iMarker < config->GetnMarker_All(); iMarker++){
        if (config->GetMarker_All_Plotting(iMarker) == YES){
            for(iElem_Bound = 0; iElem_Bound < geometry->GetnElem_Bound(iMarker); iElem_Bound++) {

                iFace = geometry->bound[iMarker][iElem_Bound]->GetGlobalFace();

                if((geometry->elem[geometry->face[iFace]->GetElems(0)]->GetColor() == rank)){
                    Buffer_Send_HaloSurf[jFace] = 1;//iFace;
                }
                jFace++;
            }
        }
    }

    jFace = 0;
    for (iMarker = 0; iMarker < config->GetnMarker_All(); iMarker++){
        if (config->GetMarker_All_Plotting(iMarker) == YES){
            for(iElem_Bound = 0; iElem_Bound < geometry->GetnElem_Bound(iMarker); iElem_Bound++) {

                iFace = geometry->bound[iMarker][iElem_Bound]->GetGlobalFace();

                if(Buffer_Send_HaloSurf[jFace] == 1){

                    Buffer_Send_GFaceSurf[jFace] = geometry->face[iFace]->GetGlobalIndex();

                }
                jFace++;
            }
        }
    }

#ifdef HAVE_MPI
    MPI_Gather(Buffer_Send_GFaceSurf, MaxLocalFaceSurf, MPI_UNSIGNED_LONG, Buffer_Recv_GFaceSurf, MaxLocalFaceSurf, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_HaloSurf, MaxLocalFaceSurf, MPI_LONG, Buffer_Recv_HaloSurf, MaxLocalFaceSurf, MPI_LONG, MASTER_NODE, MPI_COMM_WORLD);
#else
    for(iPoint = 0; iPoint < MaxLocalFaceSurf; iPoint++) Buffer_Recv_GFaceSurf[iPoint] = Buffer_Send_GFaceSurf[iPoint];
    for(iPoint = 0; iPoint < MaxLocalFaceSurf; iPoint++) Buffer_Recv_HaloSurf[iPoint] = Buffer_Send_HaloSurf[iPoint];
#endif

    delete [] Buffer_Send_GFaceSurf;
    delete [] Buffer_Send_HaloSurf;

    if (rank == MASTER_NODE) {

        Start_Face = 0; End_Face = 0;

        kFace = 0; nFace_TotalSurf=0;
        for (iProcessor = 0; iProcessor < size; iProcessor++) {
            for (iFace = 0; iFace < Buffer_Recv_nFaceSurf[iProcessor]; iFace++) {
                if(Buffer_Recv_HaloSurf[kFace+iFace] == 1){
                    nFace_TotalSurf++;
                }
            }
            kFace = (iProcessor+1)*MaxLocalFaceSurf;
        }

        End_Face = 1;//Buffer_Recv_GFaceSurf[1];
        jFace = 0; kFace = 0;
        for (iProcessor = 0; iProcessor < size; iProcessor++) {
            for (iFace = 0; iFace < Buffer_Recv_nFaceSurf[iProcessor]; iFace++) {
                if(Buffer_Recv_HaloSurf[kFace+iFace] == 1){

                    iGlobal_Index = Buffer_Recv_GFaceSurf[kFace+iFace];
                    if(Buffer_Recv_GFaceSurf[kFace+iFace] > End_Face){ End_Face = Buffer_Recv_GFaceSurf[kFace+iFace];}
                    jFace++;
                }
            }

            kFace = (iProcessor+1)*MaxLocalFaceSurf;
        }
        Start_Face = End_Face-nFace_TotalSurf+1;
    }

    if (rank == MASTER_NODE){
        delete [] Buffer_Recv_nFaceSurf;
        delete [] Buffer_Recv_GFaceSurf;
        delete [] Buffer_Recv_HaloSurf;
    }

    if (rank == MASTER_NODE) {
        nSurf_Elem = nFace_TotalSurf;
        cout<<"Merge Boundary and Volumetric Connectivity is Done   "<<endl;
    }
}


void COutput::MergeSurfaceConnectivity(CConfig *config, CGeometry *geometry) {

    int iProcessor;
    unsigned short nDim = 3, iDim =0;
    unsigned long iNode, iPoint, jPoint, jNode3=0, jNode4=0, jNode5=0, jNode6=0, jNode7=0, jNode8=0, lNode3, lNode4, lNode5, lNode6, lNode7, iGlobal_Index,
            kNode3, kNode4, kNode5, kNode6, kNode7, kNode8;
    unsigned long iElem = 0, iFace = 0, jFace, jElem, kFace;
    unsigned long nPoint_Total, nLocalElem = 0, nLocalFace = 0, nLocalPoint = 0, nFace_Total, Total_nNode;
    unsigned long nLocalFace3=0, nLocalFace4=0, nLocalFace5=0, nLocalFace6=0, nLocalFace7=0, nLocalFace8=0;
    unsigned long Buffer_Send_nElem[1], *Buffer_Recv_nElem = NULL;
    unsigned long Buffer_Send_nFace[1], *Buffer_Recv_nFace = NULL;
    unsigned long Buffer_Send_nFace3[1], *Buffer_Recv_nFace3 = NULL;
    unsigned long Buffer_Send_nFace4[1], *Buffer_Recv_nFace4 = NULL;
    unsigned long Buffer_Send_nFace5[1], *Buffer_Recv_nFace5 = NULL;
    unsigned long Buffer_Send_nFace6[1], *Buffer_Recv_nFace6 = NULL;
    unsigned long Buffer_Send_nFace7[1], *Buffer_Recv_nFace7 = NULL;
    unsigned long Buffer_Send_nFace8[1], *Buffer_Recv_nFace8 = NULL;
    unsigned long Buffer_Send_nPoint[1], *Buffer_Recv_nPoint = NULL;
    unsigned long nBuffer_Scalar3 = 0, nBuffer_Scalar4 = 0,nBuffer_Scalar5 = 0,nBuffer_Scalar6 = 0,nBuffer_Scalar7 = 0,
            nBuffer_Scalar8 = 0;
    unsigned long MaxLocalElem,MaxLocalFace, MaxLocalPoint;
    unsigned long MaxLocalFace3,MaxLocalFace4, MaxLocalFace5, MaxLocalFace6, MaxLocalFace7, MaxLocalFace8;
    int rank = MASTER_NODE;
    int size = SINGLE_NODE;

#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
#endif

    for(iFace = 0; iFace < geometry->GetnFace(); iFace++){
        if(geometry->face[iFace]->GetnNodes_Face()==3) nLocalFace3++;
        if(geometry->face[iFace]->GetnNodes_Face()==4) nLocalFace4++;
        if(geometry->face[iFace]->GetnNodes_Face()==5) nLocalFace5++;
        if(geometry->face[iFace]->GetnNodes_Face()==6) nLocalFace6++;
        if(geometry->face[iFace]->GetnNodes_Face()==7) nLocalFace7++;
        if(geometry->face[iFace]->GetnNodes_Face()==8) nLocalFace8++;
    }

    nLocalFace = geometry->GetnFace();
    nLocalElem = geometry->GetnElem();
    nLocalPoint = geometry->GetnPoint();

    Buffer_Send_nElem[0] = nLocalElem;
    Buffer_Send_nFace[0] = nLocalFace;
    Buffer_Send_nFace3[0] = nLocalFace3;
    Buffer_Send_nFace4[0] = nLocalFace4;
    Buffer_Send_nFace5[0] = nLocalFace5;
    Buffer_Send_nFace6[0] = nLocalFace6;
    Buffer_Send_nFace7[0] = nLocalFace7;
    Buffer_Send_nFace8[0] = nLocalFace8;
    Buffer_Send_nPoint[0] = nLocalPoint;

    if (rank == MASTER_NODE){
        Buffer_Recv_nElem = new unsigned long[size];
        Buffer_Recv_nFace = new unsigned long[size];
        Buffer_Recv_nFace3 = new unsigned long[size];
        Buffer_Recv_nFace4 = new unsigned long[size];
        Buffer_Recv_nFace5 = new unsigned long[size];
        Buffer_Recv_nFace6 = new unsigned long[size];
        Buffer_Recv_nFace7 = new unsigned long[size];
        Buffer_Recv_nFace8 = new unsigned long[size];
        Buffer_Recv_nPoint = new unsigned long[size];
    }

#ifdef HAVE_MPI
    MPI_Allreduce(&nLocalElem, &MaxLocalElem, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);
    MPI_Allreduce(&nLocalFace, &MaxLocalFace, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);
    MPI_Allreduce(&nLocalFace3, &MaxLocalFace3, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);
    MPI_Allreduce(&nLocalFace4, &MaxLocalFace4, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);
    MPI_Allreduce(&nLocalFace5, &MaxLocalFace5, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);
    MPI_Allreduce(&nLocalFace6, &MaxLocalFace6, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);
    MPI_Allreduce(&nLocalFace7, &MaxLocalFace7, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);
    MPI_Allreduce(&nLocalFace8, &MaxLocalFace8, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);
    MPI_Allreduce(&nLocalPoint, &MaxLocalPoint, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);

    MPI_Gather(&Buffer_Send_nElem, 1, MPI_UNSIGNED_LONG, Buffer_Recv_nElem, 1, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(&Buffer_Send_nFace, 1, MPI_UNSIGNED_LONG, Buffer_Recv_nFace, 1, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(&Buffer_Send_nFace3, 1, MPI_UNSIGNED_LONG, Buffer_Recv_nFace3, 1, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(&Buffer_Send_nFace4, 1, MPI_UNSIGNED_LONG, Buffer_Recv_nFace4, 1, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(&Buffer_Send_nFace5, 1, MPI_UNSIGNED_LONG, Buffer_Recv_nFace5, 1, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(&Buffer_Send_nFace6, 1, MPI_UNSIGNED_LONG, Buffer_Recv_nFace6, 1, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(&Buffer_Send_nFace7, 1, MPI_UNSIGNED_LONG, Buffer_Recv_nFace7, 1, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(&Buffer_Send_nFace8, 1, MPI_UNSIGNED_LONG, Buffer_Recv_nFace8, 1, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(&Buffer_Send_nPoint, 1, MPI_UNSIGNED_LONG, Buffer_Recv_nPoint, 1, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);

#else
    MaxLocalElem = nLocalElem;
    MaxLocalFace = nLocalFace;
    MaxLocalFace3 = nLocalFace3;
    MaxLocalFace4 = nLocalFace4;
    MaxLocalFace5 = nLocalFace5;
    MaxLocalFace6 = nLocalFace6;
    MaxLocalFace7 = nLocalFace7;
    MaxLocalFace8 = nLocalFace8;
    MaxLocalPoint = nLocalPoint;
    Buffer_Recv_nElem[0] = Buffer_Send_nElem[0];
    Buffer_Recv_nFace[0] = Buffer_Send_nFace[0];
    Buffer_Recv_nPoint[0] = Buffer_Send_nPoint[0];

#endif
    nBuffer_Scalar3 = MaxLocalFace3*3;
    nBuffer_Scalar4 = MaxLocalFace4*4;
    nBuffer_Scalar5 = MaxLocalFace5*5;
    nBuffer_Scalar6 = MaxLocalFace6*6;
    nBuffer_Scalar7 = MaxLocalFace7*7;
    nBuffer_Scalar8 = MaxLocalFace8*8;

    unsigned long *Buffer_Send_nNode = new unsigned long[MaxLocalFace];
    unsigned long *Buffer_Recv_nNode = NULL;

    unsigned long *Buffer_Send_Face3 = new unsigned long[nBuffer_Scalar3];
    unsigned long *Buffer_Recv_Face3 = NULL;

    unsigned long *Buffer_Send_Face4 = new unsigned long[nBuffer_Scalar4];
    unsigned long *Buffer_Recv_Face4 = NULL;

    unsigned long *Buffer_Send_Face5 = new unsigned long[nBuffer_Scalar5];
    unsigned long *Buffer_Recv_Face5 = NULL;

    unsigned long *Buffer_Send_Face6 = new unsigned long[nBuffer_Scalar6];
    unsigned long *Buffer_Recv_Face6 = NULL;

    unsigned long *Buffer_Send_Face7 = new unsigned long[nBuffer_Scalar7];
    unsigned long *Buffer_Recv_Face7 = NULL;

    unsigned long *Buffer_Send_Face8 = new unsigned long[nBuffer_Scalar8];
    unsigned long *Buffer_Recv_Face8 = NULL;

    long *Buffer_Send_RNeigh = new long[MaxLocalFace];
    long *Buffer_Recv_RNeigh = NULL;

    long *Buffer_Send_LNeigh = new long[MaxLocalFace];
    long *Buffer_Recv_LNeigh = NULL;

    unsigned long *Buffer_Send_GFace = new unsigned long[MaxLocalFace];
    unsigned long *Buffer_Recv_GFace = NULL;

    long *Buffer_Send_Halo = new long[MaxLocalFace];
    long *Buffer_Recv_Halo = NULL;

    long *Buffer_Send_Point = new long[MaxLocalPoint];
    long *Buffer_Recv_Point = NULL;

    double *Buffer_Send_X = new double[MaxLocalPoint];
    double *Buffer_Recv_X = NULL;

    double *Buffer_Send_Y = new double[MaxLocalPoint];
    double *Buffer_Recv_Y = NULL;

    double *Buffer_Send_Z, *Buffer_Recv_Z = NULL;
    Buffer_Send_Z = new double[MaxLocalPoint];

    if (rank == MASTER_NODE) {
        Buffer_Recv_Face3 = new unsigned long[size*nBuffer_Scalar3];
        Buffer_Recv_Face4 = new unsigned long[size*nBuffer_Scalar4];
        Buffer_Recv_Face5 = new unsigned long[size*nBuffer_Scalar5];
        Buffer_Recv_Face6 = new unsigned long[size*nBuffer_Scalar6];
        Buffer_Recv_Face7 = new unsigned long[size*nBuffer_Scalar7];
        Buffer_Recv_Face8 = new unsigned long[size*nBuffer_Scalar8];
        Buffer_Recv_RNeigh = new long[size*MaxLocalFace];
        Buffer_Recv_LNeigh = new long[size*MaxLocalFace];
        Buffer_Recv_nNode = new unsigned long[size*MaxLocalFace];
        Buffer_Recv_GFace = new unsigned long[size*MaxLocalFace];
        Buffer_Recv_Halo = new long[size*MaxLocalFace];
        Buffer_Recv_Point = new long[size*MaxLocalPoint];
        Buffer_Recv_X = new double[size*MaxLocalPoint];
        Buffer_Recv_Y = new double[size*MaxLocalPoint];
        Buffer_Recv_Z = new double[size*MaxLocalPoint];
    }

    jPoint = 0;
    for(iPoint = 0; iPoint < geometry->GetnPoint(); iPoint++){
        Buffer_Send_Point[jPoint] = geometry->node[iPoint]->GetGlobalIndex();
        Buffer_Send_X[jPoint] = geometry->node[iPoint]->GetCoord(0);
        Buffer_Send_Y[jPoint] = geometry->node[iPoint]->GetCoord(1);
        Buffer_Send_Z[jPoint] = geometry->node[iPoint]->GetCoord(2);
        jPoint++;
    }

#ifdef HAVE_MPI
    MPI_Gather(Buffer_Send_Point, MaxLocalPoint, MPI_UNSIGNED_LONG, Buffer_Recv_Point, MaxLocalPoint, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_X, MaxLocalPoint, MPI_DOUBLE, Buffer_Recv_X, MaxLocalPoint, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_Y, MaxLocalPoint, MPI_DOUBLE, Buffer_Recv_Y, MaxLocalPoint, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_Z, MaxLocalPoint, MPI_DOUBLE, Buffer_Recv_Z, MaxLocalPoint, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
#else
    for(iPoint = 0; iPoint < MaxLocalPoint; iPoint++) Buffer_Recv_Point[iPoint] = Buffer_Send_Point[iPoint];
    for(iPoint = 0; iPoint < MaxLocalPoint; iPoint++) Buffer_Recv_X[iPoint] = Buffer_Send_X[iPoint];
    for(iPoint = 0; iPoint < MaxLocalPoint; iPoint++) Buffer_Recv_Y[iPoint] = Buffer_Send_Y[iPoint];
    for(iPoint = 0; iPoint < MaxLocalPoint; iPoint++) Buffer_Recv_Z[iPoint] = Buffer_Send_Z[iPoint];
#endif

    delete [] Buffer_Send_Point;
    delete [] Buffer_Send_X;
    delete [] Buffer_Send_Y;
    delete [] Buffer_Send_Z;
    if(rank == MASTER_NODE){
        unsigned long *ncount = new unsigned long[MaxLocalPoint*size];
        for(iPoint = 0; iPoint < MaxLocalPoint*size; iPoint++) ncount[iPoint]=0;

        jPoint = 0; nPoint_Total = 0;
        for(iProcessor = 0; iProcessor < size; iProcessor++){
            for(iPoint = 0; iPoint < Buffer_Recv_nPoint[iProcessor]; iPoint++){

                ncount[Buffer_Recv_Point[iPoint+jPoint]]++;
                if(ncount[Buffer_Recv_Point[iPoint+jPoint]]==1){
                    nPoint_Total++;
                }
            }
            jPoint = (iProcessor+1)*MaxLocalPoint;
        }
        nGlobal_Poin = nPoint_Total;

        Coords = new double*[nDim];
        for (iDim = 0; iDim < nDim; iDim++) {
            Coords[iDim] = new double[nGlobal_Poin];
        }

        for(iPoint = 0; iPoint < MaxLocalPoint*size; iPoint++) ncount[iPoint]=0;

        jPoint = 0; nPoint_Total = 0;
        for(iProcessor = 0; iProcessor < size; iProcessor++){
            for(iPoint = 0; iPoint < Buffer_Recv_nPoint[iProcessor]; iPoint++){
                ncount[Buffer_Recv_Point[iPoint+jPoint]]++;
                if(ncount[Buffer_Recv_Point[iPoint+jPoint]]==1){
                    iGlobal_Index = Buffer_Recv_Point[iPoint+jPoint];
                    Coords[0][iGlobal_Index] = Buffer_Recv_X[iPoint+jPoint];
                    Coords[1][iGlobal_Index] = Buffer_Recv_Y[iPoint+jPoint];
                    Coords[2][iGlobal_Index] = Buffer_Recv_Z[iPoint+jPoint];
                    nPoint_Total++;
                }
            }
            jPoint = (iProcessor+1)*MaxLocalPoint;
        }

        nGlobal_Poin = nPoint_Total;
        delete [] ncount;
        delete [] Buffer_Recv_nPoint;
        delete [] Buffer_Recv_Point;
        delete [] Buffer_Recv_X;
        delete [] Buffer_Recv_Y;
        delete [] Buffer_Recv_Z;
    }

    jFace = 0;
    for(iFace = 0; iFace < geometry->GetnFace(); iFace++){
        Buffer_Send_Halo[jFace] = -1;
        if((geometry->elem[geometry->face[iFace]->GetElems(0)]->GetColor() == rank)){
            if(geometry->face[iFace]->GetElems(1) != -1){
                if((geometry->elem[geometry->face[iFace]->GetElems(1)]->GetColor() > rank)||(geometry->elem[geometry->face[iFace]->GetElems(1)]->GetColor() == rank)){
                    Buffer_Send_Halo[jFace] = 1;//iFace;
                }
            }
            if(geometry->face[iFace]->GetElems(1) == -1){
                if((geometry->elem[geometry->face[iFace]->GetElems(0)]->GetColor() == rank)){
                    Buffer_Send_Halo[jFace] = 1;//iFace;
                }
            }
        }

        else if((geometry->face[iFace]->GetElems(1) != -1) &&(geometry->elem[geometry->face[iFace]->GetElems(1)]->GetColor() == rank)){
            if((geometry->elem[geometry->face[iFace]->GetElems(0)]->GetColor() == rank)||(geometry->elem[geometry->face[iFace]->GetElems(0)]->GetColor() > rank)){
                Buffer_Send_Halo[jFace] = 1;//iFace;
            }
        }
        jFace++;
    }

    jNode3 = 0; jNode4 = 0; jNode5 = 0; jNode6 = 0; jNode7 = 0; jNode8 = 0; jFace = 0;
    for(iFace = 0; iFace < geometry->GetnFace(); iFace++){
        if(Buffer_Send_Halo[jFace] == 1){
            Buffer_Send_GFace[jFace] = geometry->face[iFace]->GetGlobalIndex();
            Buffer_Send_nNode[jFace] = geometry->face[iFace]->GetnNodes_Face();
            jElem = geometry->elem[geometry->face[iFace]->GetElems(0)]->GetGlobalIndex();
            Buffer_Send_LNeigh[jFace] = jElem;

            if(geometry->face[iFace]->GetElems(1)!=-1){
                iElem = geometry->elem[geometry->face[iFace]->GetElems(1)]->GetGlobalIndex();
                Buffer_Send_RNeigh[jFace] = iElem;
            }
            else if(geometry->face[iFace]->GetElems(1)==-1){
                Buffer_Send_RNeigh[jFace] = -1;
            }

            if( Buffer_Send_nNode[jFace]==3){
                for(iNode = 0; iNode < 3; iNode++){
                    Buffer_Send_Face3[jNode3] = geometry->node[geometry->face[iFace]->GetNode_Face(iNode)]->GetGlobalIndex();
                    jNode3++;
                }
            }
            if( Buffer_Send_nNode[jFace]==4){
                for(iNode = 0; iNode < 4; iNode++){
                    Buffer_Send_Face4[jNode4] = geometry->node[geometry->face[iFace]->GetNode_Face(iNode)]->GetGlobalIndex();
                    jNode4++;
                }
            }
            if( Buffer_Send_nNode[jFace]==5){
                for(iNode = 0; iNode < 5; iNode++){
                    Buffer_Send_Face5[jNode5] = geometry->node[geometry->face[iFace]->GetNode_Face(iNode)]->GetGlobalIndex();
                    jNode5++;
                }
            }
            if( Buffer_Send_nNode[jFace]==6){
                for(iNode = 0; iNode < 6; iNode++){
                    Buffer_Send_Face6[jNode6] = geometry->node[geometry->face[iFace]->GetNode_Face(iNode)]->GetGlobalIndex();
                    jNode6++;
                }
            }
            if( Buffer_Send_nNode[jFace]==7){
                for(iNode = 0; iNode < 7; iNode++){
                    Buffer_Send_Face7[jNode7] = geometry->node[geometry->face[iFace]->GetNode_Face(iNode)]->GetGlobalIndex();
                    jNode7++;
                }
            }
            if( Buffer_Send_nNode[jFace]==8){
                for(iNode = 0; iNode < 8; iNode++){
                    Buffer_Send_Face8[jNode8] = geometry->node[geometry->face[iFace]->GetNode_Face(iNode)]->GetGlobalIndex();
                    jNode8++;
                }
            }

        }
        jFace++;
    }

#ifdef HAVE_MPI
    MPI_Gather(Buffer_Send_Face3, nBuffer_Scalar3, MPI_UNSIGNED_LONG, Buffer_Recv_Face3, nBuffer_Scalar3, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_Face4, nBuffer_Scalar4, MPI_UNSIGNED_LONG, Buffer_Recv_Face4, nBuffer_Scalar4, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_Face5, nBuffer_Scalar5, MPI_UNSIGNED_LONG, Buffer_Recv_Face5, nBuffer_Scalar5, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_Face6, nBuffer_Scalar6, MPI_UNSIGNED_LONG, Buffer_Recv_Face6, nBuffer_Scalar6, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_Face7, nBuffer_Scalar7, MPI_UNSIGNED_LONG, Buffer_Recv_Face7, nBuffer_Scalar7, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_Face8, nBuffer_Scalar8, MPI_UNSIGNED_LONG, Buffer_Recv_Face8, nBuffer_Scalar8, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_RNeigh, MaxLocalFace, MPI_LONG, Buffer_Recv_RNeigh, MaxLocalFace, MPI_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_LNeigh, MaxLocalFace, MPI_LONG, Buffer_Recv_LNeigh, MaxLocalFace, MPI_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_nNode, MaxLocalFace, MPI_UNSIGNED_LONG, Buffer_Recv_nNode, MaxLocalFace, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_GFace, MaxLocalFace, MPI_UNSIGNED_LONG, Buffer_Recv_GFace, MaxLocalFace, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
    MPI_Gather(Buffer_Send_Halo, MaxLocalFace, MPI_LONG, Buffer_Recv_Halo, MaxLocalFace, MPI_LONG, MASTER_NODE, MPI_COMM_WORLD);
#else
    for(iPoint = 0; iPoint < nBuffer_Scalar3; iPoint++) Buffer_Recv_Face3[iPoint] = Buffer_Send_Face3[iPoint];
    for(iPoint = 0; iPoint < nBuffer_Scalar4; iPoint++) Buffer_Recv_Face4[iPoint] = Buffer_Send_Face4[iPoint];
    for(iPoint = 0; iPoint < nBuffer_Scalar5; iPoint++) Buffer_Recv_Face5[iPoint] = Buffer_Send_Face5[iPoint];
    for(iPoint = 0; iPoint < nBuffer_Scalar6; iPoint++) Buffer_Recv_Face6[iPoint] = Buffer_Send_Face6[iPoint];
    for(iPoint = 0; iPoint < nBuffer_Scalar7; iPoint++) Buffer_Recv_Face7[iPoint] = Buffer_Send_Face7[iPoint];
    for(iPoint = 0; iPoint < nBuffer_Scalar8; iPoint++) Buffer_Recv_Face8[iPoint] = Buffer_Send_Face8[iPoint];

    for(iPoint = 0; iPoint < MaxLocalFace; iPoint++) Buffer_Recv_RNeigh[iPoint] = Buffer_Send_RNeigh[iPoint];
    for(iPoint = 0; iPoint < MaxLocalFace; iPoint++) Buffer_Recv_LNeigh[iPoint] = Buffer_Send_LNeigh[iPoint];
    for(iPoint = 0; iPoint < MaxLocalFace; iPoint++) Buffer_Recv_nNode[iPoint] = Buffer_Send_nNode[iPoint];
    for(iPoint = 0; iPoint < MaxLocalFace; iPoint++) Buffer_Recv_GFace[iPoint] = Buffer_Send_GFace[iPoint];
    for(iPoint = 0; iPoint < MaxLocalFace; iPoint++) Buffer_Recv_Halo[iPoint] = Buffer_Send_Halo[iPoint];
#endif

    delete [] Buffer_Send_Face3;
    delete [] Buffer_Send_Face4;
    delete [] Buffer_Send_Face5;
    delete [] Buffer_Send_Face6;
    delete [] Buffer_Send_Face7;
    delete [] Buffer_Send_Face8;
    delete [] Buffer_Send_RNeigh;
    delete [] Buffer_Send_LNeigh;
    delete [] Buffer_Send_nNode;
    delete [] Buffer_Send_GFace;
    delete [] Buffer_Send_Halo;

    if (rank == MASTER_NODE) {

        kFace = 0; nFace_Total=0;
        for (iProcessor = 0; iProcessor < size; iProcessor++) {
            for (iFace = 0; iFace < Buffer_Recv_nFace[iProcessor]; iFace++) {
                if(Buffer_Recv_Halo[kFace+iFace] == 1){
                    nFace_Total++;
                }
            }
            kFace = (iProcessor+1)*MaxLocalFace;
        }

        Conn_Polygon3 = new int*[3];
        for (iNode = 0; iNode < 3; iNode++) {
            Conn_Polygon3[iNode] = new int[nFace_Total];
        }
        Conn_Polygon4 = new int*[4];
        for (iNode = 0; iNode < 4; iNode++) {
            Conn_Polygon4[iNode] = new int[nFace_Total];
        }

        Conn_Polygon5 = new int*[5];
        for (iNode = 0; iNode < 5; iNode++) {
            Conn_Polygon5[iNode] = new int[nFace_Total];
        }

        Conn_Polygon6 = new int*[6];
        for (iNode = 0; iNode < 6; iNode++) {
            Conn_Polygon6[iNode] = new int[nFace_Total];
        }

        Conn_Polygon7 = new int*[7];
        for (iNode = 0; iNode < 7; iNode++) {
            Conn_Polygon7[iNode] = new int[nFace_Total];
        }

        Conn_Polygon8 = new int*[8];
        for (iNode = 0; iNode < 8; iNode++) {
            Conn_Polygon8[iNode] = new int[nFace_Total];
        }

        Conn_RNeighPoly = new int [nFace_Total];
        Conn_LNeighPoly = new int [nFace_Total];
        Conn_nNodePolygon = new int [nFace_Total];

        nFace_Total = 0; Total_nNode = 0; jFace = 0; kFace = 0;
        lNode3 = 0; lNode4 = 0; lNode5 = 0; lNode6 = 0; lNode7 = 0;
        kNode3 = 0; kNode4 = 0; kNode5 = 0; kNode6 = 0; kNode7 = 0; kNode8 = 0;
        int iGlobal_Index = 0;
        for (iProcessor = 0; iProcessor < size; iProcessor++) {
            jNode3 = 0; jNode4 = 0; jNode5 = 0; jNode6 = 0; jNode7 = 0; jNode8 = 0;
            for (iFace = 0; iFace < Buffer_Recv_nFace[iProcessor]; iFace++) {
                if(Buffer_Recv_Halo[kFace+iFace] == 1){
                    iGlobal_Index = Buffer_Recv_GFace[kFace+iFace];

                    Conn_RNeighPoly[iGlobal_Index] = (int)Buffer_Recv_RNeigh[kFace+iFace]+1;
                    Conn_LNeighPoly[iGlobal_Index] = (int)Buffer_Recv_LNeigh[kFace+iFace]+1;
                    Conn_nNodePolygon[iGlobal_Index] = (int)Buffer_Recv_nNode[kFace+iFace];

                    if(Conn_nNodePolygon[iGlobal_Index] == 3){
                        for(iNode = 0; iNode < 3; iNode++){
                            Conn_Polygon3[iNode][iGlobal_Index] = (int)Buffer_Recv_Face3[jNode3+kNode3]+1;
                            jNode3++; Total_nNode++;
                        }
                    }
                    if(Conn_nNodePolygon[iGlobal_Index] == 4){
                        for(iNode = 0; iNode < 4; iNode++){
                            Conn_Polygon4[iNode][iGlobal_Index] = (int)Buffer_Recv_Face4[jNode4+kNode4]+1;
                            jNode4++; Total_nNode++;
                        }
                    }
                    if(Conn_nNodePolygon[iGlobal_Index] == 5){
                        for(iNode = 0; iNode < 5; iNode++){
                            Conn_Polygon5[iNode][iGlobal_Index] = (int)Buffer_Recv_Face5[jNode5+kNode5]+1;
                            jNode5++; Total_nNode++;
                        }
                    }
                    if(Conn_nNodePolygon[iGlobal_Index] == 6){
                        for(iNode = 0; iNode < 6; iNode++){
                            Conn_Polygon6[iNode][iGlobal_Index] = (int)Buffer_Recv_Face6[jNode6+kNode6]+1;
                            jNode6++; Total_nNode++;
                        }
                    }
                    if(Conn_nNodePolygon[iGlobal_Index] == 7){
                        for(iNode = 0; iNode < 7; iNode++){
                            Conn_Polygon7[iNode][iGlobal_Index] = (int)Buffer_Recv_Face7[jNode7+kNode7]+1;
                            jNode7++; Total_nNode++;
                        }
                    }
                    if(Conn_nNodePolygon[iGlobal_Index] == 8){
                        for(iNode = 0; iNode < 8; iNode++){
                            Conn_Polygon8[iNode][iGlobal_Index] = (int)Buffer_Recv_Face8[jNode8+kNode8]+1;
                            jNode8++; Total_nNode++;
                        }
                    }
                    nFace_Total++; jFace++;
                }
            }

            kFace = (iProcessor+1)*MaxLocalFace;
            kNode3 = (iProcessor+1)*nBuffer_Scalar3;
            kNode4 = (iProcessor+1)*nBuffer_Scalar4;
            kNode5 = (iProcessor+1)*nBuffer_Scalar5;
            kNode6 = (iProcessor+1)*nBuffer_Scalar6;
            kNode7 = (iProcessor+1)*nBuffer_Scalar7;
            kNode8 = (iProcessor+1)*nBuffer_Scalar8;
        }
        delete [] Buffer_Recv_nFace;
        delete [] Buffer_Recv_Face3;
        delete [] Buffer_Recv_Face4;
        delete [] Buffer_Recv_Face5;
        delete [] Buffer_Recv_Face6;
        delete [] Buffer_Recv_Face7;
        delete [] Buffer_Recv_Face8;
        delete [] Buffer_Recv_RNeigh;
        delete [] Buffer_Recv_LNeigh;
        delete [] Buffer_Recv_nNode;
        delete [] Buffer_Recv_GFace;
        delete [] Buffer_Recv_Halo;
    }

    if (rank == MASTER_NODE) {
        nSurf_Elem = nFace_Total;
        TOTALNUMFACENODESIII = Total_nNode;
        NumConnectedBoundaryFaces = 0;
        TotalNumBoundaryConnections = 0;
    }
}

void COutput::MergeSolution(CConfig *config, CGeometry *geometry, CSolver **solver, unsigned short val_iZone) {

    unsigned short Kind_Solver  = config->GetKind_Solver();
    unsigned short iVar = 0, jVar = 0, FirstIndex = NONE, SecondIndex = NONE, ThirdIndex = NONE;
    unsigned short nVar_First = 0, nVar_Second = 0, nVar_Third = 0;
    unsigned short iVar_GridVel = 0, iVar_PressCp = 0, iVar_Lam = 0, iVar_MachMean = 0,
            iVar_ViscCoeffs = 0, iVar_Extra = 0, iVar_Eddy = 0, iVar_Sharp = 0;

    unsigned long iPoint = 0, jPoint = 0, iVertex = 0, iMarker = 0;
    double Gas_Constant, Mach2Vel, Mach_Motion, RefDensity, RefPressure = 0.0, factor = 0.0;

    double *Aux_Frict = NULL, *Aux_Heat = NULL, *Aux_yPlus = NULL, *Aux_Sens = NULL;

    unsigned short CurrentIndex;
    unsigned long Buffer_Send_nElem[1], *Buffer_Recv_nElem = NULL;
    unsigned long nLocalElem = 0, MaxLocalElem = 0;
    unsigned long iGlobal_Index = 0, nBuffer_Scalar = 0;

    int iProcessor;
    int rank = MASTER_NODE;
    int size = SINGLE_NODE;

#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
#endif

    bool grid_movement  = (config->GetGrid_Movement());
    bool compressible   = (config->GetKind_Regime() == COMPRESSIBLE);
    bool incompressible = (config->GetKind_Regime() == INCOMPRESSIBLE);
    bool freesurface    = (config->GetKind_Regime() == FREESURFACE);
    bool transition     = (config->GetKind_Trans_Model() == LM);
    bool flow           = (( config->GetKind_Solver() == EULER             ) ||
                           ( config->GetKind_Solver() == NAVIER_STOKES     ) ||
                           ( config->GetKind_Solver() == RANS              ) ||
                           ( config->GetKind_Solver() == ADJ_EULER         ) ||
                           ( config->GetKind_Solver() == ADJ_NAVIER_STOKES ) ||
                           ( config->GetKind_Solver() == ADJ_RANS          )   );

    unsigned short iDim;
    unsigned short nDim = geometry->GetnDim();
    double RefAreaCoeff = config->GetRefAreaCoeff();
    double Gamma = config->GetGamma();
    double RefVel2;

    if (flow) {
        if (grid_movement) {
            Gas_Constant = config->GetGas_ConstantND();
            Mach2Vel = sqrt(Gamma*Gas_Constant*config->GetTemperature_FreeStreamND());
            Mach_Motion = config->GetMach_Motion();
            RefVel2 = (Mach_Motion*Mach2Vel)*(Mach_Motion*Mach2Vel);
        }
        else {
            RefVel2 = 0.0;
            for (iDim = 0; iDim < nDim; iDim++)
                RefVel2  += solver[FLOW_SOL]->GetVelocity_Inf(iDim)*solver[FLOW_SOL]->GetVelocity_Inf(iDim);
        }
        RefDensity  = solver[FLOW_SOL]->GetDensity_Inf();
        RefPressure = solver[FLOW_SOL]->GetPressure_Inf();
        factor = 1.0 / (0.5*RefDensity*RefAreaCoeff*RefVel2);
    }

    switch (Kind_Solver) {
    case EULER : case NAVIER_STOKES: FirstIndex = FLOW_SOL; SecondIndex = NONE; ThirdIndex = NONE; break;
    case RANS : FirstIndex = FLOW_SOL; SecondIndex = TURB_SOL; if (transition) ThirdIndex=TRANS_SOL; else ThirdIndex = NONE; break;
    case HEAT_EQUATION: FirstIndex = HEAT_SOL; SecondIndex = NONE; ThirdIndex = NONE; break;
    default: SecondIndex = NONE; ThirdIndex = NONE; break;
    }

    nVar_First = solver[FirstIndex]->GetnVar();
    if (SecondIndex != NONE) nVar_Second = solver[SecondIndex]->GetnVar();
    if (ThirdIndex != NONE) nVar_Third = solver[ThirdIndex]->GetnVar();
    nVar_Consv = nVar_First + nVar_Second + nVar_Third;
    nVar_Total = nVar_Consv;

    if (!config->GetLow_MemoryOutput()) {

        if (config->GetWrt_Limiters()) nVar_Total += nVar_Consv;

        if (config->GetWrt_Residuals()) nVar_Total += nVar_Consv;

        if (grid_movement) {
            iVar_GridVel = nVar_Total;
            if (geometry->GetnDim() == 2) nVar_Total += 2;
            else if (geometry->GetnDim() == 3) nVar_Total += 3;
        }

        if ((Kind_Solver == EULER) || (Kind_Solver == NAVIER_STOKES) || (Kind_Solver == RANS)) {
            iVar_PressCp = nVar_Total; nVar_Total += 3;
            iVar_MachMean = nVar_Total; nVar_Total += 1;
        }

        if ((Kind_Solver == NAVIER_STOKES) || (Kind_Solver == RANS)) {
            iVar_Lam = nVar_Total; nVar_Total += 1;
            iVar_ViscCoeffs = nVar_Total; nVar_Total += 3;
        }

        if (Kind_Solver == RANS) {
            iVar_Eddy = nVar_Total; nVar_Total += 1;
        }

        if (config->GetWrt_SharpEdges()) {
            if ((Kind_Solver == EULER) || (Kind_Solver == NAVIER_STOKES) || (Kind_Solver == RANS)) {
                iVar_Sharp = nVar_Total; nVar_Total += 1;
            }
        }

        if (config->GetExtraOutput()) {
            if (Kind_Solver == RANS) {
                iVar_Extra  = nVar_Total; nVar_Extra  = solver[TURB_SOL]->GetnOutputVariables(); nVar_Total += nVar_Extra;
            }
        }

    }

    for (iPoint = 0; iPoint < geometry->GetnElemDomain(); iPoint++)
        nLocalElem++;

    Buffer_Send_nElem[0] = nLocalElem;

    if (rank == MASTER_NODE) Buffer_Recv_nElem = new unsigned long[size];

#ifdef HAVE_MPI
    MPI_Allreduce(&nLocalElem, &MaxLocalElem, 1, MPI_UNSIGNED_LONG, MPI_MAX, MPI_COMM_WORLD);
    MPI_Gather(&Buffer_Send_nElem, 1, MPI_UNSIGNED_LONG, Buffer_Recv_nElem, 1, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
#else
    MaxLocalElem = nLocalElem;
    Buffer_Recv_nElem[0] = Buffer_Send_nElem[0];
#endif

    nBuffer_Scalar = MaxLocalElem;

    double *Buffer_Send_Var = new double[MaxLocalElem];
    double *Buffer_Recv_Var = NULL;

    double *Buffer_Send_Res = new double[MaxLocalElem];
    double *Buffer_Recv_Res = NULL;

    double *Buffer_Send_Vol = new double[MaxLocalElem];
    double *Buffer_Recv_Vol = NULL;

    unsigned long *Buffer_Send_GlobalIndex = new unsigned long[MaxLocalElem];
    unsigned long *Buffer_Recv_GlobalIndex = NULL;

    if ((Kind_Solver == NAVIER_STOKES) || (Kind_Solver == RANS)) {
        Aux_Frict = new double[geometry->GetnElem()];
        Aux_Heat  = new double[geometry->GetnElem()];
        Aux_yPlus = new double[geometry->GetnElem()];
    }

    if (rank == MASTER_NODE) {

        Buffer_Recv_Var = new double[size*MaxLocalElem];
        Buffer_Recv_Res = new double[size*MaxLocalElem];
        Buffer_Recv_Vol = new double[size*MaxLocalElem];
        Buffer_Recv_GlobalIndex = new unsigned long[size*MaxLocalElem];

        nGlobal_Elem = 0;
        for (iProcessor = 0; iProcessor < size; iProcessor++) {
            nGlobal_Elem += Buffer_Recv_nElem[iProcessor];
        }
        Data = new double*[nVar_Total];
        for (iVar = 0; iVar < nVar_Total; iVar++) {
            Data[iVar] = new double[nGlobal_Elem];
        }
    }

    for (iVar = 0; iVar < nVar_Consv; iVar++) {

        jVar = iVar;
        CurrentIndex = FirstIndex;
        if ((SecondIndex != NONE) && (iVar > nVar_First-1)) {
            jVar = iVar - nVar_First;
            CurrentIndex = SecondIndex;
        }
        if ((SecondIndex != NONE) && (ThirdIndex != NONE) && (iVar > (nVar_First + nVar_Second-1))) {
            jVar = iVar - nVar_First - nVar_Second;
            CurrentIndex = ThirdIndex;
        }

        jPoint = 0;
        for (iPoint = 0; iPoint < geometry->GetnElemDomain(); iPoint++) {

            Buffer_Send_Var[jPoint] = solver[CurrentIndex]->elem[iPoint]->GetSolution(jVar);

            if (!config->GetLow_MemoryOutput()) {

                if (config->GetWrt_Limiters()) {
                    Buffer_Send_Vol[jPoint] = solver[CurrentIndex]->elem[iPoint]->GetLimiter_Primitive(jVar);
                }

                if (config->GetWrt_Residuals()) {
                    Buffer_Send_Res[jPoint] = solver[CurrentIndex]->LinSysRes.GetBlock(iPoint, jVar);
                }

            }

            if (iVar == 0) {
                Buffer_Send_GlobalIndex[jPoint] = geometry->elem[iPoint]->GetGlobalIndex();
            }

            jPoint++;

        }

#ifdef HAVE_MPI
        MPI_Gather(Buffer_Send_Var, nBuffer_Scalar, MPI_DOUBLE, Buffer_Recv_Var, nBuffer_Scalar, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
#else
        for (iPoint = 0; iPoint < nBuffer_Scalar; iPoint++) Buffer_Recv_Var[iPoint] = Buffer_Send_Var[iPoint];
#endif
        if (!config->GetLow_MemoryOutput()) {

            if (config->GetWrt_Limiters()) {
#ifdef HAVE_MPI
                MPI_Gather(Buffer_Send_Vol, nBuffer_Scalar, MPI_DOUBLE, Buffer_Recv_Vol, nBuffer_Scalar, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
#else
                for (iPoint = 0; iPoint < nBuffer_Scalar; iPoint++) Buffer_Recv_Vol[iPoint] = Buffer_Send_Vol[iPoint];
#endif
            }

            if (config->GetWrt_Residuals()) {
#ifdef HAVE_MPI
                MPI_Gather(Buffer_Send_Res, nBuffer_Scalar, MPI_DOUBLE, Buffer_Recv_Res, nBuffer_Scalar, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
#else
                for (iPoint = 0; iPoint < nBuffer_Scalar; iPoint++) Buffer_Recv_Res[iPoint] = Buffer_Send_Res[iPoint];
#endif
            }

        }

        if (iVar == 0) {
#ifdef HAVE_MPI
            MPI_Gather(Buffer_Send_GlobalIndex, nBuffer_Scalar, MPI_UNSIGNED_LONG, Buffer_Recv_GlobalIndex, nBuffer_Scalar, MPI_UNSIGNED_LONG, MASTER_NODE, MPI_COMM_WORLD);
#else
            for (iPoint = 0; iPoint < nBuffer_Scalar; iPoint++) Buffer_Recv_GlobalIndex[iPoint] = Buffer_Send_GlobalIndex[iPoint];
#endif
        }

        if (rank == MASTER_NODE) {
            jPoint = 0;
            for (iProcessor = 0; iProcessor < size; iProcessor++) {
                for (iPoint = 0; iPoint < Buffer_Recv_nElem[iProcessor]; iPoint++) {

                    iGlobal_Index = Buffer_Recv_GlobalIndex[jPoint];

                    Data[iVar][iGlobal_Index] = Buffer_Recv_Var[jPoint];

                    if (!config->GetLow_MemoryOutput()) {

                        if (config->GetWrt_Limiters()) {
                            Data[iVar+nVar_Consv][iGlobal_Index] = Buffer_Recv_Vol[jPoint];
                        }

                        if (config->GetWrt_Residuals()) {
                            unsigned short ExtraIndex;
                            ExtraIndex = nVar_Consv;
                            if (config->GetWrt_Limiters()) ExtraIndex = 2*nVar_Consv;
                            Data[iVar+ExtraIndex][iGlobal_Index] = Buffer_Recv_Res[jPoint];
                        }

                    }

                    jPoint++;
                }
                jPoint = (iProcessor+1)*nBuffer_Scalar;
            }
        }

    }

    if (!config->GetLow_MemoryOutput()) {

        if (grid_movement) {

            jPoint = 0; double *Grid_Vel;
            for (iPoint = 0; iPoint < geometry->GetnElemDomain(); iPoint++) {

                Grid_Vel = geometry->elem[iPoint]->GetGridVel();
                Buffer_Send_Var[jPoint] = Grid_Vel[0];
                Buffer_Send_Res[jPoint] = Grid_Vel[1];
                Buffer_Send_Vol[jPoint] = Grid_Vel[2];
                jPoint++;
            }

#ifdef HAVE_MPI
            MPI_Gather(Buffer_Send_Var, nBuffer_Scalar, MPI_DOUBLE, Buffer_Recv_Var, nBuffer_Scalar, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
            MPI_Gather(Buffer_Send_Res, nBuffer_Scalar, MPI_DOUBLE, Buffer_Recv_Res, nBuffer_Scalar, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
            MPI_Gather(Buffer_Send_Vol, nBuffer_Scalar, MPI_DOUBLE, Buffer_Recv_Vol, nBuffer_Scalar, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
#else
            for (iPoint = 0; iPoint < nBuffer_Scalar; iPoint++) Buffer_Recv_Var[iPoint] = Buffer_Send_Var[iPoint];
            for (iPoint = 0; iPoint < nBuffer_Scalar; iPoint++) Buffer_Recv_Res[iPoint] = Buffer_Send_Res[iPoint];
            for (iPoint = 0; iPoint < nBuffer_Scalar; iPoint++) Buffer_Recv_Vol[iPoint] = Buffer_Send_Vol[iPoint];
#endif

            if (rank == MASTER_NODE) {
                jPoint = 0; iVar = iVar_GridVel;
                for (iProcessor = 0; iProcessor < size; iProcessor++) {
                    for (iPoint = 0; iPoint < Buffer_Recv_nElem[iProcessor]; iPoint++) {

                        iGlobal_Index = Buffer_Recv_GlobalIndex[jPoint];
                        Data[iVar][iGlobal_Index]   = Buffer_Recv_Var[jPoint];
                        Data[iVar+1][iGlobal_Index] = Buffer_Recv_Res[jPoint];
                        Data[iVar+2][iGlobal_Index] = Buffer_Recv_Vol[jPoint];
                        jPoint++;
                    }

                    jPoint = (iProcessor+1)*nBuffer_Scalar;
                }
            }
        }


        if ((Kind_Solver == EULER) || (Kind_Solver == NAVIER_STOKES) || (Kind_Solver == RANS)) {

            jPoint = 0;
            for (iPoint = 0; iPoint < geometry->GetnElemDomain(); iPoint++) {

                if (compressible) {
                    Buffer_Send_Var[jPoint] = solver[FLOW_SOL]->elem[iPoint]->GetPressure();
                    Buffer_Send_Res[jPoint] = solver[FLOW_SOL]->elem[iPoint]->GetTemperature();
                    Buffer_Send_Vol[jPoint] = (solver[FLOW_SOL]->elem[iPoint]->GetPressure() - RefPressure)*factor*RefAreaCoeff;
                }
                if (incompressible) {
                    Buffer_Send_Var[jPoint] = solver[FLOW_SOL]->elem[iPoint]->GetPressureInc();
                    Buffer_Send_Res[jPoint] = 0.0;
                    Buffer_Send_Vol[jPoint] = (solver[FLOW_SOL]->elem[iPoint]->GetPressureInc() - RefPressure)*factor*RefAreaCoeff;
                }
                jPoint++;
            }

#ifdef HAVE_MPI
            MPI_Gather(Buffer_Send_Var, nBuffer_Scalar, MPI_DOUBLE, Buffer_Recv_Var, nBuffer_Scalar, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
            MPI_Gather(Buffer_Send_Res, nBuffer_Scalar, MPI_DOUBLE, Buffer_Recv_Res, nBuffer_Scalar, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
            MPI_Gather(Buffer_Send_Vol, nBuffer_Scalar, MPI_DOUBLE, Buffer_Recv_Vol, nBuffer_Scalar, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
#else
            for (iPoint = 0; iPoint < nBuffer_Scalar; iPoint++) Buffer_Recv_Var[iPoint] = Buffer_Send_Var[iPoint];
            for (iPoint = 0; iPoint < nBuffer_Scalar; iPoint++) Buffer_Recv_Res[iPoint] = Buffer_Send_Res[iPoint];
            for (iPoint = 0; iPoint < nBuffer_Scalar; iPoint++) Buffer_Recv_Vol[iPoint] = Buffer_Send_Vol[iPoint];
#endif

            if (rank == MASTER_NODE) {
                jPoint = 0; iVar = iVar_PressCp;
                for (iProcessor = 0; iProcessor < size; iProcessor++) {
                    for (iPoint = 0; iPoint < Buffer_Recv_nElem[iProcessor]; iPoint++) {

                        iGlobal_Index = Buffer_Recv_GlobalIndex[jPoint];
                        Data[iVar][iGlobal_Index]   = Buffer_Recv_Var[jPoint];
                        Data[iVar+1][iGlobal_Index] = Buffer_Recv_Res[jPoint];
                        Data[iVar+2][iGlobal_Index] = Buffer_Recv_Vol[jPoint];
                        jPoint++;
                    }

                    jPoint = (iProcessor+1)*nBuffer_Scalar;
                }
            }
        }

        if ((Kind_Solver == EULER) || (Kind_Solver == NAVIER_STOKES) || (Kind_Solver == RANS)) {

            jPoint = 0;
            for (iPoint = 0; iPoint < geometry->GetnElemDomain(); iPoint++) {

                if (compressible) {
                    Buffer_Send_Var[jPoint] = sqrt(solver[FLOW_SOL]->elem[iPoint]->GetVelocity2())/
                            solver[FLOW_SOL]->elem[iPoint]->GetSoundSpeed();
                }
                if (incompressible) {
                    Buffer_Send_Var[jPoint] = sqrt(solver[FLOW_SOL]->elem[iPoint]->GetVelocity2())*config->GetVelocity_Ref()/
                            sqrt(config->GetBulk_Modulus()/(solver[FLOW_SOL]->elem[iPoint]->GetDensityInc()*config->GetDensity_Ref()));
                }
                jPoint++;
            }

#ifdef HAVE_MPI
            MPI_Gather(Buffer_Send_Var, nBuffer_Scalar, MPI_DOUBLE, Buffer_Recv_Var, nBuffer_Scalar, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
#else
            for (iPoint = 0; iPoint < nBuffer_Scalar; iPoint++) Buffer_Recv_Var[iPoint] = Buffer_Send_Var[iPoint];
#endif

            if (rank == MASTER_NODE) {
                jPoint = 0; iVar = iVar_MachMean;
                for (iProcessor = 0; iProcessor < size; iProcessor++) {
                    for (iPoint = 0; iPoint < Buffer_Recv_nElem[iProcessor]; iPoint++) {

                        iGlobal_Index = Buffer_Recv_GlobalIndex[jPoint];
                        Data[iVar][iGlobal_Index]   = Buffer_Recv_Var[jPoint];
                        jPoint++;
                    }

                    jPoint = (iProcessor+1)*nBuffer_Scalar;
                }
            }
        }


        if ((Kind_Solver == NAVIER_STOKES) || (Kind_Solver == RANS)) {

            jPoint = 0;
            for (iPoint = 0; iPoint < geometry->GetnElemDomain(); iPoint++) {

                if (compressible) {
                    Buffer_Send_Res[jPoint] = solver[FLOW_SOL]->elem[iPoint]->GetLaminarViscosity();
                }
                if (incompressible || freesurface) {
                    Buffer_Send_Res[jPoint] = solver[FLOW_SOL]->elem[iPoint]->GetLaminarViscosityInc();
                }
                jPoint++;
            }


#ifdef HAVE_MPI
            MPI_Gather(Buffer_Send_Res, nBuffer_Scalar, MPI_DOUBLE, Buffer_Recv_Res, nBuffer_Scalar, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
#else
            for (iPoint = 0; iPoint < nBuffer_Scalar; iPoint++) Buffer_Recv_Res[iPoint] = Buffer_Send_Res[iPoint];
#endif

            if (rank == MASTER_NODE) {
                jPoint = 0; iVar = iVar_Lam;
                for (iProcessor = 0; iProcessor < size; iProcessor++) {
                    for (iPoint = 0; iPoint < Buffer_Recv_nElem[iProcessor]; iPoint++) {

                        iGlobal_Index = Buffer_Recv_GlobalIndex[jPoint];
                        Data[iVar][iGlobal_Index] = Buffer_Recv_Res[jPoint];
                        jPoint++;
                    }

                    jPoint = (iProcessor+1)*nBuffer_Scalar;
                }
            }

            for(iPoint = 0; iPoint < geometry->GetnElemDomain(); iPoint++) {
                Aux_Frict[iPoint] = 0.0;
                Aux_Heat[iPoint]  = 0.0;
                Aux_yPlus[iPoint] = 0.0;
            }

            unsigned long iFace;
            for (iMarker = 0; iMarker < config->GetnMarker_All(); iMarker++){
                if (config->GetMarker_All_Plotting(iMarker) == YES) {
                    for(iVertex = 0; iVertex < geometry->nElem_Bound[iMarker]; iVertex++) {
                        iFace = geometry->bound[iMarker][iVertex]->GetGlobalFace();
                        iPoint = geometry->face[iFace]->GetElems(0);
                        if(geometry->elem[iPoint]->GetColor() == rank){
                            Aux_Frict[iPoint] = solver[FLOW_SOL]->GetCSkinFriction(iMarker,iVertex);
                            Aux_Heat[iPoint]  = solver[FLOW_SOL]->GetHeatFlux(iMarker,iVertex);
                            Aux_yPlus[iPoint] = solver[FLOW_SOL]->GetYPlus(iMarker,iVertex);
                        }
                    }
                }
            }

            jPoint = 0;
            for (iPoint = 0; iPoint < geometry->GetnElemDomain(); iPoint++) {

                if (compressible) {
                    Buffer_Send_Var[jPoint] = Aux_Frict[iPoint];
                    Buffer_Send_Res[jPoint] = Aux_Heat[iPoint];
                    Buffer_Send_Vol[jPoint] = Aux_yPlus[iPoint];
                }
                if (incompressible || freesurface) {
                    Buffer_Send_Var[jPoint] = Aux_Frict[iPoint];
                    Buffer_Send_Res[jPoint] = Aux_Heat[iPoint];
                    Buffer_Send_Vol[jPoint] = Aux_yPlus[iPoint];
                }
                jPoint++;
            }

#ifdef HAVE_MPI
            MPI_Gather(Buffer_Send_Var, nBuffer_Scalar, MPI_DOUBLE, Buffer_Recv_Var, nBuffer_Scalar, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
            MPI_Gather(Buffer_Send_Res, nBuffer_Scalar, MPI_DOUBLE, Buffer_Recv_Res, nBuffer_Scalar, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
            MPI_Gather(Buffer_Send_Vol, nBuffer_Scalar, MPI_DOUBLE, Buffer_Recv_Vol, nBuffer_Scalar, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
#else
            for (iPoint = 0; iPoint < nBuffer_Scalar; iPoint++) Buffer_Recv_Var[iPoint] = Buffer_Send_Var[iPoint];
            for (iPoint = 0; iPoint < nBuffer_Scalar; iPoint++) Buffer_Recv_Res[iPoint] = Buffer_Send_Res[iPoint];
            for (iPoint = 0; iPoint < nBuffer_Scalar; iPoint++) Buffer_Recv_Vol[iPoint] = Buffer_Send_Vol[iPoint];
#endif

            if (rank == MASTER_NODE) {
                jPoint = 0; iVar = iVar_ViscCoeffs;

                for (iProcessor = 0; iProcessor < size; iProcessor++) {
                    for (iPoint = 0; iPoint < Buffer_Recv_nElem[iProcessor]; iPoint++) {

                        iGlobal_Index = Buffer_Recv_GlobalIndex[jPoint];
                        Data[iVar+0][iGlobal_Index] = Buffer_Recv_Var[jPoint];
                        Data[iVar+1][iGlobal_Index] = Buffer_Recv_Res[jPoint];
                        Data[iVar+2][iGlobal_Index] = Buffer_Recv_Vol[jPoint];
                        jPoint++;
                    }

                    jPoint = (iProcessor+1)*nBuffer_Scalar;
                }
            }
        }

        if (Kind_Solver == RANS) {

            jPoint = 0;
            for (iPoint = 0; iPoint < geometry->GetnElemDomain(); iPoint++) {

                if (compressible) {
                    Buffer_Send_Var[jPoint] = solver[FLOW_SOL]->elem[iPoint]->GetEddyViscosity();
                }
                if (incompressible || freesurface) {
                    Buffer_Send_Var[jPoint] = solver[FLOW_SOL]->elem[iPoint]->GetEddyViscosityInc();
                }
                jPoint++;
            }

#ifdef HAVE_MPI
            MPI_Gather(Buffer_Send_Var, nBuffer_Scalar, MPI_DOUBLE, Buffer_Recv_Var, nBuffer_Scalar, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
#else
            for (iPoint = 0; iPoint < nBuffer_Scalar; iPoint++) Buffer_Recv_Var[iPoint] = Buffer_Send_Var[iPoint];
#endif

            if (rank == MASTER_NODE) {
                jPoint = 0; iVar = iVar_Eddy;
                for (iProcessor = 0; iProcessor < size; iProcessor++) {
                    for (iPoint = 0; iPoint < Buffer_Recv_nElem[iProcessor]; iPoint++) {

                        iGlobal_Index = Buffer_Recv_GlobalIndex[jPoint];
                        Data[iVar][iGlobal_Index] = Buffer_Recv_Var[jPoint];
                        jPoint++;
                    }

                    jPoint = (iProcessor+1)*nBuffer_Scalar;
                }
            }

        }

        if (config->GetWrt_SharpEdges()) {

            if ((Kind_Solver == EULER) || (Kind_Solver == NAVIER_STOKES) || (Kind_Solver == RANS)) {

                jPoint = 0;
                for (iPoint = 0; iPoint < geometry->GetnElemDomain(); iPoint++) {

                    jPoint++;
                }

#ifdef HAVE_MPI
                MPI_Gather(Buffer_Send_Var, nBuffer_Scalar, MPI_DOUBLE, Buffer_Recv_Var, nBuffer_Scalar, MPI_DOUBLE, MASTER_NODE, MPI_COMM_WORLD);
#else
                for (iPoint = 0; iPoint < nBuffer_Scalar; iPoint++) Buffer_Recv_Var[iPoint] = Buffer_Send_Var[iPoint];
#endif

                if (rank == MASTER_NODE) {
                    jPoint = 0; iVar = iVar_Sharp;
                    for (iProcessor = 0; iProcessor < size; iProcessor++) {
                        for (iPoint = 0; iPoint < Buffer_Recv_nElem[iProcessor]; iPoint++) {

                            iGlobal_Index = Buffer_Recv_GlobalIndex[jPoint];
                            Data[iVar][iGlobal_Index] = Buffer_Recv_Var[jPoint];
                            jPoint++;
                        }

                        jPoint = (iProcessor+1)*nBuffer_Scalar;
                    }
                }
            }
        }

        //Extra Output is deleted from here.//
    }

    delete [] Buffer_Send_Var;
    delete [] Buffer_Send_Res;
    delete [] Buffer_Send_Vol;
    delete [] Buffer_Send_GlobalIndex;
    if (rank == MASTER_NODE) {
        delete [] Buffer_Recv_Var;
        delete [] Buffer_Recv_Res;
        delete [] Buffer_Recv_Vol;
        delete [] Buffer_Recv_GlobalIndex;
    }

    if ((Kind_Solver == NAVIER_STOKES) || (Kind_Solver == RANS)) {
        delete [] Aux_Frict; delete [] Aux_Heat; delete [] Aux_yPlus;
    }
    cout<<"Merging solution is done"<<endl;
}

void COutput::MergeBaselineSolution(CConfig *config, CGeometry *geometry, CSolver *solver, unsigned short val_iZone) {

}

void COutput::SetRestart(CConfig *config, CGeometry *geometry, CSolver **solver, unsigned short val_iZone) {

    /*--- Local variables ---*/

    unsigned short Kind_Solver  = config->GetKind_Solver();
    unsigned short iVar, iDim, nDim = geometry->GetnDim();
    unsigned long iPoint, iExtIter = config->GetExtIter();
    bool grid_movement = config->GetGrid_Movement();
    ofstream restart_file;
    string filename;

    /*--- Retrieve filename from config ---*/

    if (config->GetAdjoint()) {
        filename = config->GetRestart_AdjFileName();
        filename = config->GetObjFunc_Extension(filename);
    } else {
        filename = config->GetRestart_FlowFileName();
    }

    /*--- Unsteady problems require an iteration number to be appended. ---*/

    if (config->GetUnsteady_Simulation() == TIME_SPECTRAL) {
        filename = config->GetUnsteady_FileName(filename, int(val_iZone));
    } else if (config->GetWrt_Unsteady()) {
        filename = config->GetUnsteady_FileName(filename, int(iExtIter));
    }

    /*--- Open the restart file and write the solution. ---*/

    restart_file.open(filename.c_str(), ios::out);
    restart_file.precision(15);

    /*--- Write the header line based on the particular solver ----*/

    restart_file << "\"PointID\"";

    /*--- Mesh coordinates are always written to the restart first ---*/

    if (nDim == 2) {
        restart_file << "\t\"x\"\t\"y\"";
    } else {
        restart_file << "\t\"x\"\t\"y\"\t\"z\"";
    }

    for (iVar = 0; iVar < nVar_Consv; iVar++) {
        restart_file << "\t\"Conservative_" << iVar+1<<"\"";
    }

    if (!config->GetLow_MemoryOutput()) {

        if (config->GetWrt_Limiters()) {
            for (iVar = 0; iVar < nVar_Consv; iVar++) {
                restart_file << "\t\"Limiter_" << iVar+1<<"\"";
            }
        }
        if (config->GetWrt_Residuals()) {
            for (iVar = 0; iVar < nVar_Consv; iVar++) {
                restart_file << "\t\"Residual_" << iVar+1<<"\"";
            }
        }

        /*--- Mesh velocities for dynamic mesh cases ---*/

        if (grid_movement) {
            if (nDim == 2) {
                restart_file << "\t\"Grid_Velx\"\t\"Grid_Vely\"";
            } else {
                restart_file << "\t\"Grid_Velx\"\t\"Grid_Vely\"\t\"Grid_Velz\"";
            }
        }

        /*--- Solver specific output variables ---*/

        if (config->GetKind_Regime() == FREESURFACE) {
            restart_file << "\t\"Density\"";
        }

        if ((Kind_Solver == EULER) || (Kind_Solver == NAVIER_STOKES) || (Kind_Solver == RANS)) {
            restart_file << "\t\"Pressure\"\t\"Temperature\"\t\"Pressure_Coefficient\"\t\"Mach\"";
        }

        if ((Kind_Solver == NAVIER_STOKES) || (Kind_Solver == RANS)) {
            restart_file << "\t\"Laminar_Viscosity\"\t\"Skin_Friction_Coefficient\"\t\"Heat_Flux\"\t\"Y_Plus\"";
        }

        if (Kind_Solver == RANS) {
            restart_file << "\t\"Eddy_Viscosity\"";
        }

        if (config->GetWrt_SharpEdges()) {
            if ((Kind_Solver == EULER) || (Kind_Solver == NAVIER_STOKES) || (Kind_Solver == RANS)) {
                restart_file << "\t\"Sharp_Edge_Dist\"";
            }
        }

        if (Kind_Solver == POISSON_EQUATION) {
            for (iDim = 0; iDim < geometry->GetnDim(); iDim++)
                restart_file << "\t\"poissonField_" << iDim+1 << "\"";
        }

        if ((Kind_Solver == ADJ_EULER              ) ||
                (Kind_Solver == ADJ_NAVIER_STOKES      ) ||
                (Kind_Solver == ADJ_RANS               ) ) {
            restart_file << "\t\"Surface_Sensitivity\"\t\"Solution_Sensor\"";
        }

        if (Kind_Solver == LINEAR_ELASTICITY) {
            restart_file << "\t\"Von_Mises_Stress\"\t\"Flow_Pressure\"";
        }

        if (config->GetExtraOutput()) {
            string *headings = NULL;
            //if (Kind_Solver == RANS){
            headings = solver[TURB_SOL]->OutputHeadingNames;
            //}

            for (iVar = 0; iVar < nVar_Extra; iVar++) {
                if (headings == NULL){
                    restart_file << "\t\"ExtraOutput_" << iVar+1<<"\"";
                }else{
                    restart_file << "\t\""<< headings[iVar] <<"\"";
                }
            }
        }
    }

    restart_file << endl;

    /*--- Write the restart file ---*/

    for (iPoint = 0; iPoint < geometry->GetGlobal_nPointDomain(); iPoint++) {

        /*--- Index of the point ---*/
        restart_file << iPoint << "\t";

        /*--- Write the grid coordinates first ---*/
        for (iDim = 0; iDim < nDim; iDim++) {
            restart_file << scientific << Coords[iDim][iPoint] << "\t";
        }

        /*--- Loop over the variables and write the values to file ---*/
        for (iVar = 0; iVar < nVar_Total; iVar++) {
            restart_file << scientific << Data[iVar][iPoint] << "\t";
        }
        restart_file << endl;
    }

    restart_file.close();

}

void COutput::DeallocateCoordinates(CConfig *config, CGeometry *geometry) {

    int rank = MASTER_NODE;
#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif

    /*--- Local variables and initialization ---*/

    unsigned short iDim, nDim = geometry->GetnDim();

    /*--- The master node alone owns all data found in this routine. ---*/
    if (rank == MASTER_NODE) {

        /*--- Deallocate memory for coordinate data ---*/
        for (iDim = 0; iDim < nDim; iDim++) {
            delete [] Coords[iDim];
        }
        delete [] Coords;

    }
}

void COutput::DeallocateConnectivity(CConfig *config, CGeometry *geometry) {

    int rank = MASTER_NODE;
#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif

    /*--- The master node alone owns all data found in this routine. ---*/
    if (rank == MASTER_NODE) {

        /*--- Deallocate memory for connectivity data ---*/
        if (nGlobal_Polyhedron > 0) {Conn_RNeighPolygon = NULL; delete [] Conn_RNeighPolygon; }
        if (nGlobal_Polyhedron > 0) {Conn_LNeighPolygon = NULL; delete [] Conn_LNeighPolygon; }
        if (nGlobal_Polyhedron > 0) {Conn_nNodePolyhedron = NULL; delete [] Conn_nNodePolyhedron; }
        if (nGlobal_Polyhedron > 0) {Conn_Polyhedron3 = NULL; delete [] Conn_Polyhedron3; }
        if (nGlobal_Polyhedron > 0) {Conn_Polyhedron4 = NULL; delete [] Conn_Polyhedron4; }
        if (nGlobal_Polyhedron > 0) {Conn_Polyhedron5 = NULL; delete [] Conn_Polyhedron5; }
        if (nGlobal_Polyhedron > 0) {Conn_Polyhedron6 = NULL; delete [] Conn_Polyhedron6; }
        if (nGlobal_Polyhedron > 0) {Conn_Polyhedron7 = NULL; delete [] Conn_Polyhedron7; }
        if (nGlobal_Polyhedron > 0) {Conn_Polyhedron8 = NULL; delete [] Conn_Polyhedron8; }

    }
}

void COutput::DeallocateSolution(CConfig *config, CGeometry *geometry) {

    int rank = MASTER_NODE;
#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif

    /*--- The master node alone owns all data found in this routine. ---*/
    if (rank == MASTER_NODE){
        for (unsigned short iVar = 0; iVar < nVar_Total; iVar++) {

            //                delete [] Data[iVar];

        }
        //            delete [] Data;
    }

}

void COutput::SetConvHistory_Header(ofstream *ConvHist_file, CConfig *config) {
    char cstr[200], buffer[50], turb_resid[1000];
    unsigned short iMarker, iMarker_Monitoring, iSpecies;
    string Monitoring_Tag, monitoring_coeff, aeroelastic_coeff;

    bool rotating_frame = config->GetRotating_Frame();
    bool aeroelastic = config->GetAeroelastic_Simulation();
    bool equiv_area = config->GetEquivArea();
    bool turbulent = ((config->GetKind_Solver() == RANS) || (config->GetKind_Solver() == ADJ_RANS));
    bool frozen_turb = config->GetFrozen_Visc();
    bool freesurface = (config->GetKind_Regime() == FREESURFACE);
    bool inv_design = (config->GetInvDesign_Cp() || config->GetInvDesign_HeatFlux());
    bool output_1d = config->GetWrt_1D_Output();
    bool output_per_surface = false;
    bool output_massflow = (config->GetKind_ObjFunc()==MASS_FLOW_RATE);
    if(config->GetnMarker_Monitoring() > 1) output_per_surface = true;

    bool isothermal = false;
    for (iMarker = 0; iMarker < config->GetnMarker_All(); iMarker++)
        if ((config->GetMarker_All_KindBC(iMarker) == ISOTHERMAL             ) ||
                (config->GetMarker_All_KindBC(iMarker) == ISOTHERMAL_CATALYTIC   ) ||
                (config->GetMarker_All_KindBC(iMarker) == ISOTHERMAL_NONCATALYTIC)   )
            isothermal = true;

    /*--- Write file name with extension ---*/

    string filename = config->GetConv_FileName();
    strcpy (cstr, filename.data());

    if (config->GetWrt_Unsteady() && config->GetRestart()) {
        long iExtIter = config->GetUnst_RestartIter();
        if (int(iExtIter) < 10) sprintf (buffer, "_0000%d", int(iExtIter));
        if ((int(iExtIter) >= 10) && (int(iExtIter) < 100)) sprintf (buffer, "_000%d", int(iExtIter));
        if ((int(iExtIter) >= 100) && (int(iExtIter) < 1000)) sprintf (buffer, "_00%d", int(iExtIter));
        if ((int(iExtIter) >= 1000) && (int(iExtIter) < 10000)) sprintf (buffer, "_0%d", int(iExtIter));
        if (int(iExtIter) >= 10000) sprintf (buffer, "_%d", int(iExtIter));
        strcat(cstr,buffer);
    }

    if (config->GetOutput_FileFormat() == TECPLOT) sprintf (buffer, ".dat");
    else if (config->GetOutput_FileFormat() == TECPLOT_BINARY)  sprintf (buffer, ".plt");
    else if (config->GetOutput_FileFormat() == PARAVIEW)  sprintf (buffer, ".csv");
    strcat(cstr,buffer);

    ConvHist_file->open(cstr, ios::out);
    ConvHist_file->precision(15);

    /*--- Begin of the header ---*/

    char begin[]= "\"Iteration\"";

    /*--- Header for the coefficients ---*/

    char flow_coeff[]= ",\"CLift\",\"CDrag\",\"CSideForce\",\"CMx\",\"CMy\",\"CMz\",\"CFx\",\"CFy\",\"CFz\",\"CL/CD\"";
    char heat_coeff[]= ",\"HeatFlux_Total\",\"HeatFlux_Maximum\"";
    char equivalent_area_coeff[]= ",\"CEquivArea\",\"CNearFieldOF\"";
    char rotating_frame_coeff[]= ",\"CMerit\",\"CT\",\"CQ\"";
    char free_surface_coeff[]= ",\"CFreeSurface\"";
    char wave_coeff[]= ",\"CWave\"";
    char fea_coeff[]= ",\"CFEA\"";
    char adj_coeff[]= ",\"Sens_Geo\",\"Sens_Mach\",\"Sens_AoA\",\"Sens_Press\",\"Sens_Temp\",\"Sens_AoS\"";
    char oneD_outputs[]= ",\"Avg_TotalPress\",\"Avg_Mach\",\"Avg_Temperature\",\"MassFlowRate\",\"FluxAvg_Pressure\",\"FluxAvg_Density\",\"FluxAvg_Velocity\",\"FluxAvg_Enthalpy\"";
    char Cp_inverse_design[]= ",\"Cp_Diff\"";
    char Heat_inverse_design[]= ",\"HeatFlux_Diff\"";
    char mass_flow_rate[] = ",\"MassFlowRate\"";


    /* Find the markers being monitored and create a header for them */
    for (iMarker_Monitoring = 0; iMarker_Monitoring < config->GetnMarker_Monitoring(); iMarker_Monitoring++) {
        Monitoring_Tag = config->GetMarker_Monitoring(iMarker_Monitoring);
        monitoring_coeff += ",\"CLift_"  + Monitoring_Tag + "\"";
        monitoring_coeff += ",\"CDrag_"  + Monitoring_Tag + "\"";
        monitoring_coeff += ",\"CSideForce_" + Monitoring_Tag + "\"";
        monitoring_coeff += ",\"CL/CD_" + Monitoring_Tag + "\"";
        monitoring_coeff += ",\"CFx_"    + Monitoring_Tag + "\"";
        monitoring_coeff += ",\"CFy_"    + Monitoring_Tag + "\"";
        monitoring_coeff += ",\"CFz_"    + Monitoring_Tag + "\"";
        monitoring_coeff += ",\"CMx_"    + Monitoring_Tag + "\"";
        monitoring_coeff += ",\"CMy_"    + Monitoring_Tag + "\"";
        monitoring_coeff += ",\"CMz_"    + Monitoring_Tag + "\"";
        aeroelastic_coeff += ",\"plunge_" + Monitoring_Tag + "\"";
        aeroelastic_coeff += ",\"pitch_"  + Monitoring_Tag + "\"";
    }

    /*--- Header for the residuals ---*/

    char flow_resid[]= ",\"Res_Flow[0]\",\"Res_Flow[1]\",\"Res_Flow[2]\",\"Res_Flow[3]\",\"Res_Flow[4]\"";
    char adj_flow_resid[]= ",\"Res_AdjFlow[0]\",\"Res_AdjFlow[1]\",\"Res_AdjFlow[2]\",\"Res_AdjFlow[3]\",\"Res_AdjFlow[4]\"";
    switch (config->GetKind_Turb_Model()) {
    case SA:	   sprintf (turb_resid, ",\"Res_Turb[0]\""); break;
    case SA_NEG: sprintf (turb_resid, ",\"Res_Turb[0]\""); break;
    case ML:	   sprintf (turb_resid, ",\"Res_Turb[0]\""); break;
    case SST:   	sprintf (turb_resid, ",\"Res_Turb[0]\",\"Res_Turb[1]\""); break;
    }
    char adj_turb_resid[]= ",\"Res_AdjTurb[0]\"";
    char levelset_resid[]= ",\"Res_LevelSet\"";
    char adj_levelset_resid[]= ",\"Res_AdjLevelSet\"";
    char wave_resid[]= ",\"Res_Wave[0]\",\"Res_Wave[1]\"";
    char fea_resid[]= ",\"Res_FEA\"";
    char heat_resid[]= ",\"Res_Heat\"";

    /*--- End of the header ---*/

    char end[]= ",\"Linear_Solver_Iterations\",\"CFL_Number\",\"Time(min)\"\n";

    if ((config->GetOutput_FileFormat() == TECPLOT) ||
            (config->GetOutput_FileFormat() == TECPLOT_BINARY)) {
        ConvHist_file[0] << "TITLE = \"SU2 Simulation\"" << endl;
        ConvHist_file[0] << "VARIABLES = ";
    }

    /*--- Write the header, case depending ---*/
    switch (config->GetKind_Solver()) {

    case EULER : case NAVIER_STOKES: case RANS :
        ConvHist_file[0] << begin << flow_coeff;
        if (isothermal) ConvHist_file[0] << heat_coeff;
        if (equiv_area) ConvHist_file[0] << equivalent_area_coeff;
        if (inv_design) {
            ConvHist_file[0] << Cp_inverse_design;
            if (isothermal) ConvHist_file[0] << Heat_inverse_design;
        }
        if (rotating_frame) ConvHist_file[0] << rotating_frame_coeff;
        ConvHist_file[0] << flow_resid;
        if (turbulent) ConvHist_file[0] << turb_resid;
        if (aeroelastic) ConvHist_file[0] << aeroelastic_coeff;
        if (output_per_surface) ConvHist_file[0] << monitoring_coeff;
        if (output_1d) ConvHist_file[0] << oneD_outputs;
        if (output_massflow)  ConvHist_file[0]<< mass_flow_rate;
        ConvHist_file[0] << end;
        if (freesurface) {
            ConvHist_file[0] << begin << flow_coeff << free_surface_coeff;
            ConvHist_file[0] << flow_resid << levelset_resid << end;
        }

        break;

    case ADJ_EULER      : case ADJ_NAVIER_STOKES      : case ADJ_RANS:
        ConvHist_file[0] << begin << adj_coeff << adj_flow_resid;
        if ((turbulent) && (!frozen_turb)) ConvHist_file[0] << adj_turb_resid;
        ConvHist_file[0] << end;
        if (freesurface) {
            ConvHist_file[0] << begin << adj_coeff << adj_flow_resid << adj_levelset_resid << end;
        }
        break;

    case WAVE_EQUATION:
        ConvHist_file[0] << begin << wave_coeff;
        ConvHist_file[0] << wave_resid << end;
        break;

    case HEAT_EQUATION:
        ConvHist_file[0] << begin << heat_coeff;
        ConvHist_file[0] << heat_resid << end;
        break;

    case LINEAR_ELASTICITY:
        ConvHist_file[0] << begin << fea_coeff;
        ConvHist_file[0] << fea_resid << end;
        break;

    }

    if (config->GetOutput_FileFormat() == TECPLOT || config->GetOutput_FileFormat() == TECPLOT_BINARY) {
        ConvHist_file[0] << "ZONE T= \"Convergence history\"" << endl;
    }
}


void COutput::SetConvHistory_Body(ofstream *ConvHist_file,
                                  CGeometry ***geometry,
                                  CSolver ****solver_container,
                                  CConfig **config,
                                  CIntegration ***integration,
                                  bool DualTime_Iteration,
                                  double timeused,
                                  unsigned short val_iZone) {

    bool output_1d  = config[val_iZone]->GetWrt_1D_Output();
    bool output_massflow = (config[val_iZone]->GetKind_ObjFunc()==MASS_FLOW_RATE);
    unsigned short FinestMesh = config[val_iZone]->GetFinestMesh();

    int rank;
#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#else
    rank = MASTER_NODE;
#endif

    /*--- If 1-D outputs requested, calculated them. Requires info from all nodes,
   Get area-averaged and flux-averaged values at the specified surface ---*/

    if (output_1d) {
        switch (config[val_iZone]->GetKind_Solver()) {
        case EULER:                   case NAVIER_STOKES:                   case RANS:
        case FLUID_STRUCTURE_EULER:   case FLUID_STRUCTURE_NAVIER_STOKES:   case FLUID_STRUCTURE_RANS:
        case ADJ_EULER:               case ADJ_NAVIER_STOKES:               case ADJ_RANS:
            OneDimensionalOutput(solver_container[val_iZone][FinestMesh][FLOW_SOL], geometry[val_iZone][FinestMesh], config[val_iZone]);
        }
    }
    if (output_massflow){
        switch (config[val_iZone]->GetKind_Solver()) {
        case EULER:                   case NAVIER_STOKES:                   case RANS:
        case FLUID_STRUCTURE_EULER:   case FLUID_STRUCTURE_NAVIER_STOKES:   case FLUID_STRUCTURE_RANS:
        case ADJ_EULER:               case ADJ_NAVIER_STOKES:               case ADJ_RANS:
            SetMassFlowRate(solver_container[val_iZone][FinestMesh][FLOW_SOL], geometry[val_iZone][FinestMesh], config[val_iZone]);
        }
    }

    /*--- Output using only the master node ---*/
    if (rank == MASTER_NODE) {

        unsigned long iIntIter = config[val_iZone]->GetIntIter();
        unsigned long iExtIter = config[val_iZone]->GetExtIter();

        /*--- WARNING: These buffers have hard-coded lengths. Note that you
     may have to adjust them to be larger if adding more entries. ---*/
        char begin[1000], direct_coeff[1000], surface_coeff[1000], aeroelastic_coeff[1000], monitoring_coeff[10000],
                adjoint_coeff[1000], flow_resid[1000], adj_flow_resid[1000], turb_resid[1000], trans_resid[1000],
                adj_turb_resid[1000], resid_aux[1000], levelset_resid[1000], adj_levelset_resid[1000], wave_coeff[1000],
                heat_coeff[1000], fea_coeff[1000], wave_resid[1000], heat_resid[1000], fea_resid[1000], end[1000],
                oneD_outputs[1000], massflow_outputs[1000];

        double dummy = 0.0, *Coord;
        unsigned short iVar, iMarker, iMarker_Monitoring;

        unsigned long LinSolvIter = 0, iPointMaxResid;
        double timeiter = timeused/double(iExtIter+1);

        unsigned short nDim = geometry[val_iZone][FinestMesh]->GetnDim();
        unsigned short nSpecies = config[val_iZone]->GetnSpecies();

        bool compressible = (config[val_iZone]->GetKind_Regime() == COMPRESSIBLE);
        bool incompressible = (config[val_iZone]->GetKind_Regime() == INCOMPRESSIBLE);
        bool freesurface = (config[val_iZone]->GetKind_Regime() == FREESURFACE);

        bool rotating_frame = config[val_iZone]->GetRotating_Frame();
        bool aeroelastic = config[val_iZone]->GetAeroelastic_Simulation();
        bool equiv_area = config[val_iZone]->GetEquivArea();
        bool inv_design = (config[val_iZone]->GetInvDesign_Cp() || config[val_iZone]->GetInvDesign_HeatFlux());
        bool transition = (config[val_iZone]->GetKind_Trans_Model() == LM);
        bool isothermal = false;
        for (iMarker = 0; iMarker < config[val_iZone]->GetnMarker_All(); iMarker++)
            if ((config[val_iZone]->GetMarker_All_KindBC(iMarker) == ISOTHERMAL) ||
                    (config[val_iZone]->GetMarker_All_KindBC(iMarker) == ISOTHERMAL_CATALYTIC) ||
                    (config[val_iZone]->GetMarker_All_KindBC(iMarker) == ISOTHERMAL_NONCATALYTIC))
                isothermal = true;
        bool turbulent = ((config[val_iZone]->GetKind_Solver() == RANS) || (config[val_iZone]->GetKind_Solver() == ADJ_RANS) ||
                          (config[val_iZone]->GetKind_Solver() == FLUID_STRUCTURE_RANS));
        bool adjoint = config[val_iZone]->GetAdjoint();
        bool fluid_structure = ((config[val_iZone]->GetKind_Solver() == FLUID_STRUCTURE_EULER) || (config[val_iZone]->GetKind_Solver() == FLUID_STRUCTURE_NAVIER_STOKES) ||
                                (config[val_iZone]->GetKind_Solver() == FLUID_STRUCTURE_RANS));
        bool wave = (config[val_iZone]->GetKind_Solver() == WAVE_EQUATION);
        bool heat = (config[val_iZone]->GetKind_Solver() == HEAT_EQUATION);
        bool fea = (config[val_iZone]->GetKind_Solver() == LINEAR_ELASTICITY);
        bool flow = (config[val_iZone]->GetKind_Solver() == EULER) || (config[val_iZone]->GetKind_Solver() == NAVIER_STOKES) ||
                (config[val_iZone]->GetKind_Solver() == RANS) || (config[val_iZone]->GetKind_Solver() == ADJ_EULER) ||
                (config[val_iZone]->GetKind_Solver() == ADJ_NAVIER_STOKES) || (config[val_iZone]->GetKind_Solver() == ADJ_RANS);

        bool output_per_surface = false;
        if(config[val_iZone]->GetnMarker_Monitoring() > 1) output_per_surface = true;



        /*--- Initialize variables to store information from all domains (direct solution) ---*/
        double Total_CLift = 0.0, Total_CDrag = 0.0, Total_CSideForce = 0.0, Total_CMx = 0.0, Total_CMy = 0.0, Total_CMz = 0.0, Total_CEff = 0.0,
                Total_CEquivArea = 0.0, Total_CNearFieldOF = 0.0, Total_CFx = 0.0, Total_CFy = 0.0, Total_CFz = 0.0, Total_CMerit = 0.0,
                Total_CT = 0.0, Total_CQ = 0.0, Total_CFreeSurface = 0.0, Total_CWave = 0.0, Total_CHeat = 0.0, Total_CpDiff = 0.0, Total_HeatFluxDiff = 0.0,
                Total_CFEA = 0.0, Total_Heat = 0.0, Total_MaxHeat = 0.0, Total_Mdot = 0.0;
        double OneD_AvgStagPress = 0.0, OneD_AvgMach = 0.0, OneD_AvgTemp = 0.0, OneD_MassFlowRate = 0.0,
                OneD_FluxAvgPress = 0.0, OneD_FluxAvgDensity = 0.0, OneD_FluxAvgVelocity = 0.0, OneD_FluxAvgEntalpy = 0.0;

        /*--- Initialize variables to store information from all domains (adjoint solution) ---*/
        double Total_Sens_Geo = 0.0, Total_Sens_Mach = 0.0, Total_Sens_AoA = 0.0;
        double Total_Sens_Press = 0.0, Total_Sens_Temp = 0.0;

        /*--- Residual arrays ---*/
        double *residual_flow         = NULL,
                *residual_turbulent    = NULL,
                *residual_transition   = NULL,
                *residual_levelset     = NULL;
        double *residual_adjflow      = NULL,
                *residual_adjturbulent = NULL,
                *residual_adjlevelset  = NULL;
        double *residual_wave         = NULL;
        double *residual_fea          = NULL;
        double *residual_heat         = NULL;

        /*--- Coefficients Monitored arrays ---*/
        double *aeroelastic_plunge = NULL,
                *aeroelastic_pitch  = NULL,
                *Surface_CLift      = NULL,
                *Surface_CDrag      = NULL,
                *Surface_CSideForce = NULL,
                *Surface_CEff       = NULL,
                *Surface_CFx        = NULL,
                *Surface_CFy        = NULL,
                *Surface_CFz        = NULL,
                *Surface_CMx        = NULL,
                *Surface_CMy        = NULL,
                *Surface_CMz        = NULL;

        /*--- Initialize number of variables ---*/
        unsigned short nVar_Flow = 0, nVar_LevelSet = 0, nVar_Turb = 0,
                nVar_Trans = 0, nVar_Wave = 0, nVar_Heat = 0, nVar_FEA = 0,
                nVar_AdjFlow = 0, nVar_AdjLevelSet = 0, nVar_AdjTurb = 0;

        /*--- Direct problem variables ---*/
        if (compressible) nVar_Flow = nDim+2; else nVar_Flow = nDim+1;
        if (turbulent) {
            switch (config[val_iZone]->GetKind_Turb_Model()){
            case SA:	   nVar_Turb = 1; break;
            case SA_NEG: nVar_Turb = 1; break;
            case ML:	   nVar_Turb = 1; break;
            case SST:    nVar_Turb = 2; break;
            }
        }
        if (transition) nVar_Trans = 2;
        if (wave) nVar_Wave = 2;
        if (fea) nVar_FEA = nDim;
        if (heat) nVar_Heat = 1;
        if (freesurface) nVar_LevelSet = 1;

        /*--- Adjoint problem variables ---*/
        if (compressible) nVar_AdjFlow = nDim+2; else nVar_AdjFlow = nDim+1;
        if (turbulent) {
            switch (config[val_iZone]->GetKind_Turb_Model()){
            case SA:	   nVar_AdjTurb = 1; break;
            case SA_NEG: nVar_AdjTurb = 1; break;
            case ML:     nVar_AdjTurb = 1; break;
            case SST:    nVar_AdjTurb = 2; break;
            }
        }
        if (freesurface) nVar_AdjLevelSet = 1;

        /*--- Allocate memory for the residual ---*/
        residual_flow       = new double[nVar_Flow];
        residual_turbulent  = new double[nVar_Turb];
        residual_transition = new double[nVar_Trans];
        residual_levelset   = new double[nVar_LevelSet];
        residual_wave       = new double[nVar_Wave];
        residual_fea        = new double[nVar_FEA];
        residual_heat       = new double[nVar_Heat];

        residual_adjflow      = new double[nVar_AdjFlow];
        residual_adjturbulent = new double[nVar_AdjTurb];
        residual_adjlevelset  = new double[nVar_AdjLevelSet];

        /*--- Allocate memory for the coefficients being monitored ---*/
        aeroelastic_plunge = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        aeroelastic_pitch  = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CLift      = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CDrag      = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CSideForce = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CEff       = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CFx        = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CFy        = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CFz        = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CMx        = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CMy        = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CMz        = new double[config[ZONE_0]->GetnMarker_Monitoring()];

        /*--- Write information from nodes ---*/
        switch (config[val_iZone]->GetKind_Solver()) {

        case EULER:                   case NAVIER_STOKES:                   case RANS:
        case FLUID_STRUCTURE_EULER:   case FLUID_STRUCTURE_NAVIER_STOKES:   case FLUID_STRUCTURE_RANS:
        case ADJ_EULER:               case ADJ_NAVIER_STOKES:               case ADJ_RANS:

            /*--- Flow solution coefficients ---*/
            Total_CLift       = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CLift();
            Total_CDrag       = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CDrag();
            Total_CSideForce  = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CSideForce();
            Total_CEff        = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CEff();
            Total_CMx         = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CMx();
            Total_CMy         = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CMy();
            Total_CMz         = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CMz();
            Total_CFx         = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CFx();
            Total_CFy         = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CFy();
            Total_CFz         = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CFz();

            if (freesurface) {
                Total_CFreeSurface = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CFreeSurface();
            }

            if (isothermal) {
                Total_Heat     = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_HeatFlux();
                Total_MaxHeat  = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_MaxHeatFlux();
            }

            if (equiv_area) {
                Total_CEquivArea    = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CEquivArea();
                Total_CNearFieldOF  = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CNearFieldOF();

                /*--- Note that there is a redefinition of the nearfield based functionals ---*/
                Total_CEquivArea    = config[val_iZone]->GetWeightCd()*Total_CDrag + (1.0-config[val_iZone]->GetWeightCd())*Total_CEquivArea;
                Total_CNearFieldOF  = config[val_iZone]->GetWeightCd()*Total_CDrag + (1.0-config[val_iZone]->GetWeightCd())*Total_CNearFieldOF;
            }

            if (inv_design) {
                Total_CpDiff  = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CpDiff();
                if (isothermal) {
                    Total_HeatFluxDiff = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_HeatFluxDiff();
                }
            }

            if (rotating_frame) {
                Total_CT      = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CT();
                Total_CQ      = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CQ();
                Total_CMerit  = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CMerit();
            }

            if (aeroelastic) {
                /*--- Look over the markers being monitored and get the desired values ---*/
                for (iMarker_Monitoring = 0; iMarker_Monitoring < config[ZONE_0]->GetnMarker_Monitoring(); iMarker_Monitoring++) {
                    aeroelastic_plunge[iMarker_Monitoring] = config[val_iZone]->GetAeroelastic_plunge(iMarker_Monitoring);
                    aeroelastic_pitch[iMarker_Monitoring]  = config[val_iZone]->GetAeroelastic_pitch(iMarker_Monitoring);
                }
            }

            if (output_per_surface) {
                /*--- Look over the markers being monitored and get the desired values ---*/
                for (iMarker_Monitoring = 0; iMarker_Monitoring < config[ZONE_0]->GetnMarker_Monitoring(); iMarker_Monitoring++) {
                    Surface_CLift[iMarker_Monitoring]      = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CLift(iMarker_Monitoring);
                    Surface_CDrag[iMarker_Monitoring]      = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CDrag(iMarker_Monitoring);
                    Surface_CSideForce[iMarker_Monitoring] = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CSideForce(iMarker_Monitoring);
                    Surface_CEff[iMarker_Monitoring]       = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CEff(iMarker_Monitoring);
                    Surface_CFx[iMarker_Monitoring]        = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CFx(iMarker_Monitoring);
                    Surface_CFy[iMarker_Monitoring]        = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CFy(iMarker_Monitoring);
                    Surface_CFz[iMarker_Monitoring]        = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CFz(iMarker_Monitoring);
                    Surface_CMx[iMarker_Monitoring]        = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CMx(iMarker_Monitoring);
                    Surface_CMy[iMarker_Monitoring]        = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CMy(iMarker_Monitoring);
                    Surface_CMz[iMarker_Monitoring]        = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CMz(iMarker_Monitoring);
                }
            }

            if (fluid_structure) {
                Total_CFEA  = solver_container[ZONE_0][FinestMesh][FEA_SOL]->GetTotal_CFEA();
            }

            if (output_1d) {

                /*--- Get area-averaged and flux-averaged values at the specified surface ---*/

                OneD_AvgStagPress = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetOneD_TotalPress();
                OneD_AvgMach = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetOneD_Mach();
                OneD_AvgTemp = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetOneD_Temp();
                OneD_MassFlowRate = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetOneD_MassFlowRate();

                OneD_FluxAvgPress = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetOneD_FluxAvgPress();
                OneD_FluxAvgDensity = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetOneD_FluxAvgDensity();
                OneD_FluxAvgVelocity = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetOneD_FluxAvgVelocity();
                OneD_FluxAvgEntalpy = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetOneD_FluxAvgEntalpy();

            }
            /*--- Get Mass Flow at the Monitored Markers ---*/


            if (output_massflow) {
                Total_Mdot = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetOneD_MassFlowRate();
            }

            /*--- Flow Residuals ---*/

            for (iVar = 0; iVar < nVar_Flow; iVar++)
                residual_flow[iVar] = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetRes_RMS(iVar);

            /*--- Turbulent residual ---*/

            if (turbulent) {
                for (iVar = 0; iVar < nVar_Turb; iVar++)
                    residual_turbulent[iVar] = solver_container[val_iZone][FinestMesh][TURB_SOL]->GetRes_RMS(iVar);
            }

            /*--- Transition residual ---*/

            if (transition) {
                for (iVar = 0; iVar < nVar_Trans; iVar++)
                    residual_transition[iVar] = solver_container[val_iZone][FinestMesh][TRANS_SOL]->GetRes_RMS(iVar);
            }

            /*--- Free Surface residual ---*/

            if (freesurface) {
                for (iVar = 0; iVar < nVar_LevelSet; iVar++)
                    residual_levelset[iVar] = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetRes_RMS(nDim+1);
            }

            /*--- FEA residual ---*/
            if (fluid_structure) {
                for (iVar = 0; iVar < nVar_FEA; iVar++)
                    residual_fea[iVar] = solver_container[ZONE_0][FinestMesh][FEA_SOL]->GetRes_RMS(iVar);
            }

            /*--- Iterations of the linear solver ---*/

            LinSolvIter = (unsigned long) solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetIterLinSolver();

            /*--- Adjoint solver ---*/

            if (adjoint) {

                /*--- Adjoint solution coefficients ---*/

                Total_Sens_Geo   = solver_container[val_iZone][FinestMesh][ADJFLOW_SOL]->GetTotal_Sens_Geo();
                Total_Sens_Mach  = solver_container[val_iZone][FinestMesh][ADJFLOW_SOL]->GetTotal_Sens_Mach();
                Total_Sens_AoA   = solver_container[val_iZone][FinestMesh][ADJFLOW_SOL]->GetTotal_Sens_AoA();
                Total_Sens_Press = solver_container[val_iZone][FinestMesh][ADJFLOW_SOL]->GetTotal_Sens_Press();
                Total_Sens_Temp  = solver_container[val_iZone][FinestMesh][ADJFLOW_SOL]->GetTotal_Sens_Temp();

                /*--- Adjoint flow residuals ---*/

                for (iVar = 0; iVar < nVar_AdjFlow; iVar++) {
                    residual_adjflow[iVar] = solver_container[val_iZone][FinestMesh][ADJFLOW_SOL]->GetRes_RMS(iVar);
                }

                /*--- Adjoint turbulent residuals ---*/

                if (turbulent) {
                    if (!config[val_iZone]->GetFrozen_Visc()) {
                        for (iVar = 0; iVar < nVar_AdjTurb; iVar++)
                            residual_adjturbulent[iVar] = solver_container[val_iZone][FinestMesh][ADJTURB_SOL]->GetRes_RMS(iVar);
                    }
                }

                /*--- Adjoint level set residuals ---*/

                if (freesurface) {
                    for (iVar = 0; iVar < nVar_AdjLevelSet; iVar++)
                        residual_adjlevelset[iVar] = solver_container[val_iZone][FinestMesh][ADJFLOW_SOL]->GetRes_RMS(nDim+1);
                }

            }

            break;

        case WAVE_EQUATION:

            /*--- Wave coefficients  ---*/

            Total_CWave = solver_container[val_iZone][FinestMesh][WAVE_SOL]->GetTotal_CWave();

            /*--- Wave Residuals ---*/

            for (iVar = 0; iVar < nVar_Wave; iVar++) {
                residual_wave[iVar] = solver_container[val_iZone][FinestMesh][WAVE_SOL]->GetRes_RMS(iVar);
            }

            break;

        case HEAT_EQUATION:

            /*--- Heat coefficients  ---*/

            Total_CHeat = solver_container[val_iZone][FinestMesh][HEAT_SOL]->GetTotal_CHeat();

            /*--- Wave Residuals ---*/

            for (iVar = 0; iVar < nVar_Heat; iVar++) {
                residual_heat[iVar] = solver_container[val_iZone][FinestMesh][HEAT_SOL]->GetRes_RMS(iVar);
            }

            break;

        case LINEAR_ELASTICITY:

            /*--- FEA coefficients ---*/

            Total_CFEA = solver_container[val_iZone][FinestMesh][FEA_SOL]->GetTotal_CFEA();

            /*--- Plasma Residuals ---*/

            for (iVar = 0; iVar < nVar_FEA; iVar++) {
                residual_fea[iVar] = solver_container[val_iZone][FinestMesh][FEA_SOL]->GetRes_RMS(iVar);
            }

            break;

        }

        /*--- Header frequency ---*/

        bool Unsteady = ((config[val_iZone]->GetUnsteady_Simulation() == DT_STEPPING_1ST) ||
                         (config[val_iZone]->GetUnsteady_Simulation() == DT_STEPPING_2ND));
        bool In_NoDualTime = (!DualTime_Iteration && (iExtIter % config[val_iZone]->GetWrt_Con_Freq() == 0));
        bool In_DualTime_0 = (DualTime_Iteration && (iIntIter % config[val_iZone]->GetWrt_Con_Freq_DualTime() == 0));
        bool In_DualTime_1 = (!DualTime_Iteration && Unsteady);
        bool In_DualTime_2 = (Unsteady && DualTime_Iteration && (iExtIter % config[val_iZone]->GetWrt_Con_Freq() == 0));
        bool In_DualTime_3 = (Unsteady && !DualTime_Iteration && (iExtIter % config[val_iZone]->GetWrt_Con_Freq() == 0));

        bool write_heads;
        if (Unsteady) write_heads = (iIntIter == 0);
        else write_heads = (((iExtIter % (config[val_iZone]->GetWrt_Con_Freq()*20)) == 0));

        if ((In_NoDualTime || In_DualTime_0 || In_DualTime_1) && (In_NoDualTime || In_DualTime_2 || In_DualTime_3)) {

            /*--- Prepare the history file output, note that the dual
       time output don't write to the history file ---*/

            if (!DualTime_Iteration) {

                /*--- Write the begining of the history file ---*/
                sprintf (begin, "%12d", int(iExtIter));

                /*--- Write the end of the history file ---*/
                sprintf (end, ", %12.10f, %12.10f, %12.10f\n", double(LinSolvIter), config[val_iZone]->GetCFL(MESH_0), timeused/60.0);

                /*--- Write the solution and residual of the history file ---*/
                switch (config[val_iZone]->GetKind_Solver()) {

                case EULER : case NAVIER_STOKES: case RANS:
                case FLUID_STRUCTURE_EULER: case FLUID_STRUCTURE_NAVIER_STOKES: case FLUID_STRUCTURE_RANS:
                case ADJ_EULER: case ADJ_NAVIER_STOKES: case ADJ_RANS:

                    /*--- Direct coefficients ---*/
                    sprintf (direct_coeff, ", %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f",
                             Total_CLift, Total_CDrag, Total_CSideForce, Total_CMx, Total_CMy, Total_CMz, Total_CFx, Total_CFy,
                             Total_CFz, Total_CEff);
                    if (isothermal)
                        sprintf (direct_coeff, ", %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f", Total_CLift, Total_CDrag, Total_CSideForce, Total_CMx, Total_CMy,
                                 Total_CMz, Total_CFx, Total_CFy, Total_CFz, Total_CEff, Total_Heat, Total_MaxHeat);
                    if (equiv_area)
                        sprintf (direct_coeff, ", %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f", Total_CLift, Total_CDrag, Total_CSideForce, Total_CMx, Total_CMy, Total_CMz, Total_CFx, Total_CFy, Total_CFz, Total_CEff, Total_CEquivArea, Total_CNearFieldOF);
                    if (inv_design) {
                        sprintf (direct_coeff, ", %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f", Total_CLift, Total_CDrag, Total_CSideForce, Total_CMx, Total_CMy, Total_CMz, Total_CFx, Total_CFy, Total_CFz, Total_CEff, Total_CpDiff);
                        Total_CpDiff  = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CpDiff();
                        if (isothermal) {
                            sprintf (direct_coeff, ", %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f", Total_CLift, Total_CDrag, Total_CSideForce, Total_CMx, Total_CMy, Total_CMz, Total_CFx, Total_CFy, Total_CFz, Total_CEff, Total_Heat, Total_MaxHeat, Total_CpDiff, Total_HeatFluxDiff);
                        }
                    }
                    if (rotating_frame)
                        sprintf (direct_coeff, ", %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f", Total_CLift, Total_CDrag, Total_CSideForce, Total_CMx,
                                 Total_CMy, Total_CMz, Total_CFx, Total_CFy, Total_CFz, Total_CEff, Total_CMerit, Total_CT, Total_CQ);

                    if (freesurface) {
                        sprintf (direct_coeff, ", %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f", Total_CLift, Total_CDrag, Total_CSideForce, Total_CMx, Total_CMy, Total_CMz, Total_CFx, Total_CFy,
                                 Total_CFz, Total_CEff, Total_CFreeSurface);
                    }
                    if (fluid_structure)
                        sprintf (direct_coeff, ", %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f", Total_CLift, Total_CDrag, Total_CSideForce, Total_CMx, Total_CMy, Total_CMz,
                                 Total_CFx, Total_CFy, Total_CFz, Total_CEff, Total_CFEA);

                    if (aeroelastic) {
                        for (iMarker_Monitoring = 0; iMarker_Monitoring < config[ZONE_0]->GetnMarker_Monitoring(); iMarker_Monitoring++) {
                            //Append one by one the surface coeff to aeroelastic coeff. (Think better way do this, maybe use string)
                            if (iMarker_Monitoring == 0) {
                                sprintf(aeroelastic_coeff, ", %12.10f",aeroelastic_plunge[iMarker_Monitoring]);
                            }
                            else {
                                sprintf(surface_coeff, ", %12.10f",aeroelastic_plunge[iMarker_Monitoring]);
                                strcat(aeroelastic_coeff, surface_coeff);
                            }
                            sprintf(surface_coeff, ", %12.10f",aeroelastic_pitch[iMarker_Monitoring]);
                            strcat(aeroelastic_coeff, surface_coeff);
                        }
                    }

                    if (output_per_surface) {
                        for (iMarker_Monitoring = 0; iMarker_Monitoring < config[ZONE_0]->GetnMarker_Monitoring(); iMarker_Monitoring++) {
                            //Append one by one the surface coeff to monitoring coeff. (Think better way do this, maybe use string)
                            if (iMarker_Monitoring == 0) {
                                sprintf(monitoring_coeff, ", %12.10f",Surface_CLift[iMarker_Monitoring]);
                            }
                            else {
                                sprintf(surface_coeff, ", %12.10f",Surface_CLift[iMarker_Monitoring]);
                                strcat(monitoring_coeff, surface_coeff);
                            }
                            sprintf(surface_coeff, ", %12.10f",Surface_CDrag[iMarker_Monitoring]);
                            strcat(monitoring_coeff, surface_coeff);
                            sprintf(surface_coeff, ", %12.10f",Surface_CSideForce[iMarker_Monitoring]);
                            strcat(monitoring_coeff, surface_coeff);
                            sprintf(surface_coeff, ", %12.10f",Surface_CEff[iMarker_Monitoring]);
                            strcat(monitoring_coeff, surface_coeff);
                            sprintf(surface_coeff, ", %12.10f",Surface_CFx[iMarker_Monitoring]);
                            strcat(monitoring_coeff, surface_coeff);
                            sprintf(surface_coeff, ", %12.10f",Surface_CFy[iMarker_Monitoring]);
                            strcat(monitoring_coeff, surface_coeff);
                            sprintf(surface_coeff, ", %12.10f",Surface_CFz[iMarker_Monitoring]);
                            strcat(monitoring_coeff, surface_coeff);
                            sprintf(surface_coeff, ", %12.10f",Surface_CMx[iMarker_Monitoring]);
                            strcat(monitoring_coeff, surface_coeff);
                            sprintf(surface_coeff, ", %12.10f",Surface_CMy[iMarker_Monitoring]);
                            strcat(monitoring_coeff, surface_coeff);
                            sprintf(surface_coeff, ", %12.10f",Surface_CMz[iMarker_Monitoring]);
                            strcat(monitoring_coeff, surface_coeff);
                        }
                    }


                    /*--- Flow residual ---*/
                    if (nDim == 2) {
                        if (compressible) sprintf (flow_resid, ", %12.10f, %12.10f, %12.10f, %12.10f, %12.10f", log10 (residual_flow[0]), log10 (residual_flow[1]), log10 (residual_flow[2]), log10 (residual_flow[3]), dummy );
                        if (incompressible || freesurface) sprintf (flow_resid, ", %12.10f, %12.10f, %12.10f, %12.10f, %12.10f", log10 (residual_flow[0]), log10 (residual_flow[1]), log10 (residual_flow[2]), dummy, dummy );
                    }
                    else {
                        if (compressible) sprintf (flow_resid, ", %12.10f, %12.10f, %12.10f, %12.10f, %12.10f", log10 (residual_flow[0]), log10 (residual_flow[1]), log10 (residual_flow[2]), log10 (residual_flow[3]), log10 (residual_flow[4]) );
                        if (incompressible || freesurface) sprintf (flow_resid, ", %12.10f, %12.10f, %12.10f, %12.10f, %12.10f", log10 (residual_flow[0]), log10 (residual_flow[1]), log10 (residual_flow[2]), log10 (residual_flow[3]), dummy );
                    }

                    /*--- Turbulent residual ---*/
                    if (turbulent){
                        switch(nVar_Turb) {
                        case 1: sprintf (turb_resid, ", %12.10f", log10 (residual_turbulent[0])); break;
                        case 2: sprintf (turb_resid, ", %12.10f, %12.10f", log10(residual_turbulent[0]), log10(residual_turbulent[1])); break;
                        }
                    }
                    /*---- Averaged stagnation pressure at an exit ---- */
                    if (output_1d) {
                        sprintf( oneD_outputs, ", %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, %12.10f", OneD_AvgStagPress, OneD_AvgMach, OneD_AvgTemp, OneD_MassFlowRate, OneD_FluxAvgPress, OneD_FluxAvgDensity, OneD_FluxAvgVelocity, OneD_FluxAvgEntalpy);
                    }
                    if (output_massflow){
                        sprintf(massflow_outputs,", %12.10f", Total_Mdot);
                    }


                    /*--- Transition residual ---*/
                    if (transition){
                        sprintf (trans_resid, ", %12.10f, %12.10f", log10(residual_transition[0]), log10(residual_transition[1]));
                    }

                    /*--- Free surface residual ---*/
                    if (freesurface) {
                        sprintf (levelset_resid, ", %12.10f", log10 (residual_levelset[0]));
                    }

                    /*--- Fluid structure residual ---*/
                    if (fluid_structure) {
                        if (nDim == 2) sprintf (levelset_resid, ", %12.10f, %12.10f, 0.0", log10 (residual_fea[0]), log10 (residual_fea[1]));
                        else sprintf (levelset_resid, ", %12.10f, %12.10f, %12.10f", log10 (residual_fea[0]), log10 (residual_fea[1]), log10 (residual_fea[2]));
                    }

                    if (adjoint) {

                        /*--- Adjoint coefficients ---*/
                        sprintf (adjoint_coeff, ", %12.10f, %12.10f, %12.10f, %12.10f, %12.10f, 0.0", Total_Sens_Geo, Total_Sens_Mach, Total_Sens_AoA, Total_Sens_Press, Total_Sens_Temp);

                        /*--- Adjoint flow residuals ---*/
                        if (nDim == 2) {
                            if (compressible) sprintf (adj_flow_resid, ", %12.10f, %12.10f, %12.10f, %12.10f, 0.0", log10 (residual_adjflow[0]),log10 (residual_adjflow[1]),log10 (residual_adjflow[2]),log10 (residual_adjflow[3]) );
                            if (incompressible || freesurface) sprintf (adj_flow_resid, ", %12.10f, %12.10f, %12.10f, 0.0, 0.0", log10 (residual_adjflow[0]),log10 (residual_adjflow[1]),log10 (residual_adjflow[2]) );
                        }
                        else {
                            if (compressible) sprintf (adj_flow_resid, ", %12.10f, %12.10f, %12.10f, %12.10f, %12.10f", log10 (residual_adjflow[0]),log10 (residual_adjflow[1]),log10 (residual_adjflow[2]),log10 (residual_adjflow[3]), log10 (residual_adjflow[4]) );
                            if (incompressible || freesurface) sprintf (adj_flow_resid, ", %12.10f, %12.10f, %12.10f, %12.10f, 0.0", log10 (residual_adjflow[0]),log10 (residual_adjflow[1]),log10 (residual_adjflow[2]),log10 (residual_adjflow[3]) );
                        }

                        /*--- Adjoint turbulent residuals ---*/
                        if (turbulent)
                            if (!config[val_iZone]->GetFrozen_Visc())
                                sprintf (adj_turb_resid, ", %12.10f", log10 (residual_adjturbulent[0]));

                        /*--- Adjoint free surface residuals ---*/
                        if (freesurface) sprintf (adj_levelset_resid, ", %12.10f", log10 (residual_adjlevelset[0]));
                    }

                    break;

                case WAVE_EQUATION:

                    sprintf (direct_coeff, ", %12.10f", Total_CWave);
                    sprintf (wave_resid, ", %12.10f, %12.10f, %12.10f, %12.10f, %12.10f", log10 (residual_wave[0]), log10 (residual_wave[1]), dummy, dummy, dummy );

                    break;

                case HEAT_EQUATION:

                    sprintf (direct_coeff, ", %12.10f", Total_CHeat);
                    sprintf (heat_resid, ", %12.10f, %12.10f, %12.10f, %12.10f, %12.10f", log10 (residual_heat[0]), dummy, dummy, dummy, dummy );

                    break;

                case LINEAR_ELASTICITY:

                    sprintf (direct_coeff, ", %12.10f", Total_CFEA);
                    sprintf (fea_resid, ", %12.10f, %12.10f, %12.10f, %12.10f, %12.10f", log10 (residual_fea[0]), dummy, dummy, dummy, dummy );

                    break;

                }
            }

            /*--- Write the screen header---*/
            if ((write_heads) && !(!DualTime_Iteration && Unsteady)) {

                if (!Unsteady) {
                    switch (config[val_iZone]->GetKind_Solver()) {
                    case EULER :                  case NAVIER_STOKES: case RANS:
                    case FLUID_STRUCTURE_EULER :  case FLUID_STRUCTURE_NAVIER_STOKES: case FLUID_STRUCTURE_RANS:
                        cout << endl << "Local time stepping summary:" << endl;
                        for (unsigned short iMesh = FinestMesh; iMesh <= config[val_iZone]->GetnMGLevels(); iMesh++)
                            cout << "MG level: "<< iMesh << "-> Min. DT: " << solver_container[val_iZone][iMesh][FLOW_SOL]->GetMin_Delta_Time()<<
                                    ". Max. DT: " << solver_container[val_iZone][iMesh][FLOW_SOL]->GetMax_Delta_Time() <<
                                    ". CFL number: " << config[val_iZone]->GetCFL(iMesh)  << "." << endl;
                        break;

                    }
                }
                else {
                    if (flow) {
                        cout << endl << "Min DT: " << solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetMin_Delta_Time()<<
                                ".Max DT: " << solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetMax_Delta_Time() <<
                                ".Dual Time step: " << config[val_iZone]->GetDelta_UnstTimeND() << ".";
                    }
                    else {
                        cout << endl << "Dual Time step: " << config[val_iZone]->GetDelta_UnstTimeND() << ".";
                    }
                }

                switch (config[val_iZone]->GetKind_Solver()) {
                case EULER :                  case NAVIER_STOKES:
                case FLUID_STRUCTURE_EULER :  case FLUID_STRUCTURE_NAVIER_STOKES:

                    /*--- Visualize the maximum residual ---*/
                    iPointMaxResid = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetPoint_Max(0);
                    Coord = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetPoint_Max_Coord(0);

                    cout << endl << "log10[Maximum residual]: " << log10(solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetRes_Max(0)) << "." << endl;
                    if (config[val_iZone]->GetSystemMeasurements() == SI) {
                        cout <<"Maximum residual point " << iPointMaxResid << ", located at (" << Coord[0] << ", " << Coord[1];
                        if (nDim == 3) cout << ", " << Coord[2];
                        cout <<   ")." << endl;
                    }
                    else {
                        cout <<"Maximum residual point " << iPointMaxResid << ", located at (" << Coord[0]*12.0 << ", " << Coord[1]*12.0;
                        if (nDim == 3) cout << ", " << Coord[2]*12.0;
                        cout <<   ")." << endl;
                    }

                    /*--- Print out the number of non-physical points and reconstructions ---*/
                    if (config[val_iZone]->GetNonphysical_Points() > 0)
                        cout << "There are " << config[val_iZone]->GetNonphysical_Points() << " non-physical points in the solution." << endl;
                    if (config[val_iZone]->GetNonphysical_Reconstr() > 0)
                        cout << "There are " << config[val_iZone]->GetNonphysical_Reconstr() << " non-physical states in the upwind reconstruction." << endl;

                    if (!Unsteady) cout << endl << " Iter" << "    Time(s)";
                    else cout << endl << " IntIter" << " ExtIter";

                    if (!fluid_structure) {
                        if (incompressible) cout << "   Res[Press]" << "     Res[Velx]" << "   CLift(Total)" << "   CDrag(Total)" << endl;
                        else if (freesurface) cout << "   Res[Press]" << "     Res[Dist]" << "   CLift(Total)" << "     CLevelSet" << endl;
                        else if (rotating_frame && nDim == 3) cout << "     Res[Rho]" << "     Res[RhoE]" << " CThrust(Total)" << " CTorque(Total)" << endl;
                        else if (aeroelastic) cout << "     Res[Rho]" << "     Res[RhoE]" << "   CLift(Total)" << "   CDrag(Total)" << "         plunge" << "          pitch" << endl;
                        else if (equiv_area) cout << "     Res[Rho]" << "   CLift(Total)" << "   CDrag(Total)" << "    CPress(N-F)" << endl;
                        else cout << "     Res[Rho]" << "     Res[RhoE]" << "   CLift(Total)" << "   CDrag(Total)" << endl;
                    }
                    else if (fluid_structure) cout << "     Res[Rho]" << "   Res[Displx]" << "   CLift(Total)" << "   CDrag(Total)" << endl;

                    break;

                case RANS : case FLUID_STRUCTURE_RANS:

                    /*--- Visualize the maximum residual ---*/
                    iPointMaxResid = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetPoint_Max(0);
                    Coord = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetPoint_Max_Coord(0);
                    cout << endl << "log10[Maximum residual]: " << log10(solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetRes_Max(0)) << "." << endl;
                    if (config[val_iZone]->GetSystemMeasurements() == SI) {
                        cout <<"Maximum residual point " << iPointMaxResid << ", located at (" << Coord[0] << ", " << Coord[1];
                        if (nDim == 3) cout << ", " << Coord[2];
                        cout <<   ")." << endl;
                    }
                    else {
                        cout <<"Maximum residual point " << iPointMaxResid << ", located at (" << Coord[0]*12.0 << ", " << Coord[1]*12.0;
                        if (nDim == 3) cout << ", " << Coord[2]*12.0;
                        cout <<   ")." << endl;
                    }
                    cout <<"Maximum Omega " << solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetOmega_Max() << ", maximum Strain Rate " << solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetStrainMag_Max() << "." << endl;

                    /*--- Print out the number of non-physical points and reconstructions ---*/
                    if (config[val_iZone]->GetNonphysical_Points() > 0)
                        cout << "There are " << config[val_iZone]->GetNonphysical_Points() << " non-physical points in the solution." << endl;
                    if (config[val_iZone]->GetNonphysical_Reconstr() > 0)
                        cout << "There are " << config[val_iZone]->GetNonphysical_Reconstr() << " non-physical states in the upwind reconstruction." << endl;

                    if (!Unsteady) cout << endl << " Iter" << "    Time(s)";
                    else cout << endl << " IntIter" << " ExtIter";
                    if (incompressible || freesurface) cout << "   Res[Press]";
                    else cout << "      Res[Rho]";//,cout << "     Res[RhoE]";

                    switch (config[val_iZone]->GetKind_Turb_Model()){
                    case SA:	   cout << "       Res[nu]"; break;
                    case SA_NEG: cout << "       Res[nu]"; break;
                    case ML:	   cout << "       Res[nu]"; break;
                    case SST:	   cout << "     Res[kine]" << "     Res[omega]"; break;
                    }

                    if (transition) { cout << "      Res[Int]" << "       Res[Re]"; }
                    else if (rotating_frame && nDim == 3 ) cout << "   CThrust(Total)" << "   CTorque(Total)" << endl;
                    else if (aeroelastic) cout << "   CLift(Total)" << "   CDrag(Total)" << "         plunge" << "          pitch" << endl;
                    else if (equiv_area) cout << "   CLift(Total)" << "   CDrag(Total)" << "    CPress(N-F)" << endl;
                    else cout << "   CLift(Total)"   << "   CDrag(Total)"   << endl;

                    break;

                case WAVE_EQUATION :
                    if (!Unsteady) cout << endl << " Iter" << "    Time(s)";
                    else cout << endl << " IntIter" << "  ExtIter";

                    cout << "      Res[Wave]" << "   CWave(Total)"<<  endl;
                    break;

                case HEAT_EQUATION :
                    if (!Unsteady) cout << endl << " Iter" << "    Time(s)";
                    else cout << endl << " IntIter" << "  ExtIter";

                    cout << "      Res[Heat]" << "   CHeat(Total)"<<  endl;
                    break;

                case LINEAR_ELASTICITY :
                    if (!Unsteady) cout << endl << " Iter" << "    Time(s)";
                    else cout << endl << " IntIter" << "  ExtIter";

                    if (nDim == 2) cout << "    Res[Displx]" << "    Res[Disply]" << "   CFEA(Total)"<<  endl;
                    if (nDim == 3) cout << "    Res[Displx]" << "    Res[Disply]" << "    Res[Displz]" << "   CFEA(Total)"<<  endl;
                    break;

                case ADJ_EULER :              case ADJ_NAVIER_STOKES :

                    /*--- Visualize the maximum residual ---*/
                    iPointMaxResid = solver_container[val_iZone][FinestMesh][ADJFLOW_SOL]->GetPoint_Max(0);
                    Coord = solver_container[val_iZone][FinestMesh][ADJFLOW_SOL]->GetPoint_Max_Coord(0);
                    cout << endl << "log10[Maximum residual]: " << log10(solver_container[val_iZone][FinestMesh][ADJFLOW_SOL]->GetRes_Max(0)) << "." << endl;
                    if (config[val_iZone]->GetSystemMeasurements() == SI) {
                        cout <<"Maximum residual point " << iPointMaxResid << ", located at (" << Coord[0] << ", " << Coord[1];
                        if (nDim == 3) cout << ", " << Coord[2];
                        cout <<   ")." << endl;
                    }
                    else {
                        cout <<"Maximum residual point " << iPointMaxResid << ", located at (" << Coord[0]*12.0 << ", " << Coord[1]*12.0;
                        if (nDim == 3) cout << ", " << Coord[2]*12.0;
                        cout <<   ")." << endl;
                    }

                    /*--- Print out the number of non-physical points and reconstructions ---*/
                    if (config[val_iZone]->GetNonphysical_Points() > 0)
                        cout << "There are " << config[val_iZone]->GetNonphysical_Points() << " non-physical points in the solution." << endl;

                    if (!Unsteady) cout << endl << " Iter" << "    Time(s)";
                    else cout << endl << " IntIter" << "  ExtIter";

                    if (incompressible || freesurface) cout << "   Res[Psi_Press]" << "   Res[Psi_Velx]";
                    else cout << "   Res[Psi_Rho]" << "     Res[Psi_E]";
                    cout << "      Sens_Geo" << "     Sens_Mach" << endl;

                    if (freesurface) {
                        cout << "   Res[Psi_Press]" << "   Res[Psi_Dist]" << "    Sens_Geo" << "   Sens_Mach" << endl;
                    }
                    break;

                case ADJ_RANS :

                    /*--- Visualize the maximum residual ---*/
                    iPointMaxResid = solver_container[val_iZone][FinestMesh][ADJFLOW_SOL]->GetPoint_Max(0);
                    Coord = solver_container[val_iZone][FinestMesh][ADJFLOW_SOL]->GetPoint_Max_Coord(0);
                    cout << endl << "log10[Maximum residual]: " << log10(solver_container[val_iZone][FinestMesh][ADJFLOW_SOL]->GetRes_Max(0)) << "." << endl;
                    if (config[val_iZone]->GetSystemMeasurements() == SI) {
                        cout <<"Maximum residual point " << iPointMaxResid << ", located at (" << Coord[0] << ", " << Coord[1];
                        if (nDim == 3) cout << ", " << Coord[2];
                        cout <<   ")." << endl;
                    }
                    else {
                        cout <<"Maximum residual point " << iPointMaxResid << ", located at (" << Coord[0]*12.0 << ", " << Coord[1]*12.0;
                        if (nDim == 3) cout << ", " << Coord[2]*12.0;
                        cout <<   ")." << endl;
                    }

                    /*--- Print out the number of non-physical points and reconstructions ---*/
                    if (config[val_iZone]->GetNonphysical_Points() > 0)
                        cout << "There are " << config[val_iZone]->GetNonphysical_Points() << " non-physical points in the solution." << endl;

                    if (!Unsteady) cout << endl << " Iter" << "    Time(s)";
                    else cout << endl << " IntIter" << "  ExtIter";

                    if (incompressible || freesurface) cout << "     Res[Psi_Press]";
                    else cout << "     Res[Psi_Rho]";

                    if (!config[val_iZone]->GetFrozen_Visc()) {
                        cout << "      Res[Psi_nu]";
                    }
                    else {
                        if (incompressible || freesurface) cout << "   Res[Psi_Velx]";
                        else cout << "     Res[Psi_E]";
                    }
                    cout << "     Sens_Geo" << "    Sens_Mach" << endl;

                    if (freesurface) {
                        cout << "   Res[Psi_Press]" << "   Res[Psi_Dist]" << "    Sens_Geo" << "   Sens_Mach" << endl;
                    }
                    break;

                }

            }

            /*--- Write the solution on the screen and history file ---*/
            cout.precision(6);
            cout.setf(ios::fixed,ios::floatfield);

            if (!Unsteady) {
                cout.width(5); cout << iExtIter;
                cout.width(11); cout << timeiter;

            } else {
                cout.width(8); cout << iIntIter;
                cout.width(8); cout << iExtIter;
            }

            switch (config[val_iZone]->GetKind_Solver()) {
            case EULER : case NAVIER_STOKES:
            case FLUID_STRUCTURE_EULER: case FLUID_STRUCTURE_NAVIER_STOKES:

                if (!DualTime_Iteration) {
                    if (compressible) ConvHist_file[0] << begin << direct_coeff << flow_resid;
                    if (incompressible) ConvHist_file[0] << begin << direct_coeff << flow_resid;
                    if (freesurface) ConvHist_file[0] << begin << direct_coeff << flow_resid << levelset_resid << end;
                    if (fluid_structure) ConvHist_file[0] << fea_resid;
                    if (aeroelastic) ConvHist_file[0] << aeroelastic_coeff;
                    if (output_per_surface) ConvHist_file[0] << monitoring_coeff;
                    if (output_1d) ConvHist_file[0] << oneD_outputs;
                    if (output_massflow) ConvHist_file[0] << massflow_outputs;
                    ConvHist_file[0] << end;
                    ConvHist_file[0].flush();
                }
                cout.precision(6);
                cout.setf(ios::fixed,ios::floatfield);
                cout.width(13); cout << log10(residual_flow[0]);
                if (!fluid_structure && !equiv_area) {
                    if (compressible) {
                        if (nDim == 2 ) { cout.width(14); cout << log10(residual_flow[3]); }
                        else { cout.width(14); cout << log10(residual_flow[4]); }
                    }
                    if (incompressible) { cout.width(14); cout << log10(residual_flow[1]); }
                    if (freesurface) { cout.width(14); cout << log10(residual_levelset[0]); }
                }
                else if (fluid_structure) { cout.width(14); cout << log10(residual_fea[0]); }
                if (rotating_frame && nDim == 3 ) {
                    cout.setf(ios::scientific,ios::floatfield);
                    cout.width(15); cout << Total_CT;
                    cout.width(15); cout << Total_CQ;
                    cout.unsetf(ios_base::floatfield);
                }
                else if (equiv_area) { cout.width(15); cout << min(10000.0,max(-10000.0, Total_CLift)); cout.width(15); cout << min(10000.0,max(-10000.0, Total_CDrag)); cout.width(15);
                    cout.precision(4);
                    cout.setf(ios::scientific,ios::floatfield);
                    cout << Total_CNearFieldOF; }
                else if (freesurface) { cout.width(15); cout << Total_CLift; cout.width(15); cout << Total_CFreeSurface; }
                else { cout.width(15); cout << min(10000.0,max(-10000.0, Total_CLift)); cout.width(15); cout << min(10000.0,max(-10000.0, Total_CDrag)); }
                if (aeroelastic) {
                    cout.setf(ios::scientific,ios::floatfield);
                    cout.width(15); cout << aeroelastic_plunge[0]; //Only output the first marker being monitored to the console.
                    cout.width(15); cout << aeroelastic_pitch[0];
                    cout.unsetf(ios_base::floatfield);
                }
                cout << endl;

                break;

            case RANS :

                if (!DualTime_Iteration) {
                    ConvHist_file[0] << begin << direct_coeff << flow_resid << turb_resid;
                    if (aeroelastic) ConvHist_file[0] << aeroelastic_coeff;
                    if (output_per_surface) ConvHist_file[0] << monitoring_coeff;
                    if (output_1d) ConvHist_file[0] << oneD_outputs;
                    ConvHist_file[0] << end;
                    ConvHist_file[0].flush();
                }

                cout.precision(6);
                cout.setf(ios::fixed,ios::floatfield);

                if (incompressible || freesurface) cout.width(13);
                else  cout.width(14);
                cout << log10(residual_flow[0]);
                //          else  cout.width(14),
                //                 cout << log10(residual_flow[0]),
                //                 cout.width(14);
                //          if ( nDim==2 ) cout << log10(residual_flow[3]);
                //          if ( nDim==3 ) cout << log10(residual_flow[4]);

                switch(nVar_Turb) {
                case 1: cout.width(14); cout << log10(residual_turbulent[0]); break;
                case 2: cout.width(14); cout << log10(residual_turbulent[0]);
                    cout.width(15); cout << log10(residual_turbulent[1]); break;
                }

                if (transition) { cout.width(14); cout << log10(residual_transition[0]); cout.width(14); cout << log10(residual_transition[1]); }

                if (rotating_frame && nDim == 3 ) {
                    cout.setf(ios::scientific,ios::floatfield);
                    cout.width(15); cout << Total_CT; cout.width(15);
                    cout << Total_CQ;
                    cout.unsetf(ios_base::floatfield);
                }
                else if (equiv_area) { cout.width(15); cout << min(10000.0,max(-10000.0, Total_CLift)); cout.width(15); cout << min(10000.0,max(-10000.0, Total_CDrag)); cout.width(15);
                    cout.precision(4);
                    cout.setf(ios::scientific,ios::floatfield);
                    cout << Total_CNearFieldOF; }
                else { cout.width(15); cout << min(10000.0,max(-10000.0, Total_CLift)); cout.width(15); cout << min(10000.0,max(-10000.0, Total_CDrag)); }

                if (aeroelastic) {
                    cout.setf(ios::scientific,ios::floatfield);
                    cout.width(15); cout << aeroelastic_plunge[0]; //Only output the first marker being monitored to the console.
                    cout.width(15); cout << aeroelastic_pitch[0];
                    cout.unsetf(ios_base::floatfield);
                }
                cout << endl;

                if (freesurface) {
                    if (!DualTime_Iteration) {
                        ConvHist_file[0] << begin << direct_coeff << flow_resid << levelset_resid << end;
                        ConvHist_file[0].flush();
                    }

                    cout.precision(6);
                    cout.setf(ios::fixed,ios::floatfield);
                    cout.width(13); cout << log10(residual_flow[0]);
                    cout.width(14); cout << log10(residual_levelset[0]);
                    cout.width(15); cout << Total_CLift;
                    cout.width(14); cout << Total_CFreeSurface;

                    cout << endl;
                }

                break;

            case WAVE_EQUATION:

                if (!DualTime_Iteration) {
                    ConvHist_file[0] << begin << wave_coeff << wave_resid << end;
                    ConvHist_file[0].flush();
                }

                cout.precision(6);
                cout.setf(ios::fixed,ios::floatfield);
                cout.width(14); cout << log10(residual_wave[0]);
                cout.width(14); cout << Total_CWave;
                cout << endl;
                break;

            case HEAT_EQUATION:

                if (!DualTime_Iteration) {
                    ConvHist_file[0] << begin << heat_coeff << heat_resid << end;
                    ConvHist_file[0].flush();
                }

                cout.precision(6);
                cout.setf(ios::fixed,ios::floatfield);
                cout.width(14); cout << log10(residual_heat[0]);
                cout.width(14); cout << Total_CHeat;
                cout << endl;
                break;

            case LINEAR_ELASTICITY:

                if (!DualTime_Iteration) {
                    ConvHist_file[0] << begin << fea_coeff << fea_resid << end;
                    ConvHist_file[0].flush();
                }

                cout.precision(6);
                cout.setf(ios::fixed,ios::floatfield);
                cout.width(15); cout << log10(residual_fea[0]);
                cout.width(15); cout << log10(residual_fea[1]);
                if (nDim == 3) { cout.width(15); cout << log10(residual_fea[2]); }
                cout.precision(4);
                cout.setf(ios::scientific,ios::floatfield);
                cout.width(14); cout << Total_CFEA;
                cout << endl;
                break;

            case ADJ_EULER :              case ADJ_NAVIER_STOKES :

                if (!DualTime_Iteration) {
                    ConvHist_file[0] << begin << adjoint_coeff << adj_flow_resid << end;
                    ConvHist_file[0].flush();
                }

                cout.precision(6);
                cout.setf(ios::fixed,ios::floatfield);
                if (compressible) {
                    cout.width(15); cout << log10(residual_adjflow[0]);
                    cout.width(15); cout << log10(residual_adjflow[nDim+1]);
                }
                if (incompressible || freesurface) {
                    cout.width(17); cout << log10(residual_adjflow[0]);
                    cout.width(16); cout << log10(residual_adjflow[1]);
                }
                cout.precision(4);
                cout.setf(ios::scientific,ios::floatfield);
                cout.width(14); cout << Total_Sens_Geo;
                cout.width(14); cout << Total_Sens_Mach;
                cout << endl;
                cout.unsetf(ios_base::floatfield);

                if (freesurface) {
                    if (!DualTime_Iteration) {
                        ConvHist_file[0] << begin << adjoint_coeff << adj_flow_resid << adj_levelset_resid << end;
                        ConvHist_file[0].flush();
                    }

                    cout.precision(6);
                    cout.setf(ios::fixed,ios::floatfield);
                    cout.width(17); cout << log10(residual_adjflow[0]);
                    cout.width(16); cout << log10(residual_adjlevelset[0]);
                    cout.precision(3);
                    cout.setf(ios::scientific,ios::floatfield);
                    cout.width(12); cout << Total_Sens_Geo;
                    cout.width(12); cout << Total_Sens_Mach;
                    cout.unsetf(ios_base::floatfield);
                    cout << endl;
                }

                break;

            case ADJ_RANS :

                if (!DualTime_Iteration) {
                    ConvHist_file[0] << begin << adjoint_coeff << adj_flow_resid;
                    if (!config[val_iZone]->GetFrozen_Visc())
                        ConvHist_file[0] << adj_turb_resid;
                    ConvHist_file[0] << end;
                    ConvHist_file[0].flush();
                }

                cout.precision(6);
                cout.setf(ios::fixed,ios::floatfield);
                cout.width(17); cout << log10(residual_adjflow[0]);
                if (!config[val_iZone]->GetFrozen_Visc()) {
                    cout.width(17); cout << log10(residual_adjturbulent[0]);
                }
                else {
                    if (compressible) {
                        if (geometry[val_iZone][FinestMesh]->GetnDim() == 2 ) { cout.width(15); cout << log10(residual_adjflow[3]); }
                        else { cout.width(15); cout << log10(residual_adjflow[4]); }
                    }
                    if (incompressible || freesurface) {
                        cout.width(15); cout << log10(residual_adjflow[1]);
                    }
                }
                cout.precision(4);
                cout.setf(ios::scientific,ios::floatfield);
                cout.width(14); cout << Total_Sens_Geo;
                cout.width(14); cout << Total_Sens_Mach;
                cout << endl;
                cout.unsetf(ios_base::floatfield);
                if (freesurface) {
                    if (!DualTime_Iteration) {
                        ConvHist_file[0] << begin << adjoint_coeff << adj_flow_resid << adj_levelset_resid;
                        ConvHist_file[0] << end;
                        ConvHist_file[0].flush();
                    }

                    cout.precision(6);
                    cout.setf(ios::fixed,ios::floatfield);
                    cout.width(17); cout << log10(residual_adjflow[0]);
                    cout.width(16); cout << log10(residual_adjlevelset[0]);

                    cout.precision(4);
                    cout.setf(ios::scientific,ios::floatfield);
                    cout.width(12); cout << Total_Sens_Geo;
                    cout.width(12); cout << Total_Sens_Mach;
                    cout << endl;
                    cout.unsetf(ios_base::floatfield);
                }

                break;

            }
            cout.unsetf(ios::fixed);

            delete [] residual_flow;
            delete [] residual_turbulent;
            delete [] residual_transition;
            delete [] residual_levelset;
            delete [] residual_wave;
            delete [] residual_fea;
            delete [] residual_heat;

            delete [] residual_adjflow;
            delete [] residual_adjturbulent;
            delete [] residual_adjlevelset;

            delete [] Surface_CLift;
            delete [] Surface_CDrag;
            delete [] Surface_CSideForce;
            delete [] Surface_CEff;
            delete [] Surface_CFx;
            delete [] Surface_CFy;
            delete [] Surface_CFz;
            delete [] Surface_CMx;
            delete [] Surface_CMy;
            delete [] Surface_CMz;
            delete [] aeroelastic_pitch;
            delete [] aeroelastic_plunge;
        }
    }
}

void COutput::SetCFL_Number(CSolver ****solver_container, CConfig **config, unsigned short val_iZone) {

    double CFLFactor, power, CFL, CFLMin, CFLMax, Div, Diff, MGFactor[100];
    unsigned short iMesh;

    int rank = MASTER_NODE;

#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif

    unsigned short FinestMesh = config[val_iZone]->GetFinestMesh();
    bool flow = ((config[val_iZone]->GetKind_Solver() == EULER) || (config[val_iZone]->GetKind_Solver() == NAVIER_STOKES) ||
                 (config[val_iZone]->GetKind_Solver() == RANS));
    unsigned long ExtIter = config[val_iZone]->GetExtIter();

    /*--- Output the mean flow solution using only the master node ---*/

    if ((rank == MASTER_NODE) && (flow)) {

        RhoRes_New = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetRes_RMS(0);
        if (RhoRes_Old < EPS) RhoRes_Old = RhoRes_New;

        Div = RhoRes_Old/RhoRes_New;
        Diff = RhoRes_New-RhoRes_Old;

        /*--- Compute MG factor ---*/

        MGFactor[MESH_0] = 1.0;
        for (iMesh = 1; iMesh <= config[val_iZone]->GetnMGLevels(); iMesh++) {
            MGFactor[iMesh] = MGFactor[iMesh-1] * config[val_iZone]->GetCFL(iMesh)/config[val_iZone]->GetCFL(iMesh-1);
        }

        if (Div < 1.0) power = config[val_iZone]->GetCFL_AdaptParam(0);
        else power = config[val_iZone]->GetCFL_AdaptParam(1);

        /*--- Detect a stall in the residual ---*/

        if ((fabs(Diff) <= RhoRes_New*1E-8) && (ExtIter != 0)) { Div = 0.1; power = config[val_iZone]->GetCFL_AdaptParam(1); }

        CFLMin = config[val_iZone]->GetCFL_AdaptParam(2);
        CFLMax = config[val_iZone]->GetCFL_AdaptParam(3);

        CFLFactor = pow(Div, power);

        for (iMesh = 0; iMesh <= config[val_iZone]->GetnMGLevels(); iMesh++) {
            CFL = config[val_iZone]->GetCFL(iMesh);
            CFL *= CFLFactor;

            if ((iMesh == MESH_0) && (CFL <= CFLMin)) {
                for (iMesh = 0; iMesh <= config[val_iZone]->GetnMGLevels(); iMesh++) {
                    config[val_iZone]->SetCFL(iMesh, 1.001*CFLMin*MGFactor[iMesh]);
                }
                break;
            }
            if ((iMesh == MESH_0) && (CFL >= CFLMax)) {
                for (iMesh = 0; iMesh <= config[val_iZone]->GetnMGLevels(); iMesh++)
                    config[val_iZone]->SetCFL(iMesh, 0.999*CFLMax*MGFactor[iMesh]);
                break;
            }

            config[val_iZone]->SetCFL(iMesh, CFL);

        }

        RhoRes_Old = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetRes_RMS(0);

    }


}


void COutput::SetForces_Breakdown(CGeometry ***geometry,
                                  CSolver ****solver_container,
                                  CConfig **config,
                                  CIntegration ***integration,
                                  unsigned short val_iZone) {

    char cstr[200];
    unsigned short iMarker_Monitoring;
    ofstream Breakdown_file;

    int rank = MASTER_NODE;
    bool compressible       = (config[val_iZone]->GetKind_Regime() == COMPRESSIBLE);
    bool incompressible     = (config[val_iZone]->GetKind_Regime() == INCOMPRESSIBLE);
    bool freesurface        = (config[val_iZone]->GetKind_Regime() == FREESURFACE);
    bool unsteady           = (config[val_iZone]->GetUnsteady_Simulation() != NO);
    bool viscous            = config[val_iZone]->GetViscous();
    bool grid_movement      = config[val_iZone]->GetGrid_Movement();
    bool gravity            = config[val_iZone]->GetGravityForce();
    bool turbulent          = config[val_iZone]->GetKind_Solver() == RANS;

#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif

    unsigned short FinestMesh = config[val_iZone]->GetFinestMesh();
    unsigned short nDim = geometry[val_iZone][FinestMesh]->GetnDim();
    bool flow = ((config[val_iZone]->GetKind_Solver() == EULER) || (config[val_iZone]->GetKind_Solver() == NAVIER_STOKES) ||
                 (config[val_iZone]->GetKind_Solver() == RANS));

    /*--- Output the mean flow solution using only the master node ---*/

    if ((rank == MASTER_NODE) && (flow)) {

        cout << "Writing the forces breakdown file." << endl;

        /*--- Initialize variables to store information from all domains (direct solution) ---*/

        double Total_CLift = 0.0, Total_CDrag = 0.0, Total_CSideForce = 0.0, Total_CMx = 0.0, Total_CMy = 0.0, Total_CMz = 0.0, Total_CEff = 0.0, Total_CFx = 0.0, Total_CFy = 0.0, Total_CFz = 0.0,
                Inv_CLift = 0.0, Inv_CDrag = 0.0, Inv_CSideForce = 0.0, Inv_CMx = 0.0, Inv_CMy = 0.0, Inv_CMz = 0.0, Inv_CEff = 0.0, Inv_CFx = 0.0, Inv_CFy = 0.0, Inv_CFz = 0.0,
                *Surface_CLift = NULL, *Surface_CDrag = NULL, *Surface_CSideForce = NULL, *Surface_CEff = NULL, *Surface_CFx = NULL, *Surface_CFy = NULL,  *Surface_CFz = NULL, *Surface_CMx = NULL, *Surface_CMy = NULL, *Surface_CMz = NULL,
                *Surface_CLift_Inv = NULL, *Surface_CDrag_Inv = NULL, *Surface_CSideForce_Inv = NULL, *Surface_CEff_Inv = NULL, *Surface_CFx_Inv = NULL, *Surface_CFy_Inv = NULL,  *Surface_CFz_Inv = NULL, *Surface_CMx_Inv = NULL, *Surface_CMy_Inv = NULL, *Surface_CMz_Inv = NULL;
        time_t now = time(0);
        string dt = ctime(&now); dt[24] = '.';

        /*--- Allocate memory for the coefficients being monitored ---*/

        Surface_CLift      = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CDrag      = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CSideForce = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CEff       = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CFx        = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CFy        = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CFz        = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CMx        = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CMy        = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CMz        = new double[config[ZONE_0]->GetnMarker_Monitoring()];

        Surface_CLift_Inv      = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CDrag_Inv      = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CSideForce_Inv = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CEff_Inv       = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CFx_Inv        = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CFy_Inv        = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CFz_Inv        = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CMx_Inv        = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CMy_Inv        = new double[config[ZONE_0]->GetnMarker_Monitoring()];
        Surface_CMz_Inv        = new double[config[ZONE_0]->GetnMarker_Monitoring()];

        /*--- Flow solution coefficients ---*/

        Total_CLift       = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CLift();
        Total_CDrag       = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CDrag();
        Total_CSideForce  = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CSideForce();
        Total_CEff        = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CEff();
        Total_CMx         = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CMx();
        Total_CMy         = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CMy();
        Total_CMz         = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CMz();
        Total_CFx         = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CFx();
        Total_CFy         = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CFy();
        Total_CFz         = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetTotal_CFz();

        /*--- Flow inviscid solution coefficients ---*/

        Inv_CLift       = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetAllBound_CLift_Inv();
        Inv_CDrag       = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetAllBound_CDrag_Inv();
        Inv_CSideForce  = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetAllBound_CSideForce_Inv();
        Inv_CEff        = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetAllBound_CEff_Inv();
        Inv_CMx         = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetAllBound_CMx_Inv();
        Inv_CMy         = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetAllBound_CMy_Inv();
        Inv_CMz         = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetAllBound_CMz_Inv();
        Inv_CFx         = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetAllBound_CFx_Inv();
        Inv_CFy         = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetAllBound_CFy_Inv();
        Inv_CFz         = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetAllBound_CFz_Inv();

        /*--- Look over the markers being monitored and get the desired values ---*/

        for (iMarker_Monitoring = 0; iMarker_Monitoring < config[ZONE_0]->GetnMarker_Monitoring(); iMarker_Monitoring++) {
            Surface_CLift[iMarker_Monitoring]      = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CLift(iMarker_Monitoring);
            Surface_CDrag[iMarker_Monitoring]      = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CDrag(iMarker_Monitoring);
            Surface_CSideForce[iMarker_Monitoring] = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CSideForce(iMarker_Monitoring);
            Surface_CEff[iMarker_Monitoring]       = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CEff(iMarker_Monitoring);
            Surface_CFx[iMarker_Monitoring]        = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CFx(iMarker_Monitoring);
            Surface_CFy[iMarker_Monitoring]        = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CFy(iMarker_Monitoring);
            Surface_CFz[iMarker_Monitoring]        = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CFz(iMarker_Monitoring);
            Surface_CMx[iMarker_Monitoring]        = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CMx(iMarker_Monitoring);
            Surface_CMy[iMarker_Monitoring]        = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CMy(iMarker_Monitoring);
            Surface_CMz[iMarker_Monitoring]        = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CMz(iMarker_Monitoring);

            Surface_CLift_Inv[iMarker_Monitoring]      = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CLift_Inv(iMarker_Monitoring);
            Surface_CDrag_Inv[iMarker_Monitoring]      = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CDrag_Inv(iMarker_Monitoring);
            Surface_CSideForce_Inv[iMarker_Monitoring] = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CSideForce_Inv(iMarker_Monitoring);
            Surface_CEff_Inv[iMarker_Monitoring]       = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CEff_Inv(iMarker_Monitoring);
            Surface_CFx_Inv[iMarker_Monitoring]        = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CFx_Inv(iMarker_Monitoring);
            Surface_CFy_Inv[iMarker_Monitoring]        = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CFy_Inv(iMarker_Monitoring);
            Surface_CFz_Inv[iMarker_Monitoring]        = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CFz_Inv(iMarker_Monitoring);
            Surface_CMx_Inv[iMarker_Monitoring]        = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CMx_Inv(iMarker_Monitoring);
            Surface_CMy_Inv[iMarker_Monitoring]        = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CMy_Inv(iMarker_Monitoring);
            Surface_CMz_Inv[iMarker_Monitoring]        = solver_container[val_iZone][FinestMesh][FLOW_SOL]->GetSurface_CMz_Inv(iMarker_Monitoring);
        }

        /*--- Write file name with extension ---*/

        string filename = config[val_iZone]->GetBreakdown_FileName();
        strcpy (cstr, filename.data());

        Breakdown_file.open(cstr, ios::out);

        Breakdown_file << endl <<"-------------------------------------------------------------------------" << endl;
        Breakdown_file <<"|    ___ _   _ ___                                                      |" << endl;
        Breakdown_file <<"|   / __| | | |_  )   Release 3.2.8 \"eagle\"                             |" << endl;
        Breakdown_file <<"|   \\__ \\ |_| |/ /                                                      |" << endl;
        Breakdown_file <<"|   |___/\\___//___|   Suite (Computational Fluid Dynamics Code)         |" << endl;
        Breakdown_file << "|                                                                       |" << endl;
        Breakdown_file << "|   Local date and time: " << dt << "                      |" << endl;
        Breakdown_file <<"-------------------------------------------------------------------------" << endl;
        Breakdown_file << "| SU2 Lead Developers: Dr. Francisco Palacios (fpalacios@stanford.edu). |" << endl;
        Breakdown_file << "|                      Dr. Thomas D. Economon (economon@stanford.edu).  |" << endl;
        Breakdown_file <<"-------------------------------------------------------------------------" << endl;
        Breakdown_file << "| SU2 Developers:                                                       |" << endl;
        Breakdown_file << "| - Prof. Juan J. Alonso's group at Stanford University.                |" << endl;
        Breakdown_file << "| - Prof. Piero Colonna's group at Delft University of Technology.      |" << endl;
        Breakdown_file << "| - Prof. Nicolas R. Gauger's group at Kaiserslautern U. of Technology. |" << endl;
        Breakdown_file << "| - Prof. Alberto Guardone's group at Polytechnic University of Milan.  |" << endl;
        Breakdown_file << "| - Prof. Rafael Palacios' group at Imperial College London.            |" << endl;
        Breakdown_file <<"-------------------------------------------------------------------------" << endl;
        Breakdown_file << "| Copyright (C) 2012-2015 SU2, the open-source CFD code.                |" << endl;
        Breakdown_file << "|                                                                       |" << endl;
        Breakdown_file << "| SU2 is free software; you can redistribute it and/or                  |" << endl;
        Breakdown_file << "| modify it under the terms of the GNU Lesser General Public            |" << endl;
        Breakdown_file << "| License as published by the Free Software Foundation; either          |" << endl;
        Breakdown_file << "| version 2.1 of the License, or (at your option) any later version.    |" << endl;
        Breakdown_file << "|                                                                       |" << endl;
        Breakdown_file << "| SU2 is distributed in the hope that it will be useful,                |" << endl;
        Breakdown_file << "| but WITHOUT ANY WARRANTY; without even the implied warranty of        |" << endl;
        Breakdown_file << "| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU      |" << endl;
        Breakdown_file << "| Lesser General Public License for more details.                       |" << endl;
        Breakdown_file << "|                                                                       |" << endl;
        Breakdown_file << "| You should have received a copy of the GNU Lesser General Public      |" << endl;
        Breakdown_file << "| License along with SU2. If not, see <http://www.gnu.org/licenses/>.   |" << endl;
        Breakdown_file <<"-------------------------------------------------------------------------" << endl;

        Breakdown_file.precision(6);

        Breakdown_file << endl << endl <<"Problem definition:" << endl << endl;

        if (compressible) {
            if (viscous) {
                Breakdown_file << "Viscous flow: Computing pressure using the ideal gas law" << endl;
                Breakdown_file << "based on the free-stream temperature and a density computed" << endl;
                Breakdown_file << "from the Reynolds number." << endl;
            } else {
                Breakdown_file << "Inviscid flow: Computing density based on free-stream" << endl;
                Breakdown_file << "temperature and pressure using the ideal gas law." << endl;
            }
        }

        if (grid_movement) Breakdown_file << "Force coefficients computed using MACH_MOTION." << endl;
        else Breakdown_file << "Force coefficients computed using free-stream values." << endl;

        if (incompressible || freesurface) {
            Breakdown_file << "Viscous and Inviscid flow: rho_ref, and vel_ref" << endl;
            Breakdown_file << "are based on the free-stream values, p_ref = rho_ref*vel_ref^2." << endl;
            Breakdown_file << "The free-stream value of the pressure is 0." << endl;
            Breakdown_file << "Mach number: "<< config[val_iZone]->GetMach() << ", computed using the Bulk modulus." << endl;
            Breakdown_file << "Angle of attack (deg): "<< config[val_iZone]->GetAoA() << ", computed using the the free-stream velocity." << endl;
            Breakdown_file << "Side slip angle (deg): "<< config[val_iZone]->GetAoS() << ", computed using the the free-stream velocity." << endl;
            if (viscous) Breakdown_file << "Reynolds number: " << config[val_iZone]->GetReynolds() << ", computed using free-stream values."<< endl;
            Breakdown_file << "Only dimensional computation, the grid should be dimensional." << endl;
        }

        Breakdown_file <<"-- Input conditions:"<< endl;

        if (compressible) {
            switch (config[val_iZone]->GetKind_FluidModel()) {

            case STANDARD_AIR:
                Breakdown_file << "Fluid Model: STANDARD_AIR "<< endl;
                Breakdown_file << "Specific gas constant: " << config[val_iZone]->GetGas_Constant();
                if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " N.m/kg.K." << endl;
                else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " lbf.ft/slug.R." << endl;
                Breakdown_file << "Specific gas constant (non-dim): " << config[val_iZone]->GetGas_ConstantND()<< endl;
                Breakdown_file << "Specific Heat Ratio: 1.4000 "<< endl;
                break;

            case IDEAL_GAS:
                Breakdown_file << "Fluid Model: IDEAL_GAS "<< endl;
                Breakdown_file << "Specific gas constant: " << config[val_iZone]->GetGas_Constant() << " N.m/kg.K." << endl;
                Breakdown_file << "Specific gas constant (non-dim): " << config[val_iZone]->GetGas_ConstantND()<< endl;
                Breakdown_file << "Specific Heat Ratio: "<< config[val_iZone]->GetGamma() << endl;
                break;

            case VW_GAS:
                Breakdown_file << "Fluid Model: Van der Waals "<< endl;
                Breakdown_file << "Specific gas constant: " << config[val_iZone]->GetGas_Constant() << " N.m/kg.K." << endl;
                Breakdown_file << "Specific gas constant (non-dim): " << config[val_iZone]->GetGas_ConstantND()<< endl;
                Breakdown_file << "Specific Heat Ratio: "<< config[val_iZone]->GetGamma() << endl;
                Breakdown_file << "Critical Pressure:   " << config[val_iZone]->GetPressure_Critical()  << " Pa." << endl;
                Breakdown_file << "Critical Temperature:  " << config[val_iZone]->GetTemperature_Critical() << " K." << endl;
                Breakdown_file << "Critical Pressure (non-dim):   " << config[val_iZone]->GetPressure_Critical() /config[val_iZone]->GetPressure_Ref() << endl;
                Breakdown_file << "Critical Temperature (non-dim) :  " << config[val_iZone]->GetTemperature_Critical() /config[val_iZone]->GetTemperature_Ref() << endl;
                break;

            case PR_GAS:
                Breakdown_file << "Fluid Model: Peng-Robinson "<< endl;
                Breakdown_file << "Specific gas constant: " << config[val_iZone]->GetGas_Constant() << " N.m/kg.K." << endl;
                Breakdown_file << "Specific gas constant(non-dim): " << config[val_iZone]->GetGas_ConstantND()<< endl;
                Breakdown_file << "Specific Heat Ratio: "<< config[val_iZone]->GetGamma() << endl;
                Breakdown_file << "Critical Pressure:   " << config[val_iZone]->GetPressure_Critical()  << " Pa." << endl;
                Breakdown_file << "Critical Temperature:  " << config[val_iZone]->GetTemperature_Critical() << " K." << endl;
                Breakdown_file << "Critical Pressure (non-dim):   " << config[val_iZone]->GetPressure_Critical() /config[val_iZone]->GetPressure_Ref() << endl;
                Breakdown_file << "Critical Temperature (non-dim) :  " << config[val_iZone]->GetTemperature_Critical() /config[val_iZone]->GetTemperature_Ref() << endl;
                break;
            }

            if(viscous){

                switch (config[val_iZone]->GetKind_ViscosityModel()) {

                case CONSTANT_VISCOSITY:
                    Breakdown_file << "Viscosity Model: CONSTANT_VISCOSITY  "<< endl;
                    Breakdown_file << "Laminar Viscosity: " << config[val_iZone]->GetMu_ConstantND()*config[val_iZone]->GetViscosity_Ref();
                    if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " N.s/m^2." << endl;
                    else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " lbf.s/ft^2." << endl;
                    Breakdown_file << "Laminar Viscosity (non-dim): " << config[val_iZone]->GetMu_ConstantND()<< endl;
                    break;

                case SUTHERLAND:
                    Breakdown_file << "Viscosity Model: SUTHERLAND "<< endl;
                    Breakdown_file << "Ref. Laminar Viscosity: " << config[val_iZone]->GetMu_RefND()*config[val_iZone]->GetViscosity_Ref();
                    if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " N.s/m^2." << endl;
                    else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " lbf.s/ft^2." << endl;
                    Breakdown_file << "Ref. Temperature: " << config[val_iZone]->GetMu_Temperature_RefND()*config[val_iZone]->GetTemperature_Ref();
                    if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " K." << endl;
                    else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " R." << endl;
                    Breakdown_file << "Sutherland Constant: "<< config[val_iZone]->GetMu_SND()*config[val_iZone]->GetTemperature_Ref();
                    if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " K." << endl;
                    else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " R." << endl;
                    Breakdown_file << "Laminar Viscosity (non-dim): " << config[val_iZone]->GetMu_ConstantND()<< endl;
                    Breakdown_file << "Ref. Temperature (non-dim): " << config[val_iZone]->GetMu_Temperature_RefND()<< endl;
                    Breakdown_file << "Sutherland constant (non-dim): "<< config[val_iZone]->GetMu_SND()<< endl;
                    break;

                }
                switch (config[val_iZone]->GetKind_ConductivityModel()) {

                case CONSTANT_PRANDTL:
                    Breakdown_file << "Conductivity Model: CONSTANT_PRANDTL  "<< endl;
                    Breakdown_file << "Prandtl: " << config[val_iZone]->GetPrandtl_Lam()<< endl;
                    break;

                case CONSTANT_CONDUCTIVITY:
                    Breakdown_file << "Conductivity Model: CONSTANT_CONDUCTIVITY "<< endl;
                    Breakdown_file << "Molecular Conductivity: " << config[val_iZone]->GetKt_ConstantND()*config[val_iZone]->GetConductivity_Ref()<< " W/m^2.K." << endl;
                    Breakdown_file << "Molecular Conductivity (non-dim): " << config[val_iZone]->GetKt_ConstantND()<< endl;
                    break;

                }
            }
        }

        if (incompressible || freesurface) {
            Breakdown_file << "Bulk modulus: " << config[val_iZone]->GetBulk_Modulus();
            if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " Pa." << endl;
            else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " psf." << endl;
            Breakdown_file << "Artificial compressibility factor: " << config[val_iZone]->GetArtComp_Factor();
            if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " Pa." << endl;
            else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " psf." << endl;
        }

        Breakdown_file << "Free-stream pressure: " << config[val_iZone]->GetPressure_FreeStream();
        if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " Pa." << endl;
        else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " psf." << endl;

        if (compressible) {
            Breakdown_file << "Free-stream temperature: " << config[val_iZone]->GetTemperature_FreeStream();
            if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " K." << endl;
            else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " R." << endl;
        }

        Breakdown_file << "Free-stream density: " << config[val_iZone]->GetDensity_FreeStream();
        if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " kg/m^3." << endl;
        else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " slug/ft^3." << endl;

        if (nDim == 2) {
            Breakdown_file << "Free-stream velocity: (" << config[val_iZone]->GetVelocity_FreeStream()[0] << ", ";
            Breakdown_file << config[val_iZone]->GetVelocity_FreeStream()[1] << ")";
        }
        if (nDim == 3) {
            Breakdown_file << "Free-stream velocity: (" << config[val_iZone]->GetVelocity_FreeStream()[0] << ", ";
            Breakdown_file << config[val_iZone]->GetVelocity_FreeStream()[1] << ", " << config[val_iZone]->GetVelocity_FreeStream()[2] << ")";
        }
        if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " m/s. ";
        else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " ft/s. ";

        Breakdown_file << "Magnitude: "	<< config[val_iZone]->GetModVel_FreeStream();
        if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " m/s." << endl;
        else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " ft/s." << endl;

        if (compressible) {
            Breakdown_file << "Free-stream total energy per unit mass: " << config[val_iZone]->GetEnergy_FreeStream();
            if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " m^2/s^2." << endl;
            else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " ft^2/s^2." << endl;
        }

        if (viscous) {
            Breakdown_file << "Free-stream viscosity: " << config[val_iZone]->GetViscosity_FreeStream();
            if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " N.s/m^2." << endl;
            else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " lbf.s/ft^2." << endl;
            if (turbulent){
                Breakdown_file << "Free-stream turb. kinetic energy per unit mass: " << config[val_iZone]->GetTke_FreeStream();
                if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " m^2/s^2." << endl;
                else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " ft^2/s^2." << endl;
                Breakdown_file << "Free-stream specific dissipation: " << config[val_iZone]->GetOmega_FreeStream();
                if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " 1/s." << endl;
                else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " 1/s." << endl;
            }
        }

        if (unsteady) { Breakdown_file << "Total time: " << config[val_iZone]->GetTotal_UnstTime() << " s. Time step: " << config[val_iZone]->GetDelta_UnstTime() << " s." << endl; }

        /*--- Print out reference values. ---*/

        Breakdown_file <<"-- Reference values:"<< endl;

        if (compressible) {
            Breakdown_file << "Reference specific gas constant: " << config[val_iZone]->GetGas_Constant_Ref();
            if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " N.m/kg.K." << endl;
            else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " lbf.ft/slug.R." << endl;
        }

        Breakdown_file << "Reference pressure: " << config[val_iZone]->GetPressure_Ref();
        if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " Pa." << endl;
        else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " psf." << endl;

        if (compressible) {
            Breakdown_file << "Reference temperature: " << config[val_iZone]->GetTemperature_Ref();
            if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " K." << endl;
            else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " R." << endl;
        }

        Breakdown_file << "Reference density: " << config[val_iZone]->GetDensity_Ref();
        if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " kg/m^3." << endl;
        else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " slug/ft^3." << endl;

        Breakdown_file << "Reference velocity: " << config[val_iZone]->GetVelocity_Ref();
        if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " m/s." << endl;
        else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " ft/s." << endl;

        if (compressible) {
            Breakdown_file << "Reference energy per unit mass: " << config[val_iZone]->GetEnergy_Ref();
            if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " m^2/s^2." << endl;
            else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " ft^2/s^2." << endl;
        }

        if (incompressible || freesurface) {
            Breakdown_file << "Reference length: " << config[val_iZone]->GetLength_Ref();
            if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " m." << endl;
            else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " in." << endl;
        }

        if (viscous) {
            Breakdown_file << "Reference viscosity: " << config[val_iZone]->GetViscosity_Ref();
            if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " N.s/m^2." << endl;
            else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " lbf.s/ft^2." << endl;
            Breakdown_file << "Reference conductivity: " << config[val_iZone]->GetConductivity_Ref();
            if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " W/m^2.K." << endl;
            else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " lbf/ft.s.R." << endl;
        }


        if (unsteady) Breakdown_file << "Reference time: " << config[val_iZone]->GetTime_Ref() <<" s." << endl;

        /*--- Print out resulting non-dim values here. ---*/

        Breakdown_file << "-- Resulting non-dimensional state:" << endl;
        Breakdown_file << "Mach number (non-dim): " << config[val_iZone]->GetMach() << endl;
        if (viscous) {
            Breakdown_file << "Reynolds number (non-dim): " << config[val_iZone]->GetReynolds() <<". Re length: " << config[val_iZone]->GetLength_Reynolds();
            if (config[val_iZone]->GetSystemMeasurements() == SI) Breakdown_file << " m." << endl;
            else if (config[val_iZone]->GetSystemMeasurements() == US) Breakdown_file << " ft." << endl;
        }
        if (gravity) {
            Breakdown_file << "Froude number (non-dim): " << config[val_iZone]->GetFroude() << endl;
            Breakdown_file << "Lenght of the baseline wave (non-dim): " << 2.0*PI_NUMBER*config[val_iZone]->GetFroude()*config[val_iZone]->GetFroude() << endl;
        }

        if (compressible) {
            Breakdown_file << "Specific gas constant (non-dim): " << config[val_iZone]->GetGas_ConstantND() << endl;
            Breakdown_file << "Free-stream temperature (non-dim): " << config[val_iZone]->GetTemperature_FreeStreamND() << endl;
        }

        Breakdown_file << "Free-stream pressure (non-dim): " << config[val_iZone]->GetPressure_FreeStreamND() << endl;

        Breakdown_file << "Free-stream density (non-dim): " << config[val_iZone]->GetDensity_FreeStreamND() << endl;

        if (nDim == 2) {
            Breakdown_file << "Free-stream velocity (non-dim): (" << config[val_iZone]->GetVelocity_FreeStreamND()[0] << ", ";
            Breakdown_file << config[val_iZone]->GetVelocity_FreeStreamND()[1] << "). ";
        } else {
            Breakdown_file << "Free-stream velocity (non-dim): (" << config[val_iZone]->GetVelocity_FreeStreamND()[0] << ", ";
            Breakdown_file << config[val_iZone]->GetVelocity_FreeStreamND()[1] << ", " << config[val_iZone]->GetVelocity_FreeStreamND()[2] << "). ";
        }
        Breakdown_file << "Magnitude: "	 << config[val_iZone]->GetModVel_FreeStreamND() << endl;

        if (compressible)
            Breakdown_file << "Free-stream total energy per unit mass (non-dim): " << config[val_iZone]->GetEnergy_FreeStreamND() << endl;

        if (viscous) {
            Breakdown_file << "Free-stream viscosity (non-dim): " << config[val_iZone]->GetViscosity_FreeStreamND() << endl;
            if (turbulent){
                Breakdown_file << "Free-stream turb. kinetic energy (non-dim): " << config[val_iZone]->GetTke_FreeStreamND() << endl;
                Breakdown_file << "Free-stream specific dissipation (non-dim): " << config[val_iZone]->GetOmega_FreeStreamND() << endl;
            }
        }

        if (unsteady) {
            Breakdown_file << "Total time (non-dim): " << config[val_iZone]->GetTotal_UnstTimeND() << endl;
            Breakdown_file << "Time step (non-dim): " << config[val_iZone]->GetDelta_UnstTimeND() << endl;
        }

        Breakdown_file << endl << endl <<"Forces breakdown:" << endl << endl;

        Breakdown_file << "Total CL:    ";
        Breakdown_file.width(11); Breakdown_file << Total_CLift;
        Breakdown_file << " | Pressure Component (";
        Breakdown_file.width(5); Breakdown_file << int((Inv_CLift*100.0)/(Total_CLift+EPS));
        Breakdown_file << "%): ";
        Breakdown_file.width(11); Breakdown_file << Inv_CLift;
        Breakdown_file << " | Friction Component (";
        Breakdown_file.width(5); Breakdown_file << int(100.0-(Inv_CLift*100.0)/(Total_CLift+EPS));
        Breakdown_file << "%): ";
        Breakdown_file.width(11); Breakdown_file << Total_CLift-Inv_CLift << endl;

        Breakdown_file << "Total CD:    ";
        Breakdown_file.width(11); Breakdown_file << Total_CDrag;
        Breakdown_file << " | Pressure Component (";
        Breakdown_file.width(5); Breakdown_file << int((Inv_CDrag*100.0)/(Total_CDrag+EPS)) << "%): ";;
        Breakdown_file.width(11); Breakdown_file << Inv_CDrag;
        Breakdown_file << " | Friction Component (";
        Breakdown_file.width(5); Breakdown_file << int(100.0-(Inv_CDrag*100.0)/(Total_CDrag+EPS));
        Breakdown_file << "%): ";
        Breakdown_file.width(11); Breakdown_file << Total_CDrag-Inv_CDrag << endl;

        if (nDim == 3) {
            Breakdown_file << "Total CSF:   ";
            Breakdown_file.width(11); Breakdown_file << Total_CSideForce;
            Breakdown_file << " | Pressure Component (";
            Breakdown_file.width(5); Breakdown_file << int((Inv_CSideForce*100.0)/(Total_CSideForce+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Inv_CSideForce;
            Breakdown_file << " | Friction Component (";
            Breakdown_file.width(5); Breakdown_file << int(100.0-(Inv_CSideForce*100.0)/(Total_CSideForce+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Total_CSideForce-Inv_CSideForce << endl;
        }

        Breakdown_file << "Total CL/CD: ";
        Breakdown_file.width(11); Breakdown_file << Total_CEff;
        Breakdown_file << " | Pressure Component (";
        Breakdown_file.width(5); Breakdown_file << int((Inv_CEff*100.0)/(Total_CEff+EPS));
        Breakdown_file << "%): ";
        Breakdown_file.width(11); Breakdown_file << Inv_CEff;
        Breakdown_file << " | Friction Component (";
        Breakdown_file.width(5); Breakdown_file << int(100.0-(Inv_CEff*100.0)/(Total_CEff+EPS));
        Breakdown_file << "%): ";
        Breakdown_file.width(11); Breakdown_file << Total_CEff-Inv_CEff << endl;

        if (nDim == 3) {
            Breakdown_file << "Total CMx:   ";
            Breakdown_file.width(11); Breakdown_file << Total_CMx;
            Breakdown_file << " | Pressure Component (";
            Breakdown_file.width(5); Breakdown_file << int((Inv_CMx*100.0)/(Total_CMx+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Inv_CMx;
            Breakdown_file << " | Friction Component (";
            Breakdown_file.width(5); Breakdown_file << int(100.0-(Inv_CMx*100.0)/(Total_CMx+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Total_CMx-Inv_CMx << endl;

            Breakdown_file << "Total CMy:   ";
            Breakdown_file.width(11); Breakdown_file << Total_CMy;
            Breakdown_file << " | Pressure Component (";
            Breakdown_file.width(5); Breakdown_file << int((Inv_CMy*100.0)/(Total_CMy+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Inv_CMy;
            Breakdown_file << " | Friction Component (";
            Breakdown_file.width(5); Breakdown_file << int(100.0-(Inv_CMy*100.0)/(Total_CMy+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Total_CMy-Inv_CMy << endl;
        }

        Breakdown_file << "Total CMz:   ";
        Breakdown_file.width(11); Breakdown_file << Total_CMz;
        Breakdown_file << " | Pressure Component (";
        Breakdown_file.width(5); Breakdown_file << int((Inv_CMz*100.0)/(Total_CMz+EPS));
        Breakdown_file << "%): ";
        Breakdown_file.width(11); Breakdown_file << Inv_CMz;
        Breakdown_file << " | Friction Component (";
        Breakdown_file.width(5); Breakdown_file << int(100.0-(Inv_CMz*100.0)/(Total_CMz+EPS));
        Breakdown_file << "%): ";
        Breakdown_file.width(11); Breakdown_file << Total_CMz-Inv_CMz << endl;

        Breakdown_file << "Total CFx:   ";
        Breakdown_file.width(11); Breakdown_file << Total_CFx;
        Breakdown_file << " | Pressure Component (";
        Breakdown_file.width(5); Breakdown_file << int((Inv_CFx*100.0)/(Total_CFx+EPS));
        Breakdown_file << "%): ";
        Breakdown_file.width(11); Breakdown_file << Inv_CFx;
        Breakdown_file << " | Friction Component (";
        Breakdown_file.width(5); Breakdown_file << int(100.0-(Inv_CFx*100.0)/(Total_CFx+EPS));
        Breakdown_file << "%): ";
        Breakdown_file.width(11); Breakdown_file << Total_CFx-Inv_CFx << endl;

        Breakdown_file << "Total CFy:   ";
        Breakdown_file.width(11); Breakdown_file << Total_CFy;
        Breakdown_file << " | Pressure Component (";
        Breakdown_file.width(5); Breakdown_file << int((Inv_CFy*100.0)/(Total_CFy+EPS));
        Breakdown_file << "%): ";
        Breakdown_file.width(11); Breakdown_file << Inv_CFy;
        Breakdown_file << " | Friction Component (";
        Breakdown_file.width(5); Breakdown_file << int(100.0-(Inv_CFy*100.0)/(Total_CFy+EPS));
        Breakdown_file << "%): ";
        Breakdown_file.width(11); Breakdown_file << Total_CFy-Inv_CFy << endl;

        if (nDim == 3) {
            Breakdown_file << "Total CFz:   ";
            Breakdown_file.width(11); Breakdown_file << Total_CFz;
            Breakdown_file << " | Pressure Component (";
            Breakdown_file.width(5); Breakdown_file << int((Inv_CFz*100.0)/(Total_CFz+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Inv_CFz;
            Breakdown_file << " | Friction Component (";
            Breakdown_file.width(5); Breakdown_file << int(100.0-(Inv_CFz*100.0)/(Total_CFz+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Total_CFz-Inv_CFz << endl;
        }

        Breakdown_file << endl << endl;

        for (iMarker_Monitoring = 0; iMarker_Monitoring < config[val_iZone]->GetnMarker_Monitoring(); iMarker_Monitoring++) {

            Breakdown_file << "Surface name: " << config[val_iZone]->GetMarker_Monitoring(iMarker_Monitoring) << endl << endl;

            Breakdown_file << "Total CL    (";
            Breakdown_file.width(5); Breakdown_file << int((Surface_CLift[iMarker_Monitoring]*100.0)/(Total_CLift+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Surface_CLift[iMarker_Monitoring];
            Breakdown_file << " | Pressure Component (";
            Breakdown_file.width(5); Breakdown_file << int((Surface_CLift_Inv[iMarker_Monitoring]*100.0)/(Surface_CLift[iMarker_Monitoring]+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Surface_CLift_Inv[iMarker_Monitoring];
            Breakdown_file << " | Friction Component (";
            Breakdown_file.width(5); Breakdown_file << int(100.0-(Surface_CLift_Inv[iMarker_Monitoring]*100.0)/(Surface_CLift[iMarker_Monitoring]+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Surface_CLift[iMarker_Monitoring]-Surface_CLift_Inv[iMarker_Monitoring] << endl;

            Breakdown_file << "Total CD    (";
            Breakdown_file.width(5); Breakdown_file << int((Surface_CDrag[iMarker_Monitoring]*100.0)/(Total_CDrag+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Surface_CDrag[iMarker_Monitoring];
            Breakdown_file << " | Pressure Component (";
            Breakdown_file.width(5); Breakdown_file << int((Surface_CDrag_Inv[iMarker_Monitoring]*100.0)/(Surface_CDrag[iMarker_Monitoring]+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Surface_CDrag_Inv[iMarker_Monitoring];
            Breakdown_file << " | Friction Component (";
            Breakdown_file.width(5); Breakdown_file << int(100.0-(Surface_CDrag_Inv[iMarker_Monitoring]*100.0)/(Surface_CDrag[iMarker_Monitoring]+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Surface_CDrag[iMarker_Monitoring]-Surface_CDrag_Inv[iMarker_Monitoring] << endl;

            if (nDim == 3) {
                Breakdown_file << "Total CSF   (";
                Breakdown_file.width(5); Breakdown_file << int((Surface_CSideForce[iMarker_Monitoring]*100.0)/(Total_CSideForce+EPS));
                Breakdown_file << "%): ";
                Breakdown_file.width(11); Breakdown_file << Surface_CSideForce[iMarker_Monitoring];
                Breakdown_file << " | Pressure Component (";
                Breakdown_file.width(5); Breakdown_file << int((Surface_CSideForce_Inv[iMarker_Monitoring]*100.0)/(Surface_CSideForce[iMarker_Monitoring]+EPS));
                Breakdown_file << "%): ";
                Breakdown_file.width(11); Breakdown_file << Surface_CSideForce_Inv[iMarker_Monitoring];
                Breakdown_file << " | Friction Component (";
                Breakdown_file.width(5); Breakdown_file << int(100.0-(Surface_CSideForce_Inv[iMarker_Monitoring]*100.0)/(Surface_CSideForce[iMarker_Monitoring]+EPS));
                Breakdown_file << "%): ";
                Breakdown_file.width(11); Breakdown_file << Surface_CSideForce[iMarker_Monitoring]-Surface_CSideForce_Inv[iMarker_Monitoring] << endl;
            }

            Breakdown_file << "Total CL/CD (";
            Breakdown_file.width(5); Breakdown_file << int((Surface_CEff[iMarker_Monitoring]*100.0)/(Total_CEff+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Surface_CEff[iMarker_Monitoring];
            Breakdown_file << " | Pressure Component (";
            Breakdown_file.width(5); Breakdown_file << int((Surface_CEff_Inv[iMarker_Monitoring]*100.0)/(Surface_CEff[iMarker_Monitoring]+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Surface_CEff_Inv[iMarker_Monitoring];
            Breakdown_file << " | Friction Component (";
            Breakdown_file.width(5); Breakdown_file << int(100.0-(Surface_CEff_Inv[iMarker_Monitoring]*100.0)/(Surface_CEff[iMarker_Monitoring]+EPS));
            Breakdown_file << "%): ";

            Breakdown_file.width(11); Breakdown_file << Surface_CEff[iMarker_Monitoring]-Surface_CEff_Inv[iMarker_Monitoring] << endl;

            if (nDim == 3) {

                Breakdown_file << "Total CMx   (";
                Breakdown_file.width(5); Breakdown_file << int((Surface_CMx[iMarker_Monitoring]*100.0)/(Total_CMx+EPS));
                Breakdown_file << "%): ";
                Breakdown_file.width(11); Breakdown_file << Surface_CMx[iMarker_Monitoring];
                Breakdown_file << " | Pressure Component (";
                Breakdown_file.width(5); Breakdown_file << int((Surface_CMx_Inv[iMarker_Monitoring]*100.0)/(Surface_CMx[iMarker_Monitoring]+EPS));
                Breakdown_file << "%): ";
                Breakdown_file.width(11); Breakdown_file << Surface_CMx_Inv[iMarker_Monitoring];
                Breakdown_file << " | Friction Component (";
                Breakdown_file.width(5); Breakdown_file << int(100.0-(Surface_CMx_Inv[iMarker_Monitoring]*100.0)/(Surface_CMx[iMarker_Monitoring]+EPS));
                Breakdown_file << "%): ";
                Breakdown_file.width(11); Breakdown_file << Surface_CMx[iMarker_Monitoring]-Surface_CMx_Inv[iMarker_Monitoring] << endl;

                Breakdown_file << "Total CMy   (";
                Breakdown_file.width(5); Breakdown_file << int((Surface_CMy[iMarker_Monitoring]*100.0)/(Total_CMy+EPS));
                Breakdown_file << "%): ";
                Breakdown_file.width(11); Breakdown_file << Surface_CMy[iMarker_Monitoring];
                Breakdown_file << " | Pressure Component (";
                Breakdown_file.width(5); Breakdown_file << int((Surface_CMy_Inv[iMarker_Monitoring]*100.0)/(Surface_CMy[iMarker_Monitoring]+EPS));
                Breakdown_file << "%): ";
                Breakdown_file.width(11); Breakdown_file << Surface_CMy_Inv[iMarker_Monitoring];
                Breakdown_file << " | Friction Component (";
                Breakdown_file.width(5); Breakdown_file << int(100.0-(Surface_CMy_Inv[iMarker_Monitoring]*100.0)/(Surface_CMy[iMarker_Monitoring]+EPS));
                Breakdown_file << "%): ";
                Breakdown_file.width(11); Breakdown_file << Surface_CMy[iMarker_Monitoring]-Surface_CMy_Inv[iMarker_Monitoring] << endl;
            }

            Breakdown_file << "Total CMz   (";
            Breakdown_file.width(5); Breakdown_file << int((Surface_CMz[iMarker_Monitoring]*100.0)/(Total_CMz+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Surface_CMz[iMarker_Monitoring];
            Breakdown_file << " | Pressure Component (";
            Breakdown_file.width(5); Breakdown_file << int((Surface_CMz_Inv[iMarker_Monitoring]*100.0)/(Surface_CMz[iMarker_Monitoring]+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Surface_CMz_Inv[iMarker_Monitoring];
            Breakdown_file << " | Friction Component (";
            Breakdown_file.width(5); Breakdown_file << int(100.0-(Surface_CMz_Inv[iMarker_Monitoring]*100.0)/(Surface_CMz[iMarker_Monitoring]+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Surface_CMz[iMarker_Monitoring]-Surface_CMz_Inv[iMarker_Monitoring] << endl;

            Breakdown_file << "Total CFx   (";
            Breakdown_file.width(5); Breakdown_file << int((Surface_CFx[iMarker_Monitoring]*100.0)/(Total_CFx+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Surface_CFx[iMarker_Monitoring];
            Breakdown_file << " | Pressure Component (";
            Breakdown_file.width(5); Breakdown_file << int((Surface_CFx_Inv[iMarker_Monitoring]*100.0)/(Surface_CFx[iMarker_Monitoring]+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Surface_CFx_Inv[iMarker_Monitoring];
            Breakdown_file << " | Friction Component (";
            Breakdown_file.width(5); Breakdown_file << int(100.0-(Surface_CFx_Inv[iMarker_Monitoring]*100.0)/(Surface_CFx[iMarker_Monitoring]+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Surface_CFx[iMarker_Monitoring]-Surface_CFx_Inv[iMarker_Monitoring] << endl;

            Breakdown_file << "Total CFy   (";
            Breakdown_file.width(5); Breakdown_file << int((Surface_CFy[iMarker_Monitoring]*100.0)/(Total_CFy+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Surface_CFy[iMarker_Monitoring];
            Breakdown_file << " | Pressure Component (";
            Breakdown_file.width(5); Breakdown_file << int((Surface_CFy_Inv[iMarker_Monitoring]*100.0)/(Surface_CFy[iMarker_Monitoring]+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Surface_CFy_Inv[iMarker_Monitoring];
            Breakdown_file << " | Friction Component (";
            Breakdown_file.width(5); Breakdown_file << int(100.0-(Surface_CFy_Inv[iMarker_Monitoring]*100.0)/(Surface_CFy[iMarker_Monitoring]+EPS));
            Breakdown_file << "%): ";
            Breakdown_file.width(11); Breakdown_file << Surface_CFy[iMarker_Monitoring]-Surface_CFy_Inv[iMarker_Monitoring] << endl;

            if (nDim == 3) {
                Breakdown_file << "Total CFz   (";
                Breakdown_file.width(5); Breakdown_file << int((Surface_CFz[iMarker_Monitoring]*100.0)/(Total_CFz+EPS));
                Breakdown_file << "%): ";
                Breakdown_file.width(11); Breakdown_file << Surface_CFz[iMarker_Monitoring];
                Breakdown_file << " | Pressure Component (";
                Breakdown_file.width(5); Breakdown_file << int((Surface_CFz_Inv[iMarker_Monitoring]*100.0)/(Surface_CFz[iMarker_Monitoring]+EPS));
                Breakdown_file << "%): ";
                Breakdown_file.width(11); Breakdown_file << Surface_CFz_Inv[iMarker_Monitoring];
                Breakdown_file << " | Friction Component (";
                Breakdown_file.width(5); Breakdown_file << int(100.0-(Surface_CFz_Inv[iMarker_Monitoring]*100.0)/(Surface_CFz[iMarker_Monitoring]+EPS));
                Breakdown_file << "%): ";
                Breakdown_file.width(11); Breakdown_file << Surface_CFz[iMarker_Monitoring]-Surface_CFz_Inv[iMarker_Monitoring] << endl;
            }

            Breakdown_file << endl;

        }

        delete [] Surface_CLift;
        delete [] Surface_CDrag;
        delete [] Surface_CSideForce;
        delete [] Surface_CEff;
        delete [] Surface_CFx;
        delete [] Surface_CFy;
        delete [] Surface_CFz;
        delete [] Surface_CMx;
        delete [] Surface_CMy;
        delete [] Surface_CMz;

        delete [] Surface_CLift_Inv;
        delete [] Surface_CDrag_Inv;
        delete [] Surface_CSideForce_Inv;
        delete [] Surface_CEff_Inv;
        delete [] Surface_CFx_Inv;
        delete [] Surface_CFy_Inv;
        delete [] Surface_CFz_Inv;
        delete [] Surface_CMx_Inv;
        delete [] Surface_CMy_Inv;
        delete [] Surface_CMz_Inv;

        Breakdown_file.close();

    }

}

void COutput::SetResult_Files(CSolver ****solver_container, CGeometry ***geometry, CConfig **config,
                              unsigned long iExtIter, unsigned short val_nZone) {

    int rank = MASTER_NODE;
#ifdef HAVE_MPI
    int size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif
    unsigned short iZone;

    for (iZone = 0; iZone < val_nZone; iZone++) {
        bool Wrt_Vol = config[iZone]->GetWrt_Vol_Sol();
        bool Wrt_Srf = config[iZone]->GetWrt_Srf_Sol();

#ifdef HAVE_MPI

        MPI_Comm_size(MPI_COMM_WORLD, &size);
        if (size > SINGLE_NODE) {
            Wrt_Vol = true;
            Wrt_Srf = true;
        }
#endif

        bool Wrt_Csv = config[iZone]->GetWrt_Csv_Sol();

        if (rank == MASTER_NODE) cout << endl << "Writing comma-separated values (CSV) surface files." << endl;

        switch (config[iZone]->GetKind_Solver()) {

        case EULER : case NAVIER_STOKES : case RANS :

            if (Wrt_Csv) SetSurfaceCSV_Flow(config[iZone], geometry[iZone][MESH_0], solver_container[iZone][MESH_0][FLOW_SOL], iExtIter, iZone);
            break;
        }

        unsigned short FileFormat = config[iZone]->GetOutput_FileFormat();

        if (Wrt_Vol || Wrt_Srf) {
            if (rank == MASTER_NODE) cout << "Merging connectivities in the Master node." << endl;
            MergeConnectivity(config[iZone], geometry[iZone][MESH_0], iZone);
        }

        if (rank == MASTER_NODE) cout << "Merging coordinates in the Master node." << endl;
        //            MergeCoordinates(config[iZone], geometry[iZone][MESH_0]);

        if ((rank == MASTER_NODE) && (Wrt_Vol || Wrt_Srf)) {
            if (FileFormat == TECPLOT_BINARY) {
                if (rank == MASTER_NODE) cout << "Writing Tecplot binary volume and surface mesh files." << endl;
                SetTecplot_MeshBinary(config[iZone], geometry[iZone][MESH_0], iZone);
                SetTecplot_SurfaceMesh(config[iZone], geometry[iZone][MESH_0], iZone);
            }
        }

        if (rank == MASTER_NODE) cout << "Merging solution in the Master node." << endl;
        MergeSolution(config[iZone], geometry[iZone][MESH_0], solver_container[iZone][MESH_0], iZone);

        if (rank == MASTER_NODE) {

            if (rank == MASTER_NODE) cout << "Writing SU2 native restart file." << endl;
            //      SetRestart(config[iZone], geometry[iZone][MESH_0], solver_container[iZone][MESH_0] ,iZone);

            if (Wrt_Vol && Wrt_Srf) {

                switch (FileFormat) {

                case TECPLOT:

                    if (rank == MASTER_NODE) cout << "Writing Tecplot ASCII file volume solution file." << endl;
                    SetTecplot_ASCII(config[iZone], geometry[iZone][MESH_0], solver_container[iZone][MESH_0],iZone, val_nZone);
                    SetTecplotSurf_ASCII(config[iZone], geometry[iZone][MESH_0],solver_container[iZone][MESH_0] ,iZone, val_nZone);

                    //                    DeallocateConnectivity(config[iZone], geometry[iZone][MESH_0], false);
                    break;
                }
            }

            DeallocateConnectivity(config[iZone], geometry[iZone][MESH_0]);

            DeallocateCoordinates(config[iZone], geometry[iZone][MESH_0]);

            DeallocateSolution(config[iZone], geometry[iZone][MESH_0]);

        }

#ifdef HAVE_MPI
        MPI_Bcast(&wrote_base_file, 1, MPI_UNSIGNED_SHORT, MASTER_NODE, MPI_COMM_WORLD);
        MPI_Bcast(&wrote_surf_file, 1, MPI_UNSIGNED_SHORT, MASTER_NODE, MPI_COMM_WORLD);
#endif

    }
}

void COutput::SetBaselineResult_Files(CSolver **solver, CGeometry **geometry, CConfig **config,
                                      unsigned long iExtIter, unsigned short val_nZone) {

    int rank = MASTER_NODE;
    int size = SINGLE_NODE;

#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
#endif

    unsigned short iZone;

    for (iZone = 0; iZone < val_nZone; iZone++) {

        /*--- Flags identifying the types of files to be written. ---*/

        bool Low_MemoryOutput = config[iZone]->GetLow_MemoryOutput();
        bool Wrt_Vol = config[iZone]->GetWrt_Vol_Sol();
        bool Wrt_Srf = config[iZone]->GetWrt_Srf_Sol();

        /*--- Get the file output format ---*/

        unsigned short FileFormat = config[iZone]->GetOutput_FileFormat();

        /*--- Merge the node coordinates and connectivity if necessary. This
     is only performed if a volume solution file is requested, and it
     is active by default. ---*/

        if ((Wrt_Vol || Wrt_Srf) && (!Low_MemoryOutput)) {
            if (rank == MASTER_NODE) cout << "Merging connectivities in the Master node." << endl;
            MergeConnectivity(config[iZone], geometry[iZone], iZone);
        }

        /*--- Merge the solution data needed for volume solutions and restarts ---*/

        if ((Wrt_Vol || Wrt_Srf) && (!Low_MemoryOutput)) {
            if (rank == MASTER_NODE) cout << "Merging solution in the Master node." << endl;
            MergeBaselineSolution(config[iZone], geometry[iZone], solver[iZone], iZone);
        }

        /*--- Write restart, Tecplot or Paraview files using the merged data.
     This data lives only on the master, and these routines are currently
     executed by the master proc alone (as if in serial). ---*/

        if (!Low_MemoryOutput) {

            if (rank == MASTER_NODE) {

                if (Wrt_Vol) {

                    switch (FileFormat) {

                    case TECPLOT:

                        /*--- Write a Tecplot ASCII file ---*/

                        if (rank == MASTER_NODE) cout << "Writing Tecplot ASCII file (volume grid)." << endl;
                        //                        SetTecplot_ASCII(config[iZone], geometry[iZone], solver,iZone, val_nZone, false);
                        //                        DeallocateConnectivity(config[iZone], geometry[iZone], false);
                        break;

                    case TECPLOT_BINARY:

                        /*--- Write a Tecplot binary solution file ---*/

                        if (rank == MASTER_NODE) cout << "Writing Tecplot Binary file (volume grid)." << endl;
                        SetTecplot_MeshBinary(config[iZone], geometry[iZone], iZone);
                        SetTecplot_Solution(config[iZone], geometry[iZone], iZone);
                        break;

                    case PARAVIEW:

                        /*--- Write a Paraview ASCII file ---*/

                        if (rank == MASTER_NODE) cout << "Writing Paraview ASCII file (volume grid)." << endl;
                        SetParaview_ASCII(config[iZone], geometry[iZone], iZone, val_nZone, false);
                        //                        DeallocateConnectivity(config[iZone], geometry[iZone], false);
                        break;

                    default:
                        break;
                    }

                }

                if (Wrt_Srf) {

                    switch (FileFormat) {

                    case TECPLOT:

                        /*--- Write a Tecplot ASCII file ---*/

                        if (rank == MASTER_NODE) cout << "Writing Tecplot ASCII file (surface grid)." << endl;
                        //                        SetTecplot_ASCII(config[iZone], geometry[iZone], solver, iZone, val_nZone, true);
                        //                        DeallocateConnectivity(config[iZone], geometry[iZone], true);
                        break;

                    case TECPLOT_BINARY:

                        /*--- Write a Tecplot binary solution file ---*/

                        if (rank == MASTER_NODE) cout << "Writing Tecplot Binary file (surface grid)." << endl;
                        SetTecplot_SurfaceMesh(config[iZone], geometry[iZone], iZone);
                        SetTecplot_SurfaceSolution(config[iZone], geometry[iZone], iZone);
                        break;

                    case PARAVIEW:

                        /*--- Write a Paraview ASCII file ---*/

                        if (rank == MASTER_NODE) cout << "Writing Paraview ASCII file (surface grid)." << endl;
                        SetParaview_ASCII(config[iZone], geometry[iZone], iZone, val_nZone, true);
                        //                        DeallocateConnectivity(config[iZone], geometry[iZone], true);
                        break;

                    default:
                        break;
                    }
                }

                if (FileFormat == TECPLOT_BINARY) {
                    //                    if (!wrote_base_file)
                    //                        DeallocateConnectivity(config[iZone], geometry[iZone], false);
                    //                    if (!wrote_surf_file)
                    //                        DeallocateConnectivity(config[iZone], geometry[iZone], wrote_surf_file);
                }

                if (Wrt_Vol || Wrt_Srf)
                    DeallocateSolution(config[iZone], geometry[iZone]);
            }

        }

        else {

            if (Wrt_Vol) {

                if (rank == MASTER_NODE) cout << "Writing Tecplot ASCII file (volume grid)." << endl;
                char buffer_char[50], out_file[MAX_STRING_SIZE];

                string filename;
                if (!config[iZone]->GetAdjoint()) filename = config[iZone]->GetFlow_FileName();
                else filename = config[iZone]->GetAdj_FileName();

                if (size > 1) {
                    sprintf (buffer_char, "_%d", int(rank+1));
                    filename = filename + buffer_char;
                }

                sprintf (buffer_char, ".dat");
                strcpy(out_file, filename.c_str()); strcat(out_file, buffer_char);
                SetTecplotNode_ASCII(config[iZone], geometry[iZone], solver, out_file, false);
            }

            if (Wrt_Srf) {

                if (rank == MASTER_NODE) cout << "Writing Tecplot ASCII file (surface grid)." << endl;
                char buffer_char[50], out_file[MAX_STRING_SIZE];

                string filename;
                if (!config[iZone]->GetAdjoint()) filename = config[iZone]->GetSurfFlowCoeff_FileName();
                else filename = config[iZone]->GetSurfAdjCoeff_FileName();

                if (size > 1) {
                    sprintf (buffer_char, "_%d", int(rank+1));
                    filename = filename + buffer_char;
                }

                sprintf (buffer_char, ".dat");
                strcpy(out_file, filename.c_str()); strcat(out_file, buffer_char);
                SetTecplotNode_ASCII(config[iZone], geometry[iZone], solver, out_file, true);
            }

        }

        /*--- Final broadcast (informing other procs that the base output
     file was written). ---*/

#ifdef HAVE_MPI
        MPI_Bcast(&wrote_base_file, 1, MPI_UNSIGNED_SHORT, MASTER_NODE, MPI_COMM_WORLD);
#endif

    }
}

void COutput::SetMesh_Files(CGeometry **geometry, CConfig **config, unsigned short val_nZone, bool new_file) {

    int rank = MASTER_NODE;
#ifdef HAVE_MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif

    unsigned short iZone;

    for (iZone = 0; iZone < val_nZone; iZone++) {

        /*--- Flags identifying the types of files to be written. ---*/

        bool Wrt_Vol = config[iZone]->GetWrt_Vol_Sol() && config[iZone]->GetVisualize_Deformation();
        bool Wrt_Srf = config[iZone]->GetWrt_Srf_Sol() && config[iZone]->GetVisualize_Deformation();;

        /*--- Merge the node coordinates and connectivity if necessary. This
     is only performed if a volume solution file is requested, and it
     is active by default. ---*/

        if (Wrt_Vol || Wrt_Srf) {
            if (rank == MASTER_NODE) cout <<"Merging grid connectivity." << endl;
            MergeConnectivity(config[iZone], geometry[iZone], iZone);
        }

        /*--- Merge coordinates of all grid nodes (excluding ghost points).
     The grid coordinates are always merged and included first in the
     restart files. ---*/

        MergeCoordinates(config[iZone], geometry[iZone]);

        /*--- Write restart, Tecplot or Paraview files using the merged data.
     This data lives only on the master, and these routines are currently
     executed by the master proc alone (as if in serial). ---*/

        if (rank == MASTER_NODE) {

            if (Wrt_Vol) {

                if (rank == MASTER_NODE) cout <<"Writing volume mesh file." << endl;

                /*--- Write a Tecplot ASCII file ---*/

                SetTecplot_MeshASCII(config[iZone], geometry[iZone], false, new_file);

            }

            if (Wrt_Srf) {

                if (rank == MASTER_NODE) cout <<"Writing surface mesh file." << endl;

                /*--- Write a Tecplot ASCII file ---*/

                SetTecplot_MeshASCII(config[iZone], geometry[iZone], true, new_file);

            }

            if (rank == MASTER_NODE) cout <<"Writing .su2 file." << endl;

            /*--- Write a .su2 ASCII file ---*/

            SetSU2_MeshASCII(config[iZone], geometry[iZone]);

            /*--- Deallocate connectivity ---*/

            //            DeallocateConnectivity(config[iZone], geometry[iZone], true);

        }

        /*--- Final broadcast (informing other procs that the base output
     file was written). ---*/

#ifdef HAVE_MPI
        MPI_Bcast(&wrote_base_file, 1, MPI_UNSIGNED_SHORT, MASTER_NODE, MPI_COMM_WORLD);
#endif

    }
}

void COutput::SetMassFlowRate(CSolver *solver_container, CGeometry *geometry, CConfig *config){

}

void COutput::OneDimensionalOutput(CSolver *solver_container, CGeometry *geometry, CConfig *config) {

}

void COutput::SetForceSections(CSolver *solver_container, CGeometry *geometry, CConfig *config, unsigned long iExtIter) {

}

void COutput::SetCp_InverseDesign(CSolver *solver_container, CGeometry *geometry, CConfig *config, unsigned long iExtIter) {

}

void COutput::SetHeat_InverseDesign(CSolver *solver_container, CGeometry *geometry, CConfig *config, unsigned long iExtIter) {


}

void COutput::SetEquivalentArea(CSolver *solver_container, CGeometry *geometry, CConfig *config, unsigned long iExtIter) {

}

